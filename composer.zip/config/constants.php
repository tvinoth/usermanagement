<?php

return [
    /*
      |--------------------------------------------------------------------------
      | Application Config module names
      |--------------------------------------------------------------------------
      |
     */
    'products' => ['self' => 1, 'product_app_id' => 'APPID'],
    'module' => ['dashBoard' => 1, 'userDashboard' => 2, 'adminDashboard' => 3, 'productModule' => 12, 'UserModule' => 4, 'HierarchyModule' => 5, 'appSettingModule' => 6,
        'empTypeModule' => 7, 'roleModule' => 13],
    'roles' => ['role_code' => 'RL'],
    'STATUS_ENUM' => ['DELETED' => '1', 'NOT_DELETED' => 0, 'ACTIVE' => 1, 'INACTIVE' => 0],
];

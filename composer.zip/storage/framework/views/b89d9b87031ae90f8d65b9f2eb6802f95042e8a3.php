<ul>
<?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li>
            <?php if(count($child->childs)): ?>
	    <i class="indicator glyphicon glyphicon-plus-sign"></i>
            <?php endif; ?>
            <label class='<?php echo e($hierarchyID == $child->hierarchy_id?"selectedhighlight":""); ?> pointer'>
                <input type="checkbox" name="HierarchyParent" data-hierarchyname="<?php echo e($child->hierarchy_name); ?>"  <?php echo e($hierarchyID == $child->hierarchy_id?"checked":""); ?> value="<?php echo e($child->hierarchy_id); ?>">&nbsp;<?php echo e($child->hierarchy_name); ?></label>
	<?php if(count($child->childs)): ?>
            <?php echo $__env->make('HierarchyManagement.manageHierarchychild',['childs' => $child->childs], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
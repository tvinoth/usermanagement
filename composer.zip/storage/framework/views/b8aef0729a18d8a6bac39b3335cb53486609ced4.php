    
    <?php if($userdetails != null && $methodtype   ==  "view"): ?>    
    <section class="content">
        <div class="box-default" data-collapsed="0">
            <div class="box-header with-border">
                <div class="box-title">
                <strong><?php echo e($userdetails->first_name); ?></strong>
                </div>
            </div>
        
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6"><p class="pull-left"><img src="<?php echo e(url($userdetails->profile)); ?>" class="img-circle" alt="User Image" style="width:20%;height:20%"></p></div><div class="col-sm-6"></div>
            </div>
            <div class="row">
                <div class="col-sm-6 form-horizontal">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        User Details
                        </a>
                    </div>
                    
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">First Name</label>
                        <div class="col-sm-8">
                            <span class="form-control"><?php echo e($userdetails->first_name); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Last Name</label>
                        <div class="col-sm-8">
                            <span class="form-control"><?php echo e($userdetails->last_name); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Emp ID</label>
                        <div class="col-sm-8">
                            <span class="form-control"><?php echo e($userdetails->employee_id); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-8">
                            <span class="form-control"><?php echo e($userdetails->email); ?></span>
                        </div>
                    </div>

<!--                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Date of Birth</label>
                        <div class="col-sm-8">
                            <span class="form-control"><?php echo e($userdetails->dob); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Phone</label>
                        <div class="col-sm-8">
                            <span class="form-control"><?php echo e($userdetails->mobile); ?></span>
                        </div>
                    </div>-->
                    
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Type</label>
                        <div class="col-sm-8">
                            <select name="emp_type" class="form-control" disabled="true">
                                <option value=""> --Select--</option>
                                <?php $__currentLoopData = $emptype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->emplyoee_type_id); ?>" <?php echo e($value->emplyoee_type_id   ==  $userdetails->employee_type?'selected':''); ?>> <?php echo e($value->type_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Team</label>
                        <div class="col-sm-8">
                            <select name="emp_team" class="form-control" disabled="true">
                                <option value=""> --Select--</option>
                                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->hierarchy_id); ?>" <?php echo e($value->hierarchy_id   ==  $userdetails->team_id?'selected':''); ?>> <?php echo e($value->hierarchy_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

<!--                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Role</label>
                        <div class="col-sm-8">
                            <span class="form-control"><?php echo e($userdetails->role_id); ?></span>
                        </div>
                    </div>-->
                </div>
                
                
                <div class="col-sm-6">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        Product Access Details
                        </a>
                        <ul class="nav nav-pills nav-stacked">
                        <?php $__empty_1 = true; $__currentLoopData = $productinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><a href="#"><img src="<?php echo e($product->product_logo); ?>"  class="img-circle" alt="User Image" style="width:5%;height:5%"> &nbsp;&nbsp; <?php echo e($product->product_name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li><a href="#">No Products</a></li>
                        <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    
    
    <?php elseif($userdetails != null && $methodtype   ==  "update"): ?>    
    <section class="content">
        <div class="box-default" data-collapsed="0">
            <div class="box-header with-border">
                <div class="box-title">
                <strong><?php echo e($userdetails->first_name); ?></strong>
                </div>
            </div>
        
        <div class="box-body">
        <form method="POST" action="<?php echo e(url('api/doUpdateUserInfo')); ?>" id="UpdateSectionForm" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-sm-6"><p class="pull-left"><img src="<?php echo e(url($userdetails->profile)); ?>"  class="img-circle" alt="User Image" style="width:20%;height:20%"></p></div><div class="col-sm-6"></div>
            </div>
            <div class="row">
                <div class="col-sm-6 form-horizontal">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        User Details
                        </a>
                    </div>
                    <input type="hidden" name="app_id" value="fsafr">
                    <input type="hidden" name="app_token" value="fsa5685t">
                    <input type="hidden" name="ip_address" value="172.24.183.332">
                    <input type="hidden" name="user_id" value="<?php echo e($userdetails->user_id); ?>">
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">First Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="first_name" value="<?php echo e($userdetails->first_name); ?>" placeholder="First Name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Last Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="last_name" value="<?php echo e($userdetails->last_name); ?>" placeholder="Last Name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Emp ID</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="emp_id" value="<?php echo e($userdetails->employee_id); ?>" placeholder="Emp Id">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-8">
                            <input type="email" class="form-control" name="email" value="<?php echo e($userdetails->email); ?>" placeholder="Email-ID">
                        </div>
                    </div>

<!--                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Date of Birth</label>
                        <div class="col-sm-8">
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control" name="dob" id="datepicker" value="<?php echo e($userdetails->dob); ?>" placeholder="Date Of Birth">
                            </div>
                        </div>
                    </div>-->
                    
<!--                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Phone</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="mobile" value="<?php echo e($userdetails->mobile); ?>" placeholder="Mobile">
                        </div>
                    </div>-->

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Type</label>
                        <div class="col-sm-8">
                            <select name="emp_type" class="form-control">
                                <option value=""> --Select--</option>
                                <?php $__currentLoopData = $emptype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->emplyoee_type_id); ?>" <?php echo e($value->emplyoee_type_id   ==  $userdetails->employee_type?'selected':''); ?>> <?php echo e($value->type_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Team</label>
                        <div class="col-sm-8">
                            <select name="emp_team" class="form-control">
                                <option value=""> --Select--</option>
                                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->hierarchy_id); ?>" <?php echo e($value->hierarchy_id   ==  $userdetails->team_id?'selected':''); ?>> <?php echo e($value->hierarchy_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Photo</label>
                        <div class="col-sm-3">
                            <input type="file" id="updateuserimage" class="form-control" name="upload_profile">
                        </div>
                        <div class="col-sm-6">
                            <center><img src="<?php echo e(url('assets/dist/img/empty-user.jpg')); ?>" id="updatepreviewimage"  class="img-circle" alt="User Image" style="width:15%;height:15%"></center>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <button type="button" class="btn btn-primary" id="UpdateSection"> <i class="fa fa-save"> </i> Save Changes</button>
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                </div>
                
                
                <div class="col-sm-6">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        Product Access Details
                        </a>
                        <ul class="nav nav-pills nav-stacked">
                        <?php $__empty_1 = true; $__currentLoopData = $productinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><a href="#"><img src="<?php echo e($product->product_logo); ?>"  class="img-circle" alt="User Image" style="width:5%;height:5%"> &nbsp;&nbsp; <?php echo e($product->product_name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li><a href="#">No Products</a></li>
                        <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </form>
        </div>
        </div>
    </section>
    <?php else: ?>
    <h1>No Data found</h1>
    <?php endif; ?>
    
    <script>
        var imageuploaddata     =   "";
        function readURL(input, previewtype) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                if (previewtype == 1)
                    $('#previewuploaduserimage').attr('src', e.target.result);
                else
                    $('#updatepreviewimage').attr('src', e.target.result);
                imageuploaddata     =   e.target.result;
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#uploaduserimage").change(function () {
        readURL(this, 1);
    });

    $("#updateuserimage").change(function () {
        readURL(this, 2);
    });
    
        $( "#UpdateSection" ).click(function(e) {    // Add     
        e.preventDefault();
//        var formData    =   $( "#UpdateSectionForm" ).serialize();
        var url         =   $( "#UpdateSectionForm" ).attr('action');   
        var formData    =   new FormData($( "#UpdateSectionForm" )[0]);
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#UpdateSectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }
                    $.notify(data.Message,'success');
//                    $("#showupdate_users").css('display','none');
                    sectionListReload();
                }
           });
        }
    });
    </script>
    
    <?php $__env->startSection('bottomScripts'); ?>
    <script>
        $(document).ready(function(){
            $('#datepicker').datepicker({
            autoclose: true
        });
        });
    </script>    
    <?php $__env->stopSection(); ?>

<header class="main-header">
    <a href="#" class="logo">
        <span class="logo-mini"><b>SPi USER</b></span>
        <span class="logo-lg"><b>SPi USER</b></span>
    </a>

    <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <li class="dropdown user user-menu">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="<?php echo e(url('assets/dist/img/avatar5.png')); ?>" class="user-image" alt="User Image">
                        <span class="hidden-xs"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></span>
                    </a>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                    <ul class="dropdown-menu">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    </ul>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                    <ul class="dropdown-menu">
                        <li class="user-header">
                            <img src="<?php echo e(url('assets/dist/img/avatar5.png')); ?>" class="img-circle" alt="User Image">
                            <p><?php echo e(Auth::user()->name); ?></p>
                        </li>
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="#" class="btn btn-info btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger btn-flat" onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                Sign out</a>
                            </div>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </nav>
    
</header>


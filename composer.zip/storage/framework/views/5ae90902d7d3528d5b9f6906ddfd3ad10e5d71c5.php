<?php $__env->startSection('content'); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b><?php echo e($modulename); ?></b></small></h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
                <li><a href="<?php echo e(url('menu/submodule')); ?>"> Sub Module</a></li>
            </ol>
        </section>
            
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class="active"><a href="#all_data" data-toggle="tab">All Module</a></li>
                    <li class=""><a href="#new_data" data-toggle="tab">New Module</a></li>
                    <li class="taggleusertab" style="display:none" id="showupdate_data"><a href="#update_data" data-toggle="tab">Update Module</a></li>
                    <li class="taggleusertab" style="display:none" id="showview_data"><a href="#view_data" data-toggle="tab">View Module</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">    
                        <div class="box-body">
                            <table id="userList" class="table table-bordered table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th>Sub Module Name</th>
                                        <th>Module Name</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>      
                                </tbody>    
                            </table>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="new_data">
                        <br>

                        <form method="POST" action="<?php echo e(url('api/submenu/addModule/new')); ?>" id="SectionForm" accept-charset="UTF-8" class="form-horizontal" role="form" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group required">
                                <label for="field-1" class="col-sm-3 control-label">Main Module</label>
                                <div class="col-sm-5">
                                    <select name="module_id" class="form-control required_field">
                                        <option value=""> --Select--</option>
                                        <?php $__currentLoopData = $menumoduledetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($value->module_id); ?>"><?php echo e($value->module_name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group required">
                                <label class=" col-lg-3 control-label company-label">Name</label>
                                <div class="col-lg-5">
                                    <input id="fname" class="form-control required_field" maxlength="150" name="sub_module_name" type="text">
                                    <span class="text-danger"></span>
                                </div>
                            </div>

                            <div class="form-group required">
                                <label class=" col-lg-3 control-label company-label">Description</label>
                                <div class="col-lg-5">
                                    <input id="lname" class="form-control required_field" maxlength="150" required="true" name="sub_description" type="text">
                                    <span class="text-danger"></span>
                                </div>
                            </div>                            
                            
                            <input type="hidden" name="app_id" value="<?php echo e($productdata['app_id']); ?>">
                            <input type="hidden" name="app_token" value="<?php echo e($productdata['app_token']); ?>">
                            <div class="form-group row">
                                <div class="col-lg-4"></div>
                                <div class="col-lg-1">
                                    <!--<button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>-->
                                </div>
                                <div class="col-lg-1">
                                    <button type="submit" class="btn btn-primary" id="AddSection">  <i class="fa fa-fw fa-check"> </i> Create Module</button>
                                </div>
                                <div class="col-lg-4"></div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-5 col-lg-offset-3">
                                </div>
                            </div>
                        </form>

                    </div>
                    
                    <div class="tab-pane fade removeshowactive" id="update_data">
                        <br>
                        
                        
                    </div>
                    
                    <div class="tab-pane fade removeshowactive" id="view_data">
                    <br>


                    </div>
                </div>
            </div>
        </section>
    </div>
        
        
        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog ">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header deletemodal">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Delete User</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo e(url('api/submenu/moduleDelete')); ?>" method="post" id="DeleteSectionForm">   
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="col-md-12">
                          <div class="form-group required">
                            <input type="hidden" id="sub_module_id" name="sub_module_id">
                            <input type="hidden" name="app_id" value="<?php echo e($productdata['app_id']); ?>">
                            <input type="hidden" name="app_token" value="<?php echo e($productdata['app_token']); ?>">
                          </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </form>
                    <div class="modal-body">
                        Are you sure you want to delete a <b><span id='username'></span></b>?

                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                        <button type="button" class="btn btn-danger" id="DeleteSection"><i class="fa fa-user-times"></i> Confirm Delete</button>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomScripts'); ?>
<script>
    $(document).ready(function()
    {
        $(document).on('click','#usertabmenuactivity',function () {
            if($("#usertabmenuactivity li:visible").length >2 ){
                $(".taggleusertab").each(function(){
                    $(this).hide();
                });
                $(".removeshowactive").removeClass('show active in');
            }
        });
    });
     
var datatable_url   =   <?php echo "'".url('api/submenu/getMenuList')."'"; ?>;
var token           =   <?php echo "'".csrf_token()."'"; ?>;
var app_id          =   <?php echo "'".$productdata['app_id']."'"; ?>;
var app_token       =   <?php echo "'".$productdata['app_token']."'"; ?>;
$.fn.dataTable.ext.errMode  =   'none';
var sectionList     =   $('#userList').DataTable({
            "fixedHeader": true,
            "processing": true,
            "serverSide": true,
                ajax: {
                        url: datatable_url,
                        type: 'POST',
                        'data': {
                            _token: token,'app_id':app_id
                        },
                    },
                    "initComplete": function(settings, json) {
//                    console.log(json);
                    },
            "order": [[ 1, "desc" ]],
            fixedHeader: {
                header: true,
                footer: true
            }
        });



    function sectionListReload(){
        sectionList.clear().draw();
    }
    
    function viewUserinfo(id,thisdata)
    {
        var methodtype  =   $(thisdata).attr('data-type');
        $('#usertabmenuactivity').find('li').each(function(e){
            $(this).removeClass('active'); 
        });
        $('div.tab-pane').each(function(){
            $(this).removeClass('in');
            $(this).removeClass('show');
            $(this).removeClass('active');
        });
        if(methodtype   ==  "update"){
            $("#showupdate_data").css('display','block');
            $("#showupdate_data").addClass('active');
            $("#update_data").addClass('in');
            $("#update_data").addClass('show');
            $("#update_data").addClass('active');
        }else{
            $("#showview_data").css('display','block');
            $("#showview_data").addClass('active');
            $("#view_data").addClass('in');
            $("#view_data").addClass('show');
            $("#view_data").addClass('active');
        }
          
        var postdata    =   {'app_id':app_id,'app_token':app_token,'sub_module_id':id,_token: token,'methodtype':methodtype};
        $.ajax({
            type    :   "POST",
            url     :   '<?php echo e(url("api/submenu/viewModuleInfo")); ?>',
            dataType:   "html",
            data    :   postdata,
            success: function(data) {
                if(methodtype   ==  "update")
                $("#update_data").html(data);
                else
                $("#view_data").html(data);
            }
        });
    }
    
    $( "#AddSection" ).click(function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SectionForm" ).serialize();
        var url         =   $( "#SectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }else{
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
                }
           });
        }
    });
    
    // delete
    $( "div" ).on( "click", ".deleteSection", function() {
        var id          =   this.id;
        var username    =   $(this).data('deleteusername');
        var sectionID   =   id.replace("deleteSection_", "");
        $("#sub_module_id").val(sectionID);
        $("#username").text(username);
    });
     
    $( "#DeleteSection" ).click(function() {   //Update      
        var formData    =   $( "#DeleteSectionForm" ).serialize();
        var url         =   $( "#DeleteSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#DeleteSectionForm .required_field').each(function(index){
            var value   =   $(this).val();
            value       =   value.trim();
            if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });

        if(validation  ==  true){
           var postdata    =   formData;
           $.ajax({
               type    :   "DELETE",
               url     :   url,
               data    :   postdata,
               success: function(data) {
                   if(data.Status == 1){
                       $.notify(data.Message,'success');
                       sectionListReload(); 
                       $('#modal-delete').trigger('click');
                   }else{
                       $.notify(data.Message,'danger');
                   }
               }
           });
        }
    });
</script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
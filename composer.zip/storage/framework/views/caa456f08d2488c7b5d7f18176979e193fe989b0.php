<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Spi User')); ?></title>
    <!-- Scripts -->
    <!--<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>-->
    <!-- Styles -->
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo e(url('assets/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">  
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('assets/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- ICHECK -->
    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/iCheck/all.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo e(url('assets/bower_components/Ionicons/css/ionicons.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/dist/css/AdminLTE.min.css')); ?>">  
    <link rel="stylesheet" href="<?php echo e(url('assets/css/custom.css')); ?>">
    <!-- Morris chart -->
    <!--<link rel="stylesheet" href="<?php echo e(url('assets/bower_components/morris.js/morris.css')); ?>">-->
    <!-- jvectormap -->
    <!--<link rel="stylesheet" href="<?php echo e(url('assets/bower_components/jvectormap/jquery-jvectormap.css')); ?>">-->
    <!-- Date Picker -->
    <link rel="stylesheet" href="<?php echo e(url('assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(url('assets/bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>">
    <!-- bootstrap wysihtml5 - text editor -->
    <!--<link rel="stylesheet" href="<?php echo e(url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">-->
</head>

<?php echo $__env->yieldContent('topscripts'); ?>

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <!-- included menu top -->
        <?php echo $__env->make('layouts.menutop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</body>

    <script src="<?php echo e(url('assets/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(url('assets/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dist/js/bootstrap-notify.js')); ?>"></script>
    <!-- DataTables -->
    <script src="<?php echo e(url('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(url('assets/bower_components/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(url('assets/dist/js/adminlte.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(url('assets/bower_components/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
                $.widget.bridge('uibutton', $.ui.button);
    </script>
    
    <!--<script src="<?php echo e(url('assets/dist/js/pages/dashboard.js')); ?>"></script>-->
    <!-- AdminLTE for demo purposes -->
    <!--<script src="<?php echo e(url('assets/dist/js/demo.js')); ?>"></script>-->
    <!-- Morris.js charts 
    <script src="<?php echo e(url('assets/bower_components/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/bower_components/morris.js/morris.min.js')); ?>"></script>-->
    <!-- Sparkline 
    <script src="<?php echo e(url('assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js')); ?>"></script>-->
    <!-- jvectormap 
    <script src="<?php echo e(url('assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>-->
    <!-- jQuery Knob Chart 
    <script src="<?php echo e(url('assets/bower_components/jquery-knob/dist/jquery.knob.min.js')); ?>"></script>-->
    <!-- jQuery Knob Chart -->
    <script src="<?php echo e(url('assets/plugins/iCheck/icheck.min.js')); ?>"></script>
    
    <!-- daterangepicker -->
    <script src="<?php echo e(url('assets/bower_components/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- datepicker -->
    <script src="<?php echo e(url('assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- Bootstrap WYSIHTML5 
    <script src="<?php echo e(url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>-->
    <!-- Slimscroll 
    <script src="<?php echo e(url('assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>-->
    <?php echo $__env->yieldContent('bottomScripts'); ?>

</html>

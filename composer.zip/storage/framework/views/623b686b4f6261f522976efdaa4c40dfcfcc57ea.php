<?php $__env->startSection('content'); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b><?php echo e($modulename); ?> - <?php echo e($productinfo->product_name); ?></b></small></h1>
            <ol class="breadcrumb">
            <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="<?php echo e(url('menu/module')); ?>"> Menu Module</a></li>
            </ol>
        </section>
        <!--<section class="">
            <div class="col-sm-10"></div>
            <div class="col-sm-2">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-info">
                    <i class="fa fa-user-plus"> </i> ADD USER
                </button>
            </div>
        </section><br><br>-->
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class=""><a href="<?php echo e(url('product/editproduct/'.$encryptproductID)); ?>">Product</a></li>
                    <li class="active"><a href="<?php echo e(url('product/productmodule/'.$encryptproductID)); ?>">Module</a></li>
                    <li class=""><a href="<?php echo e(url('product/productrole/'.$encryptproductID)); ?>">Roles</a></li>
                    <li class=""><a href="<?php echo e(url('product/productaccess/'.$encryptproductID)); ?>">User Access</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">
                        <div class="box-body">
                            <form id="SectionForm" accept-charset="UTF-8" class="form-horizontal" role="form" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                

                                <div class="form-group required">
                                    <label class=" col-lg-3 control-label company-label">Name</label>
                                    <div class="col-lg-5">
                                        <input id="fname" class="form-control required_field emptyvalue" maxlength="150" name="module_name" type="text">
                                        <span class="text-danger"></span>
                                    </div>
                                </div>

                                <div class="form-group required">
                                    <label class=" col-lg-3 control-label company-label">Description</label>
                                    <div class="col-lg-5">
                                        <input id="lname" class="form-control required_field emptyvalue" maxlength="150" required="true" name="description" type="text">
                                        <span class="text-danger"></span>
                                    </div>
                                </div>                            
                                
                                
                                <div class="form-group required disableupdatevalues" style="display:none">
                                    <label for="field-1" class="col-sm-3 control-label">Status</label>
                                    <div class="col-sm-5">
                                        <select name="status_enum" class="form-control required_field">
                                            <option value=""> --Select--</option>
                                            <?php $__currentLoopData = $statusdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option value="<?php echo e($value->status_id); ?>"><?php echo e($value->status_enum_name); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <input type="hidden" name="app_id" value="<?php echo e($productdata['app_id']); ?>">
                                <input type="hidden" name="app_token" value="<?php echo e($productdata['app_token']); ?>">
                                <input type="hidden" name="product_id" value="<?php echo e($productinfo->product_id); ?>">
                                <input type="hidden" name="module_id" class="disableupdatevalues" style="display:none">
                                <div class="form-group row">
                                    <div class="col-lg-4"></div>
                                    <div class="col-lg-1">
                                        <button type="button" class="btn btn-warning pull-left disableupdatevalues closeupdate" data-dismiss="modal" style="display:none"><i class="fa fa-close"></i> Close</button>
                                    </div>
                                    <div class="col-lg-1">
                                        <button type="button" class="btn btn-primary disablesubmitbtn" id="AddSection">  <i class="fa fa-fw fa-check"> </i> Create Module</button>
                                        <button type="button" class="btn btn-primary disableupdatevalues updatesubmitbtn" style="display:none">  <i class="fa fa-save"> </i> Update Module</button>
                                    </div>
                                    <div class="col-lg-4"></div>
                                </div>
                            </form>
                        </div>
                        
                        <div class="box-body">
                            <table id="userList" class="table table-bordered table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <!--<th>Case Type</th>-->
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>      
                                </tbody>    
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
        
        
        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog ">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header deletemodal">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Delete User</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo e(url('api/menu/moduleDelete')); ?>" method="post" id="DeleteSectionForm">   
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="col-md-12">
                          <div class="form-group required">
                            <input type="hidden" id="module_id" name="module_id">
                            <input type="hidden" name="app_id" value="<?php echo e($productdata['app_id']); ?>">
                            <input type="hidden" name="app_token" value="<?php echo e($productdata['app_token']); ?>">
                          </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </form>
                    <div class="modal-body">
                        Are you sure you want to delete a <b><span id='username'></span></b>?

                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                        <button type="button" class="btn btn-danger" id="DeleteSection"><i class="fa fa-user-times"></i> Confirm Delete</button>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        
        <div class="modal fade" id="modal-submodule">
            <div class="modal-dialog" style="width: 75%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Add SubModule - <span id='modulename'></span> </h4>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(url('api/submenu/addModule/new')); ?>" id="SubSectionForm" accept-charset="UTF-8" role="form" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                        <div class="form-group required">
                            <label class=" col-lg-1 control-label company-label">Name</label>
                            <div class="col-lg-3">
                                <input id="fname" class="form-control required_field" maxlength="150" name="sub_module_name" type="text">
                                <span class="text-danger"></span>
                            </div>
                        </div>

                        <div class="form-group required">
                            <label class=" col-lg-1 control-label company-label">Description</label>
                            <div class="col-lg-3">
                                <input id="lname" class="form-control required_field" maxlength="150" required="true" name="sub_description" type="text">
                                <span class="text-danger"></span>
                            </div>
                        </div>
                        
                        <input type="hidden" name="app_id" class="required_field"  value="<?php echo e($productdata['app_id']); ?>">
                        <input type="hidden" name="app_token" class="required_field"  value="<?php echo e($productdata['app_token']); ?>">
                        <input type="hidden" name="module_id" class="required_field"  value="">
                        <div class="form-group required">
                            <button type="submit" class="btn btn-primary" id="SubSection">  <i class="fa fa-fw fa-check"> </i> Create Sub Module</button>
                        </div>
                    </form><br>
                    <table class="table table-bordered table-striped" width="100%">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <!--<th>Case Type</th>-->
                                <th>Status</th>
                                <th>Created Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="sudmoduledata"> 
                        </tbody>    
                    </table>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning pull-right" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                    </div>
                    

                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        
                        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomScripts'); ?>
<script>
    $(document).ready(function()
    {
        $(".disableupdatevalues").css('display','none');
    });
     
    var datatable_url   =   <?php echo "'".url('api/menu/getMenuList')."'"; ?>;
    var token           =   <?php echo "'".csrf_token()."'"; ?>;
    var app_id          =   <?php echo "'".$productdata['app_id']."'"; ?>;
    var app_token       =   <?php echo "'".$productdata['app_token']."'"; ?>;
    
    var addmodule_url   =   <?php echo "'".url('api/menu/addModule/new')."'"; ?>;
    var updatemodule_url=   <?php echo "'".url('api/menu/addModule/update')."'"; ?>;

    $.fn.dataTable.ext.errMode  =   'none';
    var sectionList     =   $('#userList').DataTable({
            "fixedHeader": true,
            "processing": true,
            "serverSide": true,
                ajax: {
                        url: datatable_url,
                        type: 'POST',
                        'data': {
                            _token: token,'app_id':app_id
                        },
                    },
                    "initComplete": function(settings, json) {
//                    console.log(json);
                    },
            "order": [[ 1, "desc" ]],
            fixedHeader: {
                header: true,
                footer: true
            }
        });



    function sectionListReload(){
        sectionList.clear().draw();
    }
    
    function clearformdata(){
        $(".disableupdatevalues").css('display','none');
        $(".disablesubmitbtn").css('display','block');
        $("input[name='module_name']").val('');
        $("input[name='description']").val('');
        $("select[name='status_enum']").val('');
        $(".disablesubmitbtn").attr('id','AddSection');
        $(".updatesubmitbtn").removeAttr('id');
    }
    
    function viewUserinfo(id,name,desc,isActive,thisdata)
    {
        $('.required_field').removeClass('val-error');
        $(".disablesubmitbtn").css('display','none');
        $(".disablesubmitbtn").removeAttr('id');
        $(".updatesubmitbtn").attr('id','AddSection');
        $(".disableupdatevalues").css('display','block');
        $("input[name='module_name']").val(name);
        $("input[name='description']").val(desc);
        $("select[name='status_enum']").val(isActive);
        $("input[name='module_id']").val(id);
    }
        
    $(".closeupdate").click(function(){
        $(".emptyvalue").val('');
        $(".disablesubmitbtn").css('display','block');
        $(".disableupdatevalues").css('display','none'); 
        $(".disablesubmitbtn").attr('id','AddSection');
        $(".updatesubmitbtn").removeAttr('id');
    });
    
    $( document ).on('click','#AddSection',function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SectionForm" ).serialize();
        var url         =   addmodule_url;               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        var isactiveElement =   $("select[name='status_enum']:visible");
        if(isactiveElement.length   !=  0){
            var url         =   updatemodule_url; 
        }
        
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        clearformdata();
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
                }
           });
        }
    });
    
    //sub module creation SubSectionForm
        $( "#SubSection" ).click(function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SubSectionForm" ).serialize();
        var url         =   $( "#SubSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SubSectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        $("input[name='sub_module_name']").val('');
                        $("input[name='sub_description']").val('');
                        if(data.SubModuledata !== 'undefined'){
                            var errorHtml   =   '';
                            var innerstyle  =   '<tr id="deletesectionrow_'+data.SubModuledata.sub_module_id+'">';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'">'+data.SubModuledata.sub_module_name+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'">'+data.SubModuledata.sub_description+'</td>';
                            if(data.SubModuledata.is_active == 1){
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                            }else{
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
                            }
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'">'+data.SubModuledata.created_at+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'"><a onClick="editModuleinfo('+data.SubModuledata.sub_module_id+','+"'"+data.SubModuledata.sub_module_name+"'"+','+"'"+data.SubModuledata.sub_description+"'"+','+"'"+data.SubModuledata.created_at+"'"+','+data.SubModuledata.is_active+')" id="editSection_'+data.SubModuledata.sub_module_id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
                            innerstyle  +=  ' <a onClick=removeModule('+data.SubModuledata.sub_module_id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
                            errorHtml   +=  innerstyle+'</tr>';
                            $("#sudmoduledata tr:first").before(errorHtml);
                        }
                        
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
                }
           });
        }
    });
    
    // delete
    $( "div" ).on( "click", ".deleteSection", function() {
        var id          =   this.id;
        var username    =   $(this).data('deleteusername');
        var sectionID   =   id.replace("deleteSection_", "");
        $("#module_id").val(sectionID);
        $("#username").text(username);
    });
    var sectionID   =   "";
    function viewSubmoduleinfo(sectionID,thisdata){
        sectionID   =   sectionID;
        var datatable_url   =   <?php echo "'".url('api/product/viewsubmodule')."'"; ?>;
        $("input[name='sub_module_name']").val('');
        $("input[name='sub_description']").val('');
        $('.required_field').removeClass('val-error');
        $("input[name='module_id']").val(sectionID);
        var modulename  =   $(thisdata).attr('data-addmodulename');
        $("#modulename").text(modulename);
        
        $.ajax({
            type    :   "POST",
            url     :   datatable_url,
            data    :   {_token: token,'app_id':app_id,'app_token':app_token,'module_id':sectionID},
            success: function(data) {
                if(data.Status == 1){
                    var errorHtml  =   '';
                    if(data.submoduledata.length >=1){
                        $.each(data.submoduledata, function( key, value ) {
                            var innerstyle  =   '<tr id="deletesectionrow_'+value.sub_module_id+'">';
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.sub_module_id+'">'+value.sub_module_name+'</td>';
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.sub_module_id+'">'+value.sub_description+'</td>';
                            if(value.is_active == 1){
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.sub_module_id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                            }else{
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.sub_module_id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
                            }
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.sub_module_id+'">'+value.created_at+'</td>';
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.sub_module_id+'"><a onClick="editModuleinfo('+value.sub_module_id+','+"'"+value.sub_module_name+"'"+','+"'"+value.sub_description+"'"+','+"'"+value.created_at+"'"+','+value.is_active+')" id="editSection_'+value.sub_module_id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
                            innerstyle  +=  ' <a onClick=removeModule('+value.sub_module_id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
                            errorHtml   +=  innerstyle+'</tr>';
                       });
                    }else{
                        errorHtml   +=  "<tr class='colspan=5'><th>No Products</th></tr>";
                    }   
                    $('#sudmoduledata').html(errorHtml);
                }else{
                   $.notify(data.Message,'error');
                }
           }
       });
    }
    
    var statusenum      =   <?php echo $statusdetails; ?>;
            
    function editModuleinfo(id,sub_module_name,sub_description,created_at,is_active){
        $(".hidesectionrow_"+id).remove();
        var innerstyle  =   '';
        var option      =   '';
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><input class="form-control required_field updatevalidation_'+id+'" type="text" id="sub_module_name_'+id+'" value="'+sub_module_name+'"></td>'
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><input class="form-control required_field updatevalidation_'+id+'" type="text" id="sub_description_'+id+'" value="'+sub_description+'"></td>'
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><select class="form-control required_field updatevalidation_'+id+'" type="text" id="sub_status_'+id+'"><option value="">--Select--</option>';
        $.each(statusenum,function(key,statusval)
        {
            option  +=  '<option value="'+statusval.status_id+'">'+statusval.status_enum_name+'</option>';
        });
        
        innerstyle  +=  option+'</select></td>'    
        innerstyle  +=  '<td class="undosectionrow_'+id+'">'+created_at+'</td>'    
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><button onClick="updatesubmodule('+id+')" type="submit" class="btn btn-primary btn-xs"><i class="fa fa-save"> </i> update</button> <button onClick="undosubmodule('+id+','+"'"+sub_module_name+"'"+','+"'"+sub_description+"'"+','+"'"+created_at+"'"+','+is_active+')" type="submit" class="btn btn-primary btn-xs"><i class="fa fa-fw fa-undo"> </i> undo</button></td>';
        $("#deletesectionrow_"+id).append(innerstyle);
        $("#sub_status_"+id).val(is_active);
    }
    
    
    function undosubmodule(id,sub_module_name,sub_description,created_at,is_active){
        $(".undosectionrow_"+id).remove();
        var innerstyle  =   '';
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'">'+sub_module_name+'</td>';
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'">'+sub_description+'</td>';
        if(is_active == 1){
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
        }else{
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
        }
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'">'+created_at+'</td>';
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'"><a onClick="editModuleinfo('+id+','+"'"+sub_module_name+"'"+','+"'"+sub_description+"'"+','+"'"+created_at+"'"+','+is_active+')" id="editSection_'+id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
        innerstyle  +=  ' <a onClick=removeModule('+id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
        $("#deletesectionrow_"+id).append(innerstyle);
    }
    
    function updatesubmodule(id){
        var url   =   <?php echo "'".url('api/submenu/addModule/update')."'"; ?>;
        var sub_module_name     =   $("#sub_module_name_"+id).val();
        var sub_description     =   $("#sub_description_"+id).val();
        var sub_status          =   $("#sub_status_"+id+" :selected").val();
        $('.updatevalidation_'+id).removeClass('val-error');
        var validation  =   true;
        $('.updatevalidation_'+id).each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   {_token: token,'app_id':app_id,'app_token':app_token,'module_id':$("input[name='module_id']").val(),'sub_module_id':id,'sub_module_name':sub_module_name,'sub_description':sub_description,'status_enum':sub_status};
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }else{
                        if(data.SubModuledata !== 'undefined'){
                            var innerstyle   =   '';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'">'+data.SubModuledata.sub_module_name+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'">'+data.SubModuledata.sub_description+'</td>';
                            if(data.SubModuledata.is_active == 1){
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                            }else{
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
                            }
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'">'+data.SubModuledata.created_at+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.sub_module_id+'"><a onClick="editModuleinfo('+data.SubModuledata.sub_module_id+','+"'"+data.SubModuledata.sub_module_name+"'"+','+"'"+data.SubModuledata.sub_description+"'"+','+"'"+data.SubModuledata.created_at+"'"+','+data.SubModuledata.is_active+')" id="editSection_'+data.SubModuledata.sub_module_id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
                            innerstyle  +=  ' <a onClick=removeModule('+data.SubModuledata.sub_module_id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
                            $(".undosectionrow_"+id).remove();
                            $("#deletesectionrow_"+id).append(innerstyle);
                        }
                        
                        $.notify(data.Message,'success');
                    }
                }
           });
        }
    }
    
    
    $( "#DeleteSection" ).click(function() {   //Update      
        var formData    =   $( "#DeleteSectionForm" ).serialize();
        var url         =   $( "#DeleteSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#DeleteSectionForm .required_field').each(function(index){
            var value   =   $(this).val();
            value       =   value.trim();
            if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });

        if(validation  ==  true){
           var postdata    =   formData;
           $.ajax({
               type    :   "DELETE",
               url     :   url,
               data    :   postdata,
               success: function(data) {
                   if(data.Status == 1){
                       $.notify(data.Message,'success');
                       sectionListReload(); 
                       $('#modal-delete').trigger('click');
                   }else{
                       $.notify(data.Message,'danger');
                   }
               }
           });
        }
    });
    
    function removeModule(id){
        var confirmdelete     =   confirm("Are you sure you want to delete !");
        if(confirmdelete  ==  true){
            var url     =   <?php echo "'".url('api/submenu/moduleDelete')."'"; ?>;
            var postdata    =   {'app_id':app_id,'app_token':app_token,'sub_module_id':id};
            $.ajax({
                type    :   "DELETE",
                url     :   url,
                data    :   postdata,
                success: function(data) {
                    if(data.Status == 1){
                        $("#deletesectionrow_"+id).remove();
                        $.notify(data.Message,'success');
    //                    $('#modal-delete').trigger('click');
                    }else{
                        $.notify(data.Message,'danger');
                    }
                }
            });
        }
    }
    
</script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
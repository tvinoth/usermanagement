<!-- /.content-wrapper -->
<footer class="main-footer">
    <strong>Copyright &copy; <?php echo e(date('Y')); ?>

        <a target="_blank" href="http://www.spi-global.com/">www.spi-global.com</a>.</strong>
    All rights reserved.
</footer>
<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
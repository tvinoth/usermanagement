<?php $__env->startSection('content'); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b><?php echo e($modulename); ?></b></small></h1>
            <ol class="breadcrumb">
            <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="<?php echo e(url('product/productdetails')); ?>"> Product</a></li>
            </ol>
        </section>
        <!--<section class="">
            <div class="col-sm-10"></div>
            <div class="col-sm-2">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-info">
                    <i class="fa fa-user-plus"> </i> ADD USER
                </button>
            </div>
        </section><br><br>-->
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class="active"><a href="#all_data" data-toggle="tab">Product</a></li>
                    <li class="disabled"><a href="#">Modules</a></li>
                    <li class="disabled"><a href="#">Roles</a></li>
                    <li class="disabled"><a href="#">User Access</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">    
                        <div class="row">
                        <form method="POST" action="<?php echo e(url('api/product/addProduct')); ?>" id="SectionForm" accept-charset="UTF-8" class="form-horizontal" role="form" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                            <section class="col-lg-6 connectedSortable">
                                <div class=""><div id="roll" class="list-group"><p href="#" class="list-group-item disabled">Primary Info</p></div>
                                        <div class="box-body">
                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Product Name <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" name="product_name" type="text">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>

                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Product Owner <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" required="true" name="product_owner" type="text">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>

                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">UAT Link <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" required="true" name="product_uat_url" type="url">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>


                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Live Link <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" required="true" name="product_live_url" type="url">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>
                                    
                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Description</label>
                                                <div class="col-lg-10">
                                                <textarea id="editor1" name="description" rows="10" cols="80">
                                                </textarea>
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>


                                            <div class="form-group required">
                                                <label for="field-1" class="col-lg-2 control-label">Product Type <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <select name="product_type[]" class="form-control required_field">
                                                        <option value=""> --Select--</option>
                                                        <?php $__currentLoopData = $productenumtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                             <option value="<?php echo e($value->product_type_enum_id); ?>"><?php echo e($value->product_type_name); ?></option>
                                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="form-group required">
                                                <label for="field-1" class="col-lg-2 control-label">Other Tools Integrated <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <select name="other_tool[]" class="form-control required_field">
                                                        <option value=""> --Select--</option>
                                                        <?php $__currentLoopData = $productdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                             <option value="<?php echo e($value->product_id); ?>"><?php echo e($value->product_name); ?></option>
                                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group required">
                                                <label for="field-1" class="col-lg-2 control-label">Role<span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <select name="product_role[]" class="form-control required_field">
                                                        <option value=""> --Select--</option>
                                                        <?php $__currentLoopData = $productrole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                             <option value="<?php echo e($value->role_id); ?>"><?php echo e($value->name); ?></option>
                                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-lg-2 control-label">Product Logo <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input type="file" accept=".jpg,gif,png,jpeg" id="uploaduserimage" class="form-control required_field" name="product_logo">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="col-lg-5"></div>
                                                <div class="col-lg-5">
                                                    <center><img src="<?php echo e(url('assets/dist/img/empty-user.jpg')); ?>" id="previewuploaduserimage"  class="img-circle" alt="Product Image" style="width:15%;height:15%"></center>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </section>
                                
                            <section class="col-lg-6 connectedSortable">
                                <div class=""><div id="roll" class="list-group"><p href="#" class="list-group-item disabled">Secondary Info</p></div>
                                <div class="box-body">
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Version <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <input id="lname" class="form-control required_field" maxlength="150" required="true" name="version" type="text">
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">User Engaged <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <input class="form-control required_field" maxlength="150" required="true" name="user_engaged" type="text">
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Manufacture <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select class="form-control required_field" required="true" name="manufacture[]">
                                            <option value="">--Select--</option>
                                                <?php $__currentLoopData = $hierarchy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <option value="<?php echo e($value->hierarchy_id); ?>"><?php echo e($value->hierarchy_name); ?>

                                                     </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Developed By <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select class="form-control required_field" required="true" name="developedby[]">
                                            <option value="">--Select--</option>
                                                <?php $__currentLoopData = $productowner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <option data-contactemail="<?php echo e($value->email); ?>" value="<?php echo e($value->USER_ID); ?>"><?php echo e($value->USER_NAME); ?>

                                                     </option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Contact <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <textarea class="form-control required_field" rows="3" name="contact" placeholder="Product contact ..."></textarea>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label for="field-1" class="col-lg-2 control-label">Technology <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select name="technology[]" class="form-control required_field">
                                                <option value=""> --Select--</option>
                                                <?php $__currentLoopData = $ProductTechnologyModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <option value="<?php echo e($value->technology_id); ?>"><?php echo e($value->name); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Account Usage Details <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select class="form-control required_field" required="true" name="access_usage[]">
                                            <option value="">--Select--</option>
                                                <?php $__currentLoopData = $hierarchy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <option value="<?php echo e($value->hierarchy_id); ?>"><?php echo e($value->hierarchy_name); ?>

                                                     </option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Keywords</label>
                                        <div class="col-lg-10">
                                            <textarea class="form-control" rows="3" name="keywords" placeholder="Product Keywords ..."></textarea>
                                        </div>
                                    </div>

                                    <input type="hidden" name="app_id" value="<?php echo e($productdata['app_id']); ?>">
                                    <input type="hidden" name="app_token" value="<?php echo e($productdata['app_token']); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                    
                                    <div class="form-group row">
                                        <div class="col-lg-2"></div>
                                        <div class="col-lg-2">
                                            <a href="<?php echo e(url('product/productdetails')); ?>"><button type="button" class="btn btn-warning pull-left"><i class="fa fa-fw fa-backward"></i> Back</button></a>
                                        </div>
                                        <div class="col-lg-2">
                                            <button type="submit" class="btn btn-primary" id="AddSection">  <i class="fa fa-fw fa-check"> </i> Create Product</button>
                                        </div>
                                        <div class="col-lg-4"></div>
                                    </div>
                                </div>
                            </div>
                        </section>        
                    </form>
                </div>
            </div>
                    
                    
            </div>
        </div>
    </section>
</div>
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomScripts'); ?>
<script src="<?php echo e(url('assets/bower_components/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<script>
//    var     dataProductId  =   "eyJpdiI6Im5GY2MyTDBmMFB6aFNBM2RcL01UVWFnPT0iLCJ2YWx1ZSI6IkdscjJmblhWdDIyYXhKeUNvZHJtYmc9PSIsIm1hYyI6ImE3M2I0ODIzOGE5MTE3MGRiODNjZmVkM2QyMDIwNDEwNTNmNDZiOTY3YzZjMjFiNjJhNTJjMTIxZGI0ZGYzNDEifQ==";
////    var urla     =   "product/editproduct/"+dataProductId;
//
////    window.location.href    =   '<?php echo e(url("product/editproduct/'+dataProductId+'")); ?>';
//    
    $("select[name='developedby[]']").change(function()
    {
        $("input[name='contact']").val($(this).find(':selected').attr('data-contactemail'));
    });

    var token           =   <?php echo "'".csrf_token()."'"; ?>;
    var app_id          =   <?php echo "'".$productdata['app_id']."'"; ?>;
    var app_token       =   <?php echo "'".$productdata['app_token']."'"; ?>;

    var imageuploaddata     =   "";
    
    function readURL(input, previewtype) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                if (previewtype == 1)
                    $('#previewuploaduserimage').attr('src', e.target.result);
                else
                    $('#updatepreviewimage').attr('src', e.target.result);
                imageuploaddata     =   e.target.result;
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#uploaduserimage").change(function () {
        readURL(this, 1);
    });

    $("#updateuserimage").change(function () {
        readURL(this, 2);
    });
    
    $(function () {
        CKEDITOR.replace('editor1');
        $('.textarea').wysihtml5();
    });
    
    $( "#AddSection" ).click(function(e) {
        e.preventDefault();
        var ContentFromEditor1  =   CKEDITOR.instances.editor1.getData();
        var url         =   $( "#SectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        
        var formData    =   new FormData($( "#SectionForm" )[0]);
        formData.append('description',ContentFromEditor1);
        var url         =   $( "#SectionForm" ).attr('action');    
        validation = true;
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,                
                async   : false,
                cache   : false,
                contentType: false,
                processData: false,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }else{
                        var encrypt     =   data.ProductId;
                        var     dataProductId    =   '<?php echo url("product/editproduct/'+encrypt+'"); ?>';
                        window.location.href    =   dataProductId;
                        $.notify(data.Message,'success');
                    }
                }
           });
        }
    });
</script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
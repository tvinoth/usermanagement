<?php $__env->startSection('content'); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b><?php echo e($modulename); ?></b></small></h1>
            <ol class="breadcrumb">
            <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="<?php echo e(url('usermanagement')); ?>"> Users </a></li>
            </ol>
        </section>
        <!--<section class="">
            <div class="col-sm-10"></div>
            <div class="col-sm-2">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-info">
                    <i class="fa fa-user-plus"> </i> ADD USER
                </button>
            </div>
        </section><br><br>-->
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class="active"><a href="#all_users" data-toggle="tab">All Users</a></li>
                    <li class=""><a href="#new_users" data-toggle="tab">New User</a></li>
                    <li class="taggleusertab" style="display:none" id="showupdate_users"><a href="#update_user" data-toggle="tab">Update User <span id='usernamedisplay'></span></a></li>
                    <li class="taggleusertab" style="display:none" id="showview_users"><a href="#view_user" class="showview_users" data-toggle="tab">View User<span id='viewusername'></span></a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_users">    
                        <div class="box-body">
                            <table id="userList" class="table table-bordered table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th>Emp ID</th>
                                        <th>User Name</th>
                                        <th>Team</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>      
                                </tbody>    
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="new_users">
                        <br>
                        <form method="POST" action="<?php echo e(url('api/doCreateUser')); ?>" id="SectionForm" accept-charset="UTF-8" class="form-horizontal" role="form" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group required">
                                <label for="fname" class=" col-lg-3 control-label company-label">First Name</label>
                                <div class="col-lg-5">
                                    <input id="fname" class="form-control required_field" maxlength="150" name="first_name" type="text">
                                    <span class="text-danger"></span>
                                </div>
                            </div>

                            <div class="form-group required">
                                <label for="lname" class=" col-lg-3 control-label company-label">Last Name</label>
                                <div class="col-lg-5">
                                    <input id="lname" class="form-control required_field" maxlength="50" required="true" name="last_name" type="text">
                                    <span class="text-danger"></span>
                                </div>
                            </div>

                            <div class="form-group required">
                                <label for="email" class=" col-lg-3 control-label company-label">Email</label>
                                <div class="col-lg-5">
                                    <input id="email" class="form-control required_field" maxlength="60" required="true" name="email" type="email">
                                    <span class="text-danger"></span>
                                </div>
                            </div>

                            <div class="form-group required">
                                <label for="name" class=" col-lg-3 control-label company-label">Employee Id</label>
                                <div class="col-lg-5">
                                    <input id="name" class="form-control required_field" maxlength="50" required="true" name="emp_id" type="text">
                                    <span class="text-danger"></span>
                                </div>
                            </div>

                            <div class="form-group required">
                                <label for="password" class=" col-lg-3 control-label company-label">Password</label>
                                <div class="col-lg-5">
                                    <input id="password" class="form-control required_field" maxlength="50" required="true" name="password" type="password" value="">
                                    <span class="text-danger"></span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="eselect_role" class=" col-lg-3 control-label">Employee Type</label>
                                <div class="col-lg-5">
                                <select id="eselect_role" class="form-control required_field" name="emp_type">
                                    <option value="">--Select Type--</option>
                                    <?php $__currentLoopData = $emptype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->emplyoee_type_id); ?>"> <?php echo e($value->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger"></span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="select_role" class="col-lg-3 control-label">Employee Team</label>
                                <div class="col-lg-5">
                                <select id="select_role" class="form-control required_field" name="emp_team">
                                    <option value="">--Select Team--</option>
                                    <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->hierarchy_id); ?>"> <?php echo e($value->hierarchy_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger"></span>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                    <label for="inputEmail3" class="col-lg-3 control-label">Photo</label>
                                    <div class="col-lg-5">
                                        <input type="file" accept=".jpg,gif,png,jpeg" id="uploaduserimage" class="form-control required_field" name="upload_profile">
                                    </div>
                            </div>
                            <div class="form-group">
                                    <div class="col-lg-5">
                                    </div>
                                    <div class="col-lg-5">
                                        <center><img src="<?php echo e(url('assets/dist/img/empty-user.jpg')); ?>" id="previewuploaduserimage"  class="img-circle" alt="User Image" style="width:15%;height:15%"></center>
                                    </div>
                            </div>
                            
                            <input type="hidden" name="app_id" value="fsafr">
                            <input type="hidden" name="app_token" value="fsa5685t">
                            <input type="hidden" name="ip_address" value="172.24.183.332">
                            <div class="form-group row">
                                <div class="col-lg-4"></div>
                                <div class="col-lg-1">
                                    <!--<button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>-->
                                </div>
                                <div class="col-lg-1">
                                    <button type="submit" class="btn btn-primary" id="AddSection">  <i class="fa fa-user-plus"> </i> Create User</button>
                                </div>
                                <div class="col-lg-4"></div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-5 col-lg-offset-3">
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade removeshowactive" id="update_user">
                        <br>
                        
                        
                    </div>
                    
                    <div class="tab-pane fade removeshowactive" id="view_user">
                        <br>
                        
                        
                    </div>
                </div>
            </div>
        </section>
    </div>


        <div class="modal fade in" id="modal-edit">
            <div class="modal-dialog">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Update User</h4>
                    </div>
                    <div class="modal-body">
                        <!-- Horizontal Form -->
                        <div class="card card-info">
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form class="form-horizontal">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">First Name</label>

                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" value="Admin" placeholder="First Name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Last Name</label>

                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" value="A" placeholder="Last Name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Emp ID</label>

                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" value="22002" placeholder="Employee ID">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Emp E-Mail</label>

                                        <div class="col-sm-10">
                                            <input type="email" class="form-control" value="Admin@spi-global.com" placeholder="Employee Mail">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Employee Team</label>
                                        <div class="col-sm-10">
                                            <select class="form-control">
                                                <option>--Select Team--</option>
                                                <option value="2" selected>Spinger</option>
                                                <option>Health</option>
                                                <option>OPS</option>
                                                <option>EPS</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Employee Type</label>
                                        <div class="col-sm-10">
                                            <select class="form-control">
                                                <option>--Select Type--</option>
                                                <option>SPI User</option>
                                                <option value="2" selected>Freelancer</option>
                                                <option>Others</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Photo</label>
                                        <div class="col-sm-4">
                                            <input type="file" id="updateuserimage" class="form-control" name="userimage">
                                        </div>
                                        <div class="col-sm-6">
                                            <center><img src="<?php echo e(url('assets/dist/img/empty-user.jpg')); ?>" id="updatepreviewimage"  class="img-circle" alt="User Image" style="width:15%;height:15%"></center>
                                        </div>
                                    </div>

                                </div>
                                <!-- /.card-footer -->
                            </form>
                        </div>
                        <div class="modal-footer">

                            <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                            <button type="button" class="btn btn-primary"> <i class="fa fa-save"> </i> Save Changes</button>
                        </div>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog ">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header deletemodal">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Delete User</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo e(url('api/doUserDelete')); ?>" method="post" id="DeleteSectionForm">   
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="col-md-12">
                          <div class="form-group required">
                            <input type="hidden" id="userId" name="user_id" >
                            <input type="hidden" id="appId" name="app_id" >
                            <input type="hidden" id="appToken" name="app_token" >
                            <input type="hidden" id="ip_address" name="ip_address" value="172.24.183.33">
                          </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </form>
                    <div class="modal-body">
                        Are you sure you want to delete a <b><span id='username'></span></b>?

                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                        <button type="button" class="btn btn-danger" id="DeleteSection"><i class="fa fa-user-times"></i> Confirm Delete</button>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomScripts'); ?>
<script type="text/javascript">
    var imageuploaddata     =   "";
    function readURL(input, previewtype) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                if (previewtype == 1)
                    $('#previewuploaduserimage').attr('src', e.target.result);
                else
                    $('#updatepreviewimage').attr('src', e.target.result);
                imageuploaddata     =   e.target.result;
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#uploaduserimage").change(function () {
        readURL(this, 1);
    });

    $("#updateuserimage").change(function () {
        readURL(this, 2);
    });
</script>

<script>
    $(document).ready(function()
    {
        $(document).on('click','#usertabmenuactivity',function () {
            if($("#usertabmenuactivity li:visible").length >2 ){
                $(".taggleusertab").each(function(){
                    $(this).hide();
                });
		$(".removeshowactive").removeClass('show active in');
            }
        });
    });
     
var datatable_url   =   <?php echo "'".url('api/doGetUserList')."'"; ?>;
var token           =   <?php echo "'".csrf_token()."'"; ?>;

$.fn.dataTable.ext.errMode  =   'none';
var sectionList     =   $('#userList').DataTable({
            "fixedHeader": true,
            "processing": true,
            "serverSide": true,
                ajax: {
                        url: datatable_url,
                        type: 'POST',
                        'data': {
                            _token: token,
                        },
                    },
                    "initComplete": function(settings, json) {
//                    console.log(json);
                    },
            "order": [[ 1, "desc" ]],
            fixedHeader: {
                header: true,
                footer: true
            }
        });



    function sectionListReload(){
        sectionList.clear().draw();
    }
    
    function viewUserinfo(id,thisdata)
    {
        var methodtype  =   $(thisdata).attr('data-type');
        $('#usertabmenuactivity').find('li').each(function(e){
            $(this).removeClass('active'); 
        });
        $('div.tab-pane').each(function(){
            $(this).removeClass('in show active');
        });
        if(methodtype   ==  "update"){
            $("#showupdate_users").css('display','block');
            $("#showupdate_users").addClass('active');
            $("#update_user").addClass('in show active');
        }else{
            $("#showview_users").css('display','block');
            $("#showview_users").addClass('active');
            $("#view_user").addClass('in show active');
        }
          
          
        var postdata    =   {'app_id':10,'app_token':'25156','user_id':id,'methodtype':methodtype};
        $.ajax({
            type    :   "POST",
            url     :   '<?php echo e(url("api/doViewUserInfo")); ?>',
            dataType:   "html",
            data    :   postdata,
            success: function(data) {
                if(methodtype   ==  "update")
                $("#update_user").html(data);
                else
                $("#view_user").html(data);
            }
        });
    }
    
    $( "#AddSection" ).click(function(e) {    // Add     
        e.preventDefault();
//        var formData    =   $( "#SectionForm" ).serialize();
//        formData.push('upload_profile',imageuploaddata);
        var formData    =   new FormData($( "#SectionForm" )[0]);
//        formData        =   formData+'&upload_profile='+imageuploaddata;
        var url         =   $( "#SectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                
        async: false,
        cache: false,
        contentType: false,
        processData: false,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }
                    $.notify(data.Message,'success');
                    sectionListReload();
                }
           });
        }
    });
    
    // delete
    $( "div" ).on( "click", ".deleteSection", function() {
        var id          =   this.id;
        var username    =   $(this).data('deleteusername');
        var sectionID   =   id.replace("deleteSection_", "");
        $("#userId").val(sectionID);
        $("#appId").val('fertert');
        $("#appToken").val('fe2652');
        $("#username").text(username);
    });
     
    $( "#DeleteSection" ).click(function() {   //Update      
        var formData    =   $( "#DeleteSectionForm" ).serialize();
        var url         =   $( "#DeleteSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#DeleteSectionForm .required_field').each(function(index){
            var value   =   $(this).val();
            value       =   value.trim();
            if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });

        if(validation  ==  true){
           var postdata    =   formData;
           $.ajax({
               type    :   "DELETE",
               url     :   url,
               data    :   postdata,
               success: function(data) {
                   if(data.Status == 1){
                       $.notify(data.Message,'success');
                       sectionListReload(); 
                       $('#modal-delete').trigger('click');
                   }
                   $.notify(data.Message,'danger');
               }
           });
        }
    });
</script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
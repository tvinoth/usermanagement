
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <?php if(auth()->guard()->guest()): ?>
            <div class="pull-left image">
                <img src="<?php echo e(url('assets/dist/img/avatar5.png')); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p>Guest</p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            <div class="pull-left image">
                <img src="<?php echo e(url('assets/dist/img/avatar5.png')); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
            <?php endif; ?>
        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li><a href="<?php echo e(url('admindashboard')); ?>"><i class="fa fa-fw fa-user-secret"></i> Admin Dashboard</a></li>
                    <li class="active"><a href="<?php echo e(url('userdashboard')); ?>"><i class="fa fa-fw fa-dashcube"></i> User Dashboard</a></li>
                    
                </ul>
            </li>
            <li class="">
                <a href="<?php echo e(url('usermanagement')); ?>">
                    <i class="fa fa-user"></i> <span>User Management</span>
                </a>
            </li>
            <li class="active">
                <a href="<?php echo e(url('hierarchymanagement')); ?>">
                    <i class="fa fa-fw fa-hand-lizard-o"></i> <span>Hierarchy Management</span>
                </a>
            </li>
            <!--<li class="treeview">
                <a href="#">
                    <i class="fa fa-fw fa-wrench"></i> <span>Account Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li><a href="<?php echo e(url('usermanagement')); ?>"><i class="fa fa-fw fa-group"></i> EG Management</a></li>
                    <li class="active"><a href="<?php echo e(url('userdashboard')); ?>"><i class="fa fa-fw fa-cloud"></i> Cluster Management</a></li>
                    <li class="active"><a href="<?php echo e(url('userdashboard')); ?>"><i class="fa fa-fw fa-steam"></i> Team Management</a></li>
                </ul>
            </li>-->
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-cogs"></i> <span>App Setting's</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li class="active"><a href="<?php echo e(url('emptypemanagement')); ?>"><i class="fa fa-fw fa-users"></i> Employee Type Management</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-cogs"></i> <span>Product Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li><a href="<?php echo e(url('product/productdetails')); ?>"><i class="fa fa-cogs"></i> Product Details</a></li>
                    <li><a href="<?php echo e(url('menu/module')); ?>"><i class="fa fa-cogs"></i> Module</a></li>
                    <li><a href="<?php echo e(url('menu/submodule')); ?>"><i class="fa fa-cogs"></i> Sub Module</a></li>
                </ul>
            </li>
            <li class="">
                <a href="<?php echo e(url('rolemanagement')); ?>">
                    <i class="fa fa-fw fa-child"></i> <span>Roles Management</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>

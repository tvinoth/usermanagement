<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Models\MenuManagement as MenuModel;
use Config;

class Controller extends BaseController {

    use AuthorizesRequests,
        DispatchesJobs,
        ValidatesRequests;

    protected $notdeletedStatus;
    protected $deletedStatus;
    protected $activeStatus;
    protected $inActiveStatus;
    protected $productselfId;
    protected $dashBoard;
    protected $adminDashboard;
    protected $userDashboard;
    protected $productModule;
    protected $HierarchyModule;
    protected $appSettingModule;
    protected $empTypeModule;
    protected $roleModule;

    public function __construct() {
        $this->productselfId = Config::get('constants.products.self');
        $this->notdeletedStatus = Config::get('constants.STATUS_ENUM.NOT_DELETED');
        $this->deletedStatus = Config::get('constants.STATUS_ENUM.DELETED');
        $this->activeStatus = Config::get('constants.STATUS_ENUM.ACTIVE');
        $this->inActiveStatus = Config::get('constants.STATUS_ENUM.INACTIVE');
        $this->productModule = Config::get('constants.module.productModule');
        $this->userModule = Config::get('constants.module.UserModule');
        $this->dashBoard = Config::get('constants.module.dashBoard');
        $this->adminDashboard = Config::get('constants.module.adminDashboard');
        $this->userDashboard = Config::get('constants.module.userDashboard');
        $this->HierarchyModule = Config::get('constants.module.HierarchyModule');
        $this->appSettingModule = Config::get('constants.module.appSettingModule');
        $this->empTypeModule = Config::get('constants.module.empTypeModule');
        $this->roleModule = Config::get('constants.module.roleModule');
    }

    public function doAppNameConvertion($type, $name) {
        switch ($type) {
            case 1:
                $namecase = strtoupper($name);
                break;
            case 2:
                $namecase = strtolower($name);
                break;
            case 3:
                $namecase = ucfirst($name);
                break;
            case 4:
                $namecase = ucwords($name);
                break;
            default:
                $namecase = ucwords($name);
                break;
        }
        return $namecase;
    }

    public function modulecodegeneration($prdid, $productinfo, $modulename, $records) {
        $newcode = "";
        if ($records != null) {
            $incrementid = str_pad($records->module_id + 1, 2, 0, STR_PAD_LEFT);
            $newcode = self::explodeConvertion($records->module_code);
        } else {
            $incrementid = str_pad(1, 2, 0, STR_PAD_LEFT);
            $newcode = str_pad(1, 2, 0, STR_PAD_LEFT);
        }
        //one of the format
        /* $allmodulecode      =   MenuModel\ModuleModel::all();
          $newArray           =   $allmodulecode->pluck('module_code')->toArray();
          $expldArray         =   [];
          if(count($newArray)>=1){
          foreach($newArray as $key=>$value){
          if(strpos($value,'-') !== 	false){
          $Array  =   explode('-',$value);
          $expldArray[]   =    $Array[1];
          }
          }
          }
          $maxofvalue     =   max($expldArray)+1; */
        $prdname = $productinfo->product_name;
        $prdshrtname = strtoupper($productinfo->product_short_name);
        $prdname = self::getSinglestring($prdname);
        $modulename = self::getSinglestring($modulename);
        $newmodulecode = $prdname . '' . $modulename . $prdshrtname . $incrementid . '-' . $newcode;
        $wheredata = ['product_id' => $prdid, 'module_code' => $newmodulecode];
        $allmodulecode = MenuModel\ModuleModel::where($wheredata)->first();
        if ($allmodulecode != null) {
            $newcode = self::explodeConvertion($allmodulecode->module_code);
            $incrementid = str_pad($newcode + 1, 2, 0, STR_PAD_LEFT);
            $newmodulecode = $prdname . '' . $modulename . $prdshrtname . $incrementid . '-' . $newcode;
            return $newmodulecode;
        }
        return $newmodulecode;
    }

    public function submodulecodegeneration($moduleid, $productinfo, $modulename, $records) {
        $newcode = "";
        if ($records != null) {
            $incrementid = str_pad($records->module_item_id + 1, 2, 0, STR_PAD_LEFT);
            $newcode = self::explodeConvertion($records->module_item_code);
        } else {
            $incrementid = str_pad(1, 2, 0, STR_PAD_LEFT);
            $newcode = str_pad(1, 2, 0, STR_PAD_LEFT);
        }

        $prdname = $productinfo->product_name;
        $prdshrtname = strtoupper($productinfo->product_short_name);
        $prdname = self::getSinglestring($prdname);
        $modulename = self::getSinglestring($modulename);
        $newmodulecode = $prdname . '' . $modulename . $prdshrtname . $incrementid . '-' . $newcode;
        $wheredata = ['module_id' => $moduleid, 'module_item_code' => $newmodulecode];
        $allmodulecode = MenuModel\ModuleItemsModel::where($wheredata)->first();
        if ($allmodulecode != null) {
            $newcode = self::explodeConvertion($allmodulecode->module_item_code);
            $incrementid = str_pad($newcode + 1, 2, 0, STR_PAD_LEFT);
            $newmodulecode = $prdname . '' . $modulename . $prdshrtname . $incrementid . '-' . $newcode;
            return $newmodulecode;
        }
        return $newmodulecode;
    }

    public function explodeConvertion($code) {
        $newcode = "";
        if (strpos($code, '-') !== false) {
            $Array = explode('-', $code);
            $newcode = str_pad($Array[1] + 1, 2, 0, STR_PAD_LEFT);
        } else {
            $newcode = str_pad(1, 2, 0, STR_PAD_LEFT);
        }
        return $newcode;
    }

    public function getSinglestring($string) {
        return strtoupper(substr($string, 0, 1));
    }

}

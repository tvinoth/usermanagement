<?php

namespace App\Http\Controllers\usermanagement;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Session;
use App\Models\UsermanagementModel;
use App\Models\EmployeeTypeModel;
use App\Models\MenuManagement as MenuModel;
use App\Models\HierarchyManagement\HierarchyModel;
use App\Models\Products as PRDModel;
use Config;
use Illuminate\Support\Facades\View;

class UserManagementController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        View::share('parentname', 'User Management');
        View::share('childname', '');
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $team       =   HierarchyModel::Active()->get();
        $emptype    =   EmployeeTypeModel::Active()->get();
        $modulename     =   MenuModel\ModuleModel::find($this->userModule);
        if($modulename !=   null){
            $modulename     =   $this->doAppNameConvertion($modulename->module_type,$modulename->module_name);
        }        
        $productid      =   $this->productselfId;
        $productdata['app_id']    =   '';
        $productdata['app_token'] =   '';
        $productinfo    =   PRDModel\ProductModel::find($productid);
        $productdetails =   PRDModel\ProductModel::Active()->get();
        if($productinfo !=  null)
        $productdata['app_id']    =   $productinfo->product_app_id;
        $productdata['app_token'] =   $productinfo->product_token;    
        return view('usermanagement.usermanagement')->with(compact('emptype','team','modulename','productdata'));
    }
}

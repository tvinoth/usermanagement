<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\User;
use App\Models\MenuManagement as MenuModel;
use Session;
use Illuminate\Support\Facades\View;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        View::share('parentname', 'Dashboard');
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        View::share('childname', 'Admin Dashboard');
        $userinfo   =   User::getUserInfo(Auth::user()->id);
        if($userinfo != null){
        }
        $modulename     =   MenuModel\ModuleModel::find('1');
        if($modulename !=   null){
            $modulename     =   $this->doAppNameConvertion($modulename->module_type,$modulename->module_name);
        }
        return view('dashboard.admindashboard')->with(compact('modulename'));
    }
}

<?php

namespace App\Http\Controllers\accountmanagement\eg_management;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Session;
use App\Models\UsermanagementModel;

class EgManagementController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
//        $userdetails    =   UsermanagementModel::getUserfullInfo();
//        return view('usermanagement.usermanagement')->with(compact('userdetails'));
                return view('usermanagement.usermanagement');
    }
    
    public function view()
    {
//        $userdetails    =   UsermanagementModel::getUserfullInfo();
//        return view('usermanagement.usermanagement')->with(compact('userdetails'));
                return view('usermanagement.viewuserinfo');
    }
}

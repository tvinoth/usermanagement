<?php

namespace App\Http\Controllers\ProductManagement;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\User;
use App\Models\MenuManagement as MenuModel;
use App\Models\Products as PRDModel;
use App\Models\ModuleTypeEnumModel;
use App\Models\RolesModel;
use App\Models\StatusEnumModel;
use App\Models\TechnologyModel;
use Illuminate\Support\Facades\Crypt;
use App\Models\HierarchyManagement\HierarchyModel;
use Session;
use Carbon\Carbon;
use Validator;
use DB;
use Config;
use Illuminate\Support\Facades\View;

class ProductController extends Controller {

    public function __construct() {
        parent::__construct();
        View::share('parentname', 'Product Management');
        $this->middleware('auth');
    }

    public function index() {
        View::share('childname', 'Product Details');
        $modulename = MenuModel\ModuleModel::find($this->productModule);
        if ($modulename != null) {
            $modulename = $this->doAppNameConvertion($modulename->module_type, $modulename->module_name);
        }
        $productid = $this->productselfId;
        $productdata['app_id'] = '';
        $productdata['app_token'] = '';
        $productinfo = PRDModel\ProductModel::find($productid);
        if ($productinfo != null)
            $productdata['app_id'] = $productinfo->product_app_id;
        $productdata['app_token'] = $productinfo->product_token;
        return view('ProductManagement.index')->with(compact('modulename', 'productdata'));
    }

    public function addproduct() {
        View::share('childname', 'Product Details');
        $modulename = MenuModel\ModuleModel::find($this->productModule);
        if ($modulename != null) {
            $modulename = $this->doAppNameConvertion($modulename->module_type, $modulename->module_name);
        }
        $productid = $this->productselfId;
        $productenumtype = PRDModel\ProductTypeEnumModel::Active()->get();
        $hierarchy = HierarchyModel::Active()->get();
        $ProductTechnologyModel = TechnologyModel::Active()->get();
        $productrole = RolesModel::Active()->get();
        $productowner = User::getUserNamelist();
        $productdata['app_id'] = '';
        $productdata['app_token'] = '';
        $productinfo = PRDModel\ProductModel::find($productid);
        $productdetails = PRDModel\ProductModel::Active()->where('product_id', '<>', $productid)->get();
        if ($productinfo != null)
            $productdata['app_id'] = $productinfo->product_app_id;
        $productdata['app_token'] = $productinfo->product_token;
        return view('ProductManagement.addProduct')->with(compact('modulename', 'productdata', 'productrole', 'productenumtype', 'hierarchy', 'ProductTechnologyModel', 'productowner', 'productdetails'));
    }

    public function editproduct($encryptproductID) {
        View::share('childname', 'Product Details');
        $productID = Crypt::decryptString($encryptproductID);
        $productinfo = PRDModel\ProductModel::with(array('productInfo', 'productAccess', 'productContact', 'productDeveloped', 'productKeywords', 'productManufacture', 'productOtherTool', 'productRole', 'productTechnology', 'productTypeSystem'))->find($productID);

        $keywords = "";
        if (count($productinfo->productKeywords) >= 1) {
            foreach ($productinfo->productKeywords as $value) {
                $keywords .= $value->keywords . ',';
            }
            $keywords = rtrim($keywords, ',');
        }

        $contacts = "";
        if (count($productinfo->productContact) >= 1) {
            foreach ($productinfo->productContact as $value) {
                $contacts .= $value->contact_mail . ',';
            }
            $contacts = rtrim($contacts, ',');
        }

        if ($productinfo != '') {
            $modulename = MenuModel\ModuleModel::find($this->productModule);
            if ($modulename != null) {
                $modulename = $this->doAppNameConvertion($modulename->module_type, $modulename->module_name);
            }
            $productid = $this->productselfId;
            $productenumtype = PRDModel\ProductTypeEnumModel::Active()->get();
            $hierarchy = HierarchyModel::Active()->get();
            $ProductTechnologyModel = TechnologyModel::Active()->get();
            $productowner = User::getUserNamelist();
            $productrole = RolesModel::Active()->get();
            $productdata['app_id'] = '';
            $productdata['app_token'] = '';
            $productdetails = PRDModel\ProductModel::Active()->where('product_id', '<>', $productid)->get();
            if ($productinfo != null)
                $productdata['app_id'] = $productinfo->product_app_id;
            $productdata['app_token'] = $productinfo->product_token;
            return view('ProductManagement.editProduct')->with(compact('modulename', 'keywords', 'productrole', 'contacts', 'encryptproductID', 'productdata', 'productinfo', 'productenumtype', 'hierarchy', 'ProductTechnologyModel', 'productowner', 'productdetails'));
        }
        else {
            return redirect('product/addproduct');
        }
    }

    public function productmodule($encryptproductID) {
        View::share('childname', 'Product Details');
        $productID = Crypt::decryptString($encryptproductID);
        $productinfo = PRDModel\ProductModel::find($productID);
        if ($productinfo != '') {
            $modulename = MenuModel\ModuleModel::find($this->productModule);
            if ($modulename != null) {
                $modulename = $this->doAppNameConvertion($modulename->module_type, $modulename->module_name);
            }
            $productid = $this->productselfId;
            $productenumtype = PRDModel\ProductTypeEnumModel::Active()->get();
            $hierarchy = HierarchyModel::Active()->get();
            $ProductTechnologyModel = TechnologyModel::Active()->get();
            $productowner = User::getUserNamelist();
            $statusdetails = StatusEnumModel::Active()->get();
            $productdata['app_id'] = '';
            $productdata['app_token'] = '';
            $productdetails = PRDModel\ProductModel::Active()->where('product_id', '<>', $productid)->get();
            if ($productinfo != null)
                $productdata['app_id'] = $productinfo->product_app_id;
            $productdata['app_token'] = $productinfo->product_token;
            return view('ProductManagement.productModule')->with(compact('modulename', 'statusdetails', 'encryptproductID', 'productdata', 'productinfo', 'productenumtype', 'hierarchy', 'ProductTechnologyModel', 'productowner', 'productdetails'));
        }
        else {
            return redirect('product/addproduct');
        }
    }

    public function productrole($encryptproductID) {
        View::share('childname', 'Product Details');
        $childitem = [];
        $productinfo = [];
        $productID = Crypt::decryptString($encryptproductID);
        $productinfo = PRDModel\ProductModel::with(array('productRole', 'productModule'))->find($productID)->toArray();
        if (count($productinfo) >= 1) {
            if (count($productinfo['product_module']) >= 1) {
                foreach ($productinfo['product_module'] as $parent => $parentvalue) {
                    $productinfo['product_module'][$parent] = MenuModel\ModuleModel::with(array('productModuleItems'))->find($parentvalue['module_id'])->toArray();
                    //check child is added or not
                    $getchilditems = MenuModel\ModuleModel::select(DB::raw('module.module_id'))->where('parent_id', $parentvalue['module_id'])->Active()->get()->toArray();
                    if (count($getchilditems) >= 1) {
                        foreach ($getchilditems as $childkey => $childvalue) {
                            $productinfo['product_module'][$parent]['product_sub_module'][] = MenuModel\ModuleModel::with(array('productModuleItems'))->find($childvalue['module_id'])->toArray();
                        }
                    }
                }
            }
            $encodeinfo = json_encode($productinfo);
            $productinfo = json_decode($encodeinfo);
            $modulename = MenuModel\ModuleModel::find($this->productModule);
            if ($modulename != null) {
                $modulename = $this->doAppNameConvertion($modulename->module_type, $modulename->module_name);
            }
            $productid = $this->productselfId;
            $productdata['app_id'] = '';
            $productdata['app_token'] = '';
            $productdetails = PRDModel\ProductModel::Active()->where('product_id', '<>', $productid)->get();
            if ($productinfo != null)
                $productdata['app_id'] = $productinfo->product_app_id;
            $productdata['app_token'] = $productinfo->product_token;
            return view('ProductManagement.productRole')->with(compact('modulename', 'encryptproductID', 'productdata', 'productinfo', 'productdetails'));
        }
        else {
            return redirect('product/addproduct');
        }
    }

    public function productaccess($encryptproductID) {
        View::share('childname', 'Product Details');
        $productID = Crypt::decryptString($encryptproductID);
        $productinfo = PRDModel\ProductModel::find($productID);
        if ($productinfo != '') {
            $modulename = MenuModel\ModuleModel::find($this->productModule);
            if ($modulename != null) {
                $modulename = $this->doAppNameConvertion($modulename->module_type, $modulename->module_name);
            }
            $productid = $this->productselfId;
            $productenumtype = PRDModel\ProductTypeEnumModel::Active()->get();
            $hierarchy = HierarchyModel::Active()->get();
            $ProductTechnologyModel = TechnologyModel::Active()->get();
            $productowner = User::getUserNamelist();
            $productrole = PRDModel\ProductRoleModuleMapModel::getProductRoleList($productID);
            $productdata['app_id'] = '';
            $productdata['app_token'] = '';
            $productdetails = PRDModel\ProductModel::Active()->where('product_id', '<>', $productid)->get();
            $statusdetails = StatusEnumModel::Active()->get();
            if ($productinfo != null)
                $productdata['app_id'] = $productinfo->product_app_id;
            $productdata['app_token'] = $productinfo->product_token;
            return view('ProductManagement.productAccess')->with(compact('modulename', 'statusdetails', 'productrole', 'encryptproductID', 'productdata', 'productinfo', 'productenumtype', 'hierarchy', 'ProductTechnologyModel', 'productowner', 'productdetails'));
        }
        else {
            return redirect('product/addproduct');
        }
    }

}

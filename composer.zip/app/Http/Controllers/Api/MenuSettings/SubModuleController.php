<?php

namespace App\Http\Controllers\Api\MenuSettings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MenuManagement as MenuModel;
use App\Models\Products as PRDModel;
use App\Models\StatusEnumModel;
use Carbon\Carbon;
use Validator;
use DB;
use Config;

class SubModuleController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
    }

    public function validationRequestRule($type, $moduleId, $moduleitemid, $moduleitemname) {

        Validator::extend('module_unique', function ( $columnname, $value, $parameters ) {
            if ($parameters[3] == "new") {
                $whereprod = [['module_id', $parameters[1]]];
            } else {
                $whereprod = [['module_id', $parameters[1]], ['module_item_id', '<>', $parameters[2]]];
            }
            $wheredata = ['is_deleted' => $this->notdeletedStatus, 'module_item_name' => $value];
            $checkexist = MenuModel\ModuleItemsModel::where($wheredata)->where($whereprod)->count();
            if ($checkexist >= 1) {
                return false;
            }
            return true;
        }, $moduleitemname . ' name is already exist');

        switch ($type) {
            case 'new';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                $request['module_item_name'] = "required|min:3|max:255|module_unique:module_items,{$moduleId},{$moduleitemid},{$type}";
                $request['module_item_description'] = "required";
                break;
            case 'update';
                $request['app_id'] = "required";
                $request['module_item_id'] = "required|numeric";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                $request['status_enum'] = "required|numeric";
                $request['module_item_name'] = "required|min:3|max:255|module_unique:module_items,{$moduleId},{$moduleitemid},{$type}";
                $request['module_item_description'] = "required";
                break;
            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_item_id'] = "required|numeric";
                break;
            case 'view';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_item_id'] = "required|numeric";
                break;
            case 'viewsubmodule';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_item_id'] = "required|numeric";
                break;
        }
        return $request;
    }

    public function getMenuList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }

            $userdetails = MenuModel\SubModuleModel::getModuleInfoDetails($start, $length, $searchStr, $orderColumn, $sorting);
            $data = array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $namecase = $this->doAppNameConvertion($row->MODULE_TYPE, $row->NAME);
                    $tempArray = array();
                    $tempArray[] = $namecase;
                    $tempArray[] = $row->MODULENAME;
                    $tempArray[] = $row->DESCRIPTION;
                    if ($row->is_active == 1)
                        $tempArray[] = '<td><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                    else
                        $tempArray[] = '<td><span class="label label-danger"><i class="fa fa-fw fa-remove"></i> In Active </span></td>';
                    $tempArray[] = Carbon::parse($row->CREATED_DATE)->format('l jS F Y h:i:s A');
                    $actions = '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->ID . ',this)" data-type="view" title="View"></i><a> <a class="editSection" onClick="viewUserinfo(' . $row->ID . ',this)" id="editSection_' . $row->ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[] = $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }

    public function viewModuleInfo(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $inputrequest = $request->input();
            $validation = Validator::make($inputrequest, $this->validationRequestRule('view', '', '', ''));
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $ID = $inputrequest['sub_module_id'];
            $methodtype = $inputrequest['methodtype'];
            $moduleinfo = MenuModel\SubModuleModel::find($ID);
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                $productid = $this->productselfId;
                $menumoduledetails = MenuModel\ModuleModel::Active()->get();
                $statusdetails = StatusEnumModel::Active()->get();
                $productdata['app_id'] = '';
                $productdata['app_token'] = '';
                $productinfo = PRDModel\ProductModel::find($productid);
                if ($productinfo != null)
                    $productdata['app_id'] = $productinfo->product_app_id;
                $productdata['app_token'] = $productinfo->product_token;
                return view('MenuSettings.submenu_module.view')->with(compact('moduleinfo', 'methodtype', 'menumoduledetails', 'productdata', 'statusdetails'));
            }
            $Response['MessageCode'] = "204";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $Response['UserDetails'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }

    public function addModule($type, Request $request) {
        try {
            $Response['ErrorCode'] = "405";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['RequiredField'] = [];
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                if ($type == "new") {
                    $validation = Validator::make($inputrequest, $this->validationRequestRule($type, $inputrequest['module_id'], '', $inputrequest['module_item_name']));
                    if ($validation->fails()) {
                        $Response['ErrorCode'] = "400";
                        $Response['Message'] = "Bad Request, Invalid request message parameters";
                        $Response['RequiredField'] = $validation->errors();
                        return response()->json($Response);
                    }
//                    $wheredata  =   ['module_id'=>$inputrequest['module_id'],'module_item_name'=>$inputrequest['module_item_name']];
//                    $checkexist     =   MenuModel\ModuleItemsModel::Active()->where($wheredata)->first();
//                    if($checkexist !=   null){
//                        $Response['ErrorCode'] = "400";
//                        $Response['Message'] = $inputrequest['module_item_name']." is already exist!";
//                        return response()->json($Response);
//                    }

                    $getRecord = MenuModel\ModuleModel::moduleProduct($inputrequest['module_id']);
                    if ($getRecord != null) {
                        $lastRecord = MenuModel\ModuleItemsModel::latest()->first();
                        $modulecode = $this->submodulecodegeneration($getRecord->module_id, $getRecord, $inputrequest['module_item_name'], $lastRecord);
                        $input['module_item_name'] = $inputrequest['module_item_name'];
                        $input['module_id'] = $inputrequest['module_id'];
                        $input['module_item_description'] = $inputrequest['module_item_description'];
                        $input['module_item_code'] = $modulecode;
                        $input['is_active'] = 1;
                        $inserted = MenuModel\ModuleItemsModel::create($input);
                        if ($inserted != null) {
                            $Response['ErrorCode'] = "200";
                            $Response['Message'] = "Created Successfully";
                            $Response['Status'] = 1;
                            $Response['SubModuledata'] = $inserted;
                            return response()->json($Response);
                        }
                    }
                    $Response['ErrorCode'] = "400";
                    $Response['Message'] = "Product is not exist!";
                    return response()->json($Response);
                }
                if ($type == "update") {
                    $validation = Validator::make($inputrequest, $this->validationRequestRule($type, $inputrequest['module_id'], $inputrequest['module_item_id'], $inputrequest['module_item_name']));
                    if ($validation->fails()) {
                        $Response['ErrorCode'] = "400";
                        $Response['Message'] = "Bad Request, Invalid request message parameters";
                        $Response['RequiredField'] = $validation->errors();
                        return response()->json($Response);
                    }
//                    $wheredata  =   ['module_id'=>$inputrequest['module_id'],'module_item_name'=>$inputrequest['module_item_name']];
//                    $checkexist     =   MenuModel\SubModuleModel::Active()->where($wheredata)->where('module_item_id','<>',$inputrequest['module_item_id'])->first();
//                    if($checkexist !=   null){
//                        $Response['ErrorCode'] = "400";
//                        $Response['Message'] = $inputrequest['module_item_name']." is already exist!";
//                        return response()->json($Response);
//                    }
                    $existdata = MenuModel\ModuleItemsModel::find($inputrequest['module_item_id']);
                    $existdata->module_item_name = $inputrequest['module_item_name'];
                    $existdata->module_id = $inputrequest['module_id'];
                    $existdata->is_active = $inputrequest['status_enum'];
                    $existdata->module_item_description = $inputrequest['module_item_description'];
                    $existdata->save();
                    if ($existdata != null) {
                        $Response['ErrorCode'] = "200";
                        $Response['Message'] = "Updated Successfully";
                        $Response['Status'] = 1;
                        $Response['SubModuledata'] = $existdata;
                        return response()->json($Response);
                    }
                    $Response['Message'] = "Failed";
                }
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }

    public function moduleDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('delete', '', '', ''));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['module_item_id'];
                $existdata = MenuModel\ModuleItemsModel::find($uID);
                if ($existdata != null) {
                    $existdata['is_deleted'] = 1;
                    $existdata->save(); //update
                    $data = MenuModel\ModuleItemsModel::Exceptdelete()->where('module_id', $existdata->module_id)->count();
                    $Response['MessageCode'] = "200";
                    $Response['Message'] = "Record has been deleted successfully";
                    $Response['Status'] = 1;
                    $Response['moduleItemCount'] = $data;
                    DB::commit();
                    return response()->json($Response);
                }
            }
            DB::rollback();
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }

    public function viewsubmodule(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('viewsubmodule', '', '', ''));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }

                $uID = $inputrequest['module_id'];
                $existdata = MenuModel\ModuleModel::find($uID);
                if ($existdata != null) {
                    $data = MenuModel\ModuleItemsModel::Exceptdelete()->where('module_id', $uID)->get();
                    $Response['MessageCode'] = "200";
                    $Response['Message'] = "Success";
                    $Response['Status'] = 1;
                    $Response['submoduledata'] = $data;
                    return response()->json($Response);
                }
                $Response['Message'] = "No data found";
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }

}

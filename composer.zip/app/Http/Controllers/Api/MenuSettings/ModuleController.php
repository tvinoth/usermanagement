<?php

namespace App\Http\Controllers\Api\MenuSettings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Input;
use App\Models\MenuManagement as MenuModel;
use App\Models\Products as PRDModel;
use App\Models\StatusEnumModel;
use Carbon\Carbon;
use Validator;
use DB;
use Config;

class ModuleController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function validationRequestRule($type, $prdId, $moduleid, $parent, $modulename) {
        Validator::extend('module_unique', function ( $columnname, $value, $parameters ) {
            if ($parameters[4] == "new") {
                $whereprod = [['product_id', $parameters[1]]];
            } else {
                $whereprod = [['product_id', $parameters[1]], ['module_id', '<>', $parameters[2]]];
            }
            $wheredata = ['is_deleted' => $this->notdeletedStatus, 'module_name' => $value];
            $checkexist = MenuModel\ModuleModel::where($wheredata)->where($whereprod)->count();
            if ($checkexist >= 1) {
                return false;
            }
            return true;
        }, $modulename . ' name is already exist');

        switch ($type) {
            case 'new';
                $request['app_id'] = "required";
                $request['product_id'] = "required|numeric";
                $request['app_token'] = "required";
                $request['module_name'] = "required";
                $request['user_id'] = "required|numeric";
                $request['module_name'] = "required|min:3|max:255|module_unique:module,{$prdId},{$moduleid},{$parent},{$type}";
//                $request['module_name'] = 'required|max:255|unique:module,module_name,'.$id.',product_id';
//                $request['module_name'] = Rule::unique('module')->ignore($id, 'product_id');
//                $request['module_name']     =   Rule::unique('module')->where(function ($query) use($id,$moduleid) {
//                    return $query->where('is_deleted', $this->notdeletedStatus)
//                    ->where('product_id', $id);
//                });
//                $request['parent_id'] = "required_if:is_parent,in:1";
                $request['description'] = "required";
                break;
            case 'update';
                $request['app_id'] = "required";
                $request['product_id'] = "required|numeric";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
//                $request['module_name']     =   Rule::unique('module')->where(function ($query) use($prdId,$moduleid) {
//                    return $query->where('product_id', $prdId)
//                    ->where('module_id', $moduleid);
//                });
                $request['module_name'] = "required|min:3|max:255|module_unique:module,{$prdId},{$moduleid},{$parent},{$type}";
                $request['status_enum'] = "required|numeric";
                if ($parent == 0) {
                    $request['parent_id'] = "required|numeric";
                }
                $request['description'] = "required";
                break;
            case 'parentlist';
                $request['app_id'] = "required";
                $request['product_id'] = "required|numeric";
                $request['app_token'] = "required";
                break;

            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
            case 'view';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
        }
        return $request;
    }

    public function getMenuList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }
            $productID = (isset($Req->product_id) ? $Req->product_id : '');

            $userdetails = MenuModel\ModuleModel::getModuleInfoDetails($productID, $start, $length, $searchStr, $orderColumn, $sorting);
            $data = array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $namecase = $this->doAppNameConvertion($row->MODULE_TYPE, $row->NAME);
                    $tempArray = array();
                    if ($row->IS_PARENT == 1) {
                        $tempArray[] = $namecase;
                        $tempArray[] = '--';
                    } else {
                        $tempArray[] = $row->NAME;
                        $tempArray[] = $row->PARENT_NAME;
                    }

                    $tempArray[] = $row->DESCRIPTION;
                    if ($row->is_active == 1)
                        $tempArray[] = '<td><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                    else
                        $tempArray[] = '<td><span class="label label-danger"><i class="fa fa-fw fa-remove"></i> In Active </span></td>';
                    $tempArray[] = Carbon::parse($row->CREATED_DATE)->format('l jS F Y h:i:s A');
                    $actions = '<a onClick="viewSubmoduleinfo(' . $row->ID . ',this)" id="AddSubModuleSection_' . $row->ID . '" data-addmodulename="' . $row->NAME . '"><i data-toggle="modal" data-target="#modal-submodule" class="fa fa-plus fa-2px btn btn-xs btn-success" data-type="view" title="View"></i></a> '
//                             '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->ID . ','."'".$namecase."'".','."'".$row->DESCRIPTION."'".','.$row->is_active.',this)" data-type="view" title="View"></i></a>'
                            . ' <a class="editSection" onClick="viewUserinfo(' . $row->ID . ',' . "'" . $namecase . "'" . ',' . "'" . $row->DESCRIPTION . "'" . ',' . $row->is_active . ',' . $row->IS_PARENT . ',' . "'" . $row->PARENT_ID . "'" . ',this)" id="editSection_' . $row->ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[] = $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }

    public function viewModuleInfo(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $inputrequest = $request->input();
            $validation = Validator::make($inputrequest, $this->validationRequestRule('view', '', '', '', ''));
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $ID = $inputrequest['module_id'];
            $methodtype = $inputrequest['methodtype'];
            $moduleinfo = MenuModel\ModuleModel::find($ID);
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                $statusdetails = StatusEnumModel::Active()->get();
                $productid = Config::get('constants.products.self');
                $productdata['app_id'] = '';
                $productdata['app_token'] = '';
                $productinfo = PRDModel\ProductModel::find($productid);
                if ($productinfo != null)
                    $productdata['app_id'] = $productinfo->product_app_id;
                $productdata['app_token'] = $productinfo->product_token;
                $productdetails = PRDModel\ProductModel::Active()->get();
                return view('MenuSettings.menu_module.view')->with(compact('moduleinfo', 'methodtype', 'productdetails', 'productdata', 'statusdetails'));
            }
            $Response['MessageCode'] = "204";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $Response['UserDetails'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }

    public function getParentModuleList(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            if ($request->isMethod('POST')) {
                $inputrequest = $request->input();
                $validation = Validator::make($inputrequest, $this->validationRequestRule('parentlist', '', '', '', ''));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                $ID = $inputrequest['product_id'];
                $moduleinfo = MenuModel\ModuleModel::getParentModule($ID);
                $Response['MessageCode'] = "204";
                $Response['Message'] = "Success";
                $Response['Status'] = 1;
                $Response['ParentModule'] = $moduleinfo;
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }

    public function addModule($type, Request $request) {
        try {
            $Response['ErrorCode'] = "405";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['RequiredField'] = [];
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                if ($type == "new") {
                    $validation = Validator::make($inputrequest, $this->validationRequestRule($type, $inputrequest['product_id'], '', '', $inputrequest['module_name']));
                    if ($validation->fails()) {
                        $Response['ErrorCode'] = "400";
                        $Response['Message'] = "Bad Request, Invalid request message parameters";
                        $Response['RequiredField'] = $validation->errors();
                        return response()->json($Response);
                    }

                    $modulecode = "";
                    $productinfo = PRDModel\ProductModel::find($inputrequest['product_id']);
                    $lastRecord = MenuModel\ModuleModel::where(['product_id' => $inputrequest['product_id']])->latest()->first();
                    $modulecode = $this->modulecodegeneration($inputrequest['product_id'], $productinfo, $inputrequest['module_name'], $lastRecord);
//                    $wheredata  =   ['product_id'=>$inputrequest['product_id'],'module_name'=>$inputrequest['module_name']];
//                    $checkexist     =   MenuModel\ModuleModel::Active()->where($wheredata)->first();
//                    if($checkexist !=   null){
//                        $Response['ErrorCode'] = "400";
//                        $Response['Message'] = $inputrequest['module_name']." is already exist!";
//                        return response()->json($Response);
//                    }
                    $input['module_name'] = $inputrequest['module_name'];
                    $input['product_id'] = $inputrequest['product_id'];
                    $input['description'] = $inputrequest['description'];
                    $input['module_code'] = $modulecode;
                    $input['created_by'] = $inputrequest['user_id'];
                    $input['created_at'] = Carbon::now();
                    if (Input::has('parent_id') && $inputrequest['parent_id'] != '') {
                        $input['parent_id'] = $inputrequest['parent_id'];
                        $input['is_parent'] = 0;
                    }

                    $inserted = MenuModel\ModuleModel::insert($input);

                    if ($inserted != null) {
                        $Response['ErrorCode'] = "200";
                        $Response['Message'] = "Created Successfully";
                        $Response['Status'] = 1;
                        return response()->json($Response);
                    }
                }

                if ($type == "update") {
                    $existdata = MenuModel\ModuleModel::find($inputrequest['module_id']);
                    $parent = ($existdata != null ? $existdata->is_parent : '');
                    $validation = Validator::make($inputrequest, $this->validationRequestRule($type, $inputrequest['product_id'], $inputrequest['module_id'], $parent, $inputrequest['module_name']));
                    if ($validation->fails()) {
                        $Response['ErrorCode'] = "400";
                        $Response['Message'] = "Bad Request, Invalid request message parameters";
                        $Response['RequiredField'] = $validation->errors();
                        return response()->json($Response);
                    }
//                    $wheredata  =   ['product_id'=>$inputrequest['product_id'],'module_name'=>$inputrequest['module_name']];
//                    $checkexist     =   MenuModel\ModuleModel::Active()->where($wheredata)->where('module_id','<>',$inputrequest['module_id'])->first();
//                    if($checkexist !=   null){
//                        $Response['ErrorCode'] = "400";
//                        $Response['Message'] = $inputrequest['module_name']." is already exist!";
//                        return response()->json($Response);
//                    }
                    $existdata->module_name = $inputrequest['module_name'];
                    $existdata->product_id = $inputrequest['product_id'];
                    $existdata->is_active = $inputrequest['status_enum'];
                    $existdata->description = $inputrequest['description'];
                    if (Input::has('parent_id') && $inputrequest['parent_id'] != '') {
                        $existdata->parent_id = $inputrequest['parent_id'];
                    }
                    $existdata->save();
                    if ($existdata != null) {
                        $Response['ErrorCode'] = "200";
                        $Response['Message'] = "Updated Successfully";
                        $Response['Status'] = 1;
                        return response()->json($Response);
                    }
                    $Response['Message'] = "Failed";
                }
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }

    public function moduleDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('delete', '', '', '', ''));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $ID = $inputrequest['module_id'];
                $existdata = MenuModel\ModuleModel::with(array('parentModule'))->find($ID);
                if ($existdata != null) {
                    $existdata['is_deleted'] = 1;
                    $existdata->parentModule()->update(['is_deleted' => 1]); //update
                    $existdata->save(); //update
                    $Response['MessageCode'] = "200";
                    $Response['Message'] = "Record has been deleted successfully";
                    $Response['Status'] = 1;
                    DB::commit();
                    return response()->json($Response);
                }
            }
            DB::rollback();
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }

}

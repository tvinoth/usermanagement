<?php

namespace App\Http\Controllers\Api\usermanagement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Session;
use App\User;
use App\UserInfo;
use App\Models\UsermanagementModel;
use App\Models\Products as PRDModel;
use App\Models\EmployeeTypeModel;
use App\Models\HierarchyManagement\HierarchyModel;
use Carbon\Carbon;
use Validator;
use DB;
use File;

class UserManagementController extends Controller {

    public function validationRequestRule($type) {
        switch ($type) {
            case 'create';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['first_name'] = 'required|string|min:2|max:255';
                $request['last_name'] = 'required|string|min:1|max:255';
                $request['email'] = 'required|string|email|max:255|unique:users';
                $request['password'] = 'required|string|min:6|max:50';
                $request['emp_id'] = "required|numeric";
                $request['emp_team'] = "required|numeric";
                $request['emp_type'] = "required|numeric";
//                $request['upload_profile']  =   "required";
                break;
            case 'update';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['user_id'] = 'required|numeric';
                /* $request['first_name'] 	=   'required|string|min:2|max:255';
                  $request['last_name'] 	=   'required|string|min:1|max:255';
                  $request['email'] 		=   'required|string|email|max:255';
                  $request['password'] 	=   'required|string|min:6|max:50';
                  $request['emp_id'] 		=   "required|numeric";
                  $request['emp_team'] 	=   "required|numeric";
                  $request['emp_type'] 	=   "required|numeric"; */
                break;
            case 'login';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['email'] = 'required|string|email';
                $request['password'] = 'required|string';
                break;
            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['user_id'] = "required|numeric";
                break;
            case 'view';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['user_id'] = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['first_name'] = 'required|string|min:2|max:255';
                $request['last_name'] = 'required|string|min:1|max:255';
                $request['email'] = 'required|string|email|max:255|unique:users';
                $request['password'] = 'required|string|min:6|max:50';
                $request['emp_id'] = "required|numeric";
                $request['emp_team'] = "required|numeric";
                $request['emp_type'] = "required|numeric";
                break;
        }
        return $request;
    }

    public function doCreateUser(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $Response['UserDetails'] = [];
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $rules = $this->validationRequestRule('create');
                $validation = Validator::make($inputrequest, $rules);
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required!";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                
                
                /*$base64_img_array   =   explode(':', $userimage);
                $img_info           =   explode(',', end($base64_img_array));
                $img_file_extension = '';
                if (!empty($img_info)) {
                    switch ($img_info[0]) {
                        case 'image/jpeg;base64':
                                $img_file_extension = 'jpeg';
                                break;
                        case 'image/jpg;base64':
                                $img_file_extension = 'jpg';
                                break;
                        case 'image/gif;base64':
                                $img_file_extension = 'gif';
                                break;
                        case 'image/png;base64':
                                $img_file_extension = 'png';
                                break;
                    }
                }
                
                $contactimage   =   rand(23232,99999).'_user.'.$img_file_extension;
                if(file_exists(public_path('/userimages/'))){

                }else{
                    File::makeDirectory(public_path('/userimages/'), 0777, true, true);
                }
                $img_file               =   '';
                $contactnewimage        =   '';
                //check file is exist or not otherwise create file
                if(file_exists(public_path('/userimages/')))
                {
                    $img_file_name      =   public_path().'/userimages/'.$contactimage;
                    $img_file 		=   file_put_contents($img_file_name, base64_decode($img_info[1]));
                    $contactnewimage 	=   'userimages/'.$contactimage;
                }*/
                
                $sourcetarget               =   'uploads/';
                if(Input::hasFile('upload_profile')) {
                    $userimage              =   $request->file('upload_profile');
                    $fileexetention         =   $userimage->getClientOriginalExtension();
                    $sourcefilename         =   $userimage->getClientOriginalName();
                    $file_name              =   pathinfo($sourcefilename, PATHINFO_FILENAME); // filename without extension
                    $NewfileName            =   $inputrequest['emp_id'].'_'.trim($file_name). '.'.$fileexetention;
                    $fileuploadname         =   $sourcetarget.$NewfileName;
                    $movefile               =   $userimage->move($sourcetarget, $NewfileName);
                    if($movefile == ''){
                        $Response['MessageCode']   =   "404";
                        $Response['Message']        =   "User image is not uploaded successfully.";
                        return response()->json($Response);
                    }
                }
                
                
                    
                $wheredata      =   ['email' => $inputrequest['email']];
                $existuserinfo  =   User::Active()->where($wheredata)->first();
                if ($existuserinfo != null) {
                    $Response['MessageCode'] = "404";
                    $Response['Message'] = $inputrequest['email'] . " email has already been taken.";
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $authinfo = User::create([
                            'first_name' => $inputrequest['first_name'],
                            'last_name' => $inputrequest['last_name'],
                            'email' => $inputrequest['email'],
                            'password' => Hash::make($inputrequest['password']),
                ]);

                if ($authinfo != '') {
                    $userinfo = [];
                    $userinfo['user_id'] = $authinfo->id;
                    $userinfo['employee_id'] = $inputrequest['emp_id'];
                    $userinfo['employee_type'] = $inputrequest['emp_type'];
                    $userinfo['team_id'] = $inputrequest['emp_team'];
                    $userinfo['profile'] = $fileuploadname;//$contactnewimage
                    $userinfo['ip_address'] = $request->ip();
                    $userinforesult = DB::table('users_info')->insertGetId($userinfo);
                    if (!empty($userinforesult)) {
                        DB::commit();
                        $userdetails = UsermanagementModel::getUserInfo($authinfo->id);
                        $productinfo = PRDModel\ProductModel::getUserproductInfo($authinfo->id);
                        if ($userdetails != null) {
                            $Response['MessageCode'] = "200";
                            $Response['Message'] = "Success";
                            $Response['Status'] = 1;
                            $Response['UserDetails'] = $userdetails;
                            $Response['ProductDetails'] = $productinfo;
                            return response()->json($Response);
                        }
                    }
                    DB::rollback();
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "User created is not successfully try again";
                    return response()->json($Response);
                }
                DB::rollback();
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }

    public function doUserLogin(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $Response['UserDetails'] = [];
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('login'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                $wheredata = ['email' => $inputrequest['email']];
                $existuserinfo = User::Active()->where($wheredata)->first();
                if ($existuserinfo != null) {
                    if (Hash::check($inputrequest['password'], $existuserinfo->password)) {
                        $userdetails = UsermanagementModel::getUserInfo($existuserinfo->id);
                        $productinfo = PRDModel\ProductModel::getUserproductInfo($existuserinfo->id);
                        if ($userdetails != null) {
                            $Response['MessageCode'] = "200";
                            $Response['Message'] = "Success";
                            $Response['Status'] = 1;
                            $Response['UserDetails'] = $userdetails;
                            $Response['ProductDetails'] = $productinfo;
                            return response()->json($Response);
                        }
                    }
                }
                $Response['MessageCode'] = "401";
                $Response['RequiredField'] = "";
                $Response['Message'] = "These credentials do not match our records.";
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }

    public function doGetUserList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }

            $userdetails = UsermanagementModel::getUserallInfoDetails($start, $length, $searchStr, $orderColumn, $sorting);
            $data           =   array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $showauthorname = "";
                    $tempArray = array();
                    $tempArray[] = $row->employee_id;
                    $showauthorname = ($row->USER_NAME == "" ? '--' : $row->USER_NAME);
                    $tempArray[] = $showauthorname;
                    $tempArray[] = $row->TEAM_NAME;
                    if ($row->is_active == 1)
                        $tempArray[] = '<td><span class="label label-success"><i class="fa fa-user"></i> Active</span></td>';
                    else
                        $tempArray[] = '<td><span class="label label-danger"><i class="fa fa-user-times"></i> In Active </span></td>';
                    $tempArray[] = Carbon::parse($row->CREATED_DATE)->format('l jS \\of F Y h:i:s A');
                    $actions = '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->USER_ID . ',this)" data-type="view" title="View"></i><a>
                                            <a class="editSection" onClick="viewUserinfo(' . $row->USER_ID . ',this)" id="editSection_' . $row->USER_ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->USER_ID . '" data-deleteusername="' . $row->USER_NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[] = $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }

    public function doViewUserInfo(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $validation = Validator::make($request->all(), [
                        'app_id' => 'required',
                        'app_token' => 'required',
                        'user_id' => 'required|numeric'
            ]);
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $userID = $request->input('user_id');
            $methodtype = $request->input('methodtype');
            $productinfo = PRDModel\ProductModel::getUserproductInfo($userID);
            $userdetails = UsermanagementModel::getUserInfo($userID);
            if(file_exists($userdetails->profile)){
                $userdetails['profile']   =   $userdetails->profile;
            }else{
                $userdetails['profile']   =   "assets/dist/img/empty-user.jpg";
            }
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                $emptype    =   EmployeeTypeModel::Active()->get();
                $team       =   HierarchyModel::Active()->get();
                return view('usermanagement.viewuserinfo')->with(compact('userdetails', 'productinfo', 'methodtype', 'emptype', 'team'));
            }
            if ($userdetails != null) {
                $Response['MessageCode'] = "200";
                $Response['Message'] = "Success";
                $Response['Status'] = 1;
                $Response['UserDetails'] = $userdetails;
                $Response['ProductDetails'] = $productinfo;
                return response()->json($Response);
            }
            $Response['MessageCode'] = "204";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $Response['UserDetails'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }

    public function doUpdateUserInfo(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
//            $inputrequest               =   json_decode($request->getContent(),1);
//            $inputfieldvalidation       =   json_decode($request->getContent());
//            if(is_object($inputfieldvalidation) && $request->isMethod('POST')){
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('update'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['user_id'];
                $wheredata = ['id' => $uID];
                $existuserinfo = User::where($wheredata)->first();
                if ($existuserinfo != null) {
                    $updatedata = [];
                    if (isset($inputrequest['first_name'])) {
                        $existuserinfo['first_name'] = $inputrequest['first_name'];
                    }if (isset($inputrequest['last_name'])) {
                        $existuserinfo['last_name'] = $inputrequest['last_name'];
                    }if (isset($inputrequest['email'])) {
                        $wheredata = ['email' => $inputrequest['email']];
                        $checkexistemail = User::where($wheredata)->where('ID', '<>', $uID)->first();
                        if ($checkexistemail != "") {
                            $Response['MessageCode'] = "400";
                            $Response['Message'] = $inputrequest['email'] . " email has already been taken.";
                            return response()->json($Response);
                        }
                        $existuserinfo['email'] = $inputrequest['email'];
                    }if (isset($inputrequest['emp_id'])) {
                        $updatedata['employee_id'] = $inputrequest['emp_id'];
                    }if (isset($inputrequest['emp_type'])) {
                        $updatedata['employee_type'] = $inputrequest['emp_type'];
                    }if (isset($inputrequest['emp_team'])) {
                        $updatedata['team_id'] = $inputrequest['emp_team'];
                    }if (isset($inputrequest['password'])) {
                        $existuserinfo['password'] = Hash::make($inputrequest['password']);
                    }
                    
                    $sourcetarget               =   'uploads/';
                    if(Input::hasFile('upload_profile')) {
                        $userimage              =   $request->file('upload_profile');
                        $fileexetention         =   $userimage->getClientOriginalExtension();
                        $sourcefilename         =   $userimage->getClientOriginalName();
                        $file_name              =   pathinfo($sourcefilename, PATHINFO_FILENAME); // filename without extension
                        $NewfileName            =   $inputrequest['emp_id'].'_'.trim($file_name). '.'.$fileexetention;
                        $fileuploadname         =   $sourcetarget.$NewfileName;
                        $movefile               =   $userimage->move($sourcetarget, $NewfileName);
                        $updatedata['profile']  =   $fileuploadname;
                        if($movefile == ''){
                            $Response['MessageCode']   =   "404";
                            $Response['Message']        =   "User image is not uploaded successfully.";
                            return response()->json($Response);
                        }
                    }
                
                    $existuserinfo->save(); //update
                    $updatedata['last_ip_address'] = $request->ip();
                    $updatedata['updated_by'] = $uID;
                    $updatedata['updated_at'] = Carbon::now();
                    $updateuserdetails = DB::table('users_info')->where('user_id', $uID)->update($updatedata);
                    ;
                    if ($updateuserdetails) {
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been updated successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
                $Response['MessageCode'] = "401";
                $Response['RequiredField'] = "";
                $Response['Message'] = "Invalid User Id, do not match our records.";
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }

    public function doUserDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('delete'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['user_id'];
                $wheredata = ['id' => $uID];
                $existuserinfo = User::where($wheredata)->first();
                if ($existuserinfo != null) {
                    $existuserinfo['is_deleted'] = 1;
                    $existuserinfo->save(); //update
                    $updatedata = [];
                    $updatedata['is_deleted'] = 1;
                    $updatedata['last_ip_address'] = $request->ip();
                    $updatedata['updated_by'] = $uID;
                    $updatedata['updated_at'] = Carbon::now();
                    $updateuserdetails = DB::table('users_info')->where('user_id', $uID)->update($updatedata);
                    if ($updateuserdetails) {
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been deleted successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
                $Response['MessageCode'] = "401";
                $Response['RequiredField'] = "";
                $Response['Message'] = "Invalid User Id, do not match our records.";
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }

}

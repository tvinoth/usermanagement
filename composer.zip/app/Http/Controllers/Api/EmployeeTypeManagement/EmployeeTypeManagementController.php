<?php

namespace App\Http\Controllers\Api\EmployeeTypeManagement;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\EmployeeTypeModel;
use Carbon\Carbon;
use Validator;
use DB;
use App\User;

class EmployeeTypeManagementController extends Controller
{
    public function validationRequestRule($type) {
        switch ($type) {
            case 'create';
                $request['app_id']              =   "required";
                $request['app_token']           =   "required";
                $request['type_name']           =   'required|string|min:2|max:255';
                break;
            case 'update';
//                $request['app_id'] = "required";
//                $request['app_token'] = "required";
                $request['emptype_id'] = 'required|numeric';
                $request['type_name'] = 'required|string|min:2|max:255';
                break;
            case 'view';
//                $request['app_id'] = "required";
//                $request['app_token'] = "required";
                $request['emptype_id'] = "required|numeric";
                break;
            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['emptype_id'] = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['emptype_id'] = 'required|string|min:2|max:255';
                $request['type_name'] = 'required|string|min:1|max:255';
                break;
        }
        return $request;
    }
    
    public function doGetEmpTypeList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }

            $userdetails    =   EmployeeTypeModel::getEmpTypeInfoDetails($start, $length, $searchStr, $orderColumn, $sorting);
            $data           =   array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $showname           =   "";
                    $tempArray          =   array();
                    $showname           =   ($row->NAME == "" ? '--' : $row->NAME);
                    $tempArray[]        =   $showname;
                    $tempArray[]        =   $row->DESCRIPTION;
                    if ($row->IS_ACTIVE == 1)
                        $tempArray[]    =   '<td><span class="label label-success"><i class="fa fa-user"></i> Active</span></td>';
                    else
                        $tempArray[]    =   '<td><span class="label label-danger"><i class="fa fa-user-times"></i> In Active </span></td>';
                    $tempArray[]        =   Carbon::parse($row->CREATED_DATE)->format('l jS \\of F Y h:i:s A');
                    $actions            =   '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->ID . ',this)" data-type="view" title="View"></i><a>
                                            <a class="editSection" onClick="viewUserinfo(' . $row->ID . ',this)" id="editSection_' . $row->ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[]        =   $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"]               =   $Req->draw;
            $Response["recordsTotal"]       =   (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"]    =   (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"]               =   $data;

            return response()->json($Response);
        }
    }
    
    public function doAddEmployeeType(Request $request)
    {
        $inputrequest       =   $request->input();
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $Response['user_details'] = [];
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('create'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                
                $input['type_name']        =   $inputrequest['type_name'];
                $input['created_at']            =   Carbon::now();
                $input['description']           =   empty($inputrequest['description']) ? '' : $inputrequest['description'];
                $inserted     =   EmployeeTypeModel::insert($input);
                if ($inserted != null) {
                    $Response['MessageCode'] = "200";
                    $Response['Message'] = "Success";
                    $Response['Status'] = 1;
                    return response()->json($Response);
                }
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }
    
    public function doViewEmpTypeInfo(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $validation     =   Validator::make($request->all(), $this->validationRequestRule('view'));
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $ID    =   $request->input('emptype_id');
            $methodtype     =   $request->input('methodtype');
            $data    =   EmployeeTypeModel::find($ID);
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                return view('EmployeeTypeManagement.viewEmployeeType')->with(compact('data','methodtype'));
            }
            if ($userdetails != null) {
                $Response['MessageCode'] = "200";
                $Response['Message'] = "Success";
                $Response['Status'] = 1;
                $Response['user_details'] = $userdetails;
                $Response['product_details'] = $productinfo;
                return response()->json($Response);
            }
            $Response['MessageCode'] = "204";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $Response['user_details'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }
    
    public function doUpdateEmptype(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('update'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['emptype_id'];
                $existinfo = EmployeeTypeModel::find($uID);
                if ($existinfo != null) {
                        $existinfo['type_name']     =   $inputrequest['type_name'];
                        $existinfo['description']   =   $inputrequest['description'];
                        $updateuserdetails  =   $existinfo->save(); //update
                    if ($updateuserdetails) {
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been updated successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
                $Response['MessageCode'] = "401";
                $Response['RequiredField'] = "";
                $Response['Message'] = "Invalid Hierarchy Id, do not match our records.";
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
    
    public function doEmpTypeDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('delete'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['emptype_id'];
                $existdata = EmployeeTypeModel::find($uID);
                if ($existdata != null) {
                        $existdata['is_deleted'] = 1;
                        $existdata->save(); //update
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been deleted successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
                return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
}

<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RolesModel;
use App\Models\Products as PRDModel;
use App\Models\StatusEnumModel;
use Carbon\Carbon;
use Validator;
use DB;
use Config;

class RoleManagementController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $productselfId;
    protected $roleCode;
    
    public function __construct() {
        parent::__construct();
        $this->productselfId    =   Config::get('constants.products.self');
        $this->roleCode         =   Config::get('constants.roles.role_code');
    }
    
    public function validationRequestRule($type) {
        switch ($type) {
            case 'new';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['name']        = "required";
                $request['description'] = "required";
                break;
            case 'update';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['role_id'] = "required|numeric";
                $request['name'] = "required";
                $request['status_enum'] = "required|numeric";
                $request['description'] = "required";
                break;
            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['role_id'] = "required|numeric";
                break;
            case 'view';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['role_id'] = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['role_id'] = "required|numeric";
                break;
        }
        return $request;
    }
    
    public function getRoleList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }

            $userdetails    =   RolesModel::getRoleInfoDetails($start, $length, $searchStr, $orderColumn, $sorting);
            $data           =   array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $tempArray      =   array();
                    $tempArray[] = $row->NAME;
                    $tempArray[] = $row->DESCRIPTION;
//                    $tempArray[] =   $row->TYPE;
                    if ($row->is_active == 1)
                        $tempArray[] = '<td><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                    else
                        $tempArray[] = '<td><span class="label label-danger"><i class="fa fa-fw fa-remove"></i> In Active </span></td>';
                    $tempArray[] = Carbon::parse($row->CREATED_DATE)->format('l jS F Y h:i:s A');
                    $actions = '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->ID . ',this)" data-type="view" title="View"></i><a> <a class="editSection" onClick="viewUserinfo(' . $row->ID . ',this)" id="editSection_' . $row->ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[] = $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }
    
    public function viewRoleInfo(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $inputrequest   =   $request->input();
            $validation     =   Validator::make($inputrequest, $this->validationRequestRule('view'));
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $ID         = $inputrequest['role_id'];
            $methodtype = $inputrequest['methodtype'];
            $datainfo =   RolesModel::find($ID);
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                $statusdetails  =   StatusEnumModel::Active()->get();
                $productid      =   $this->productselfId;
                $productdata['app_id']    =   '';
                $productdata['app_token'] =   '';
                $productinfo    =   PRDModel\ProductModel::find($productid);
                if($productinfo !=  null)
                $productdata['app_id']    =   $productinfo->product_app_id;
                $productdata['app_token'] =   $productinfo->product_token;
                return view('RoleManagement.view')->with(compact('datainfo','methodtype','productdata','statusdetails'));
            }
            $Response['MessageCode'] = "204";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $Response['user_details'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }
    
    public function addRole($type,Request $request)
    {
        $inputrequest       =   $request->input();
        try {
            $Response['ErrorCode'] = "405";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['RequiredField'] = [];
            $Response['Status'] = 0;
            $inputrequest       =   $request->input();
            if ($request->isMethod('POST')) {
                $validation     =   Validator::make($inputrequest, $this->validationRequestRule($type));
                if ($validation->fails()) {
                    $Response['ErrorCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                
                if($type    ==  "new"){
                    $rolecode   =   "";
                    $lastRecord =   RolesModel::latest()->first();
                    if($lastRecord  !=  null)
                        $rolecode   =   $this->roleCode.($lastRecord->role_id+1);
                    else
                        $rolecode   =   $this->roleCode.'1';
                    $wheredata  =   ['name'=>$inputrequest['name']];
                    $checkexist     =   RolesModel::Active()->where($wheredata)->first();
                    if($checkexist !=   null){
                        $Response['ErrorCode'] = "400";
                        $Response['Message'] = $inputrequest['name']." is already exist!";
                        return response()->json($Response);
                    }
                    $input['name']    =   $inputrequest['name'];
                    $input['description']    =   $inputrequest['description'];
                    $input['role_code']    =   $rolecode;
                    $inserted   =   RolesModel::create($input);
                    if ($inserted != null) {
                        $Response['ErrorCode'] = "200";
                        $Response['Message'] = "Created Successfully";
                        $Response['Status'] = 1;
                        return response()->json($Response);
                    }
                }
                if($type    ==  "update"){
                    $wheredata  =   ['name'=>$inputrequest['name']];
                    $checkexist     =   RolesModel::Active()->where($wheredata)->where('role_id','<>',$inputrequest['role_id'])->first();
                    if($checkexist !=   null){
                        $Response['ErrorCode'] = "400";
                        $Response['Message'] = $inputrequest['name']." is already exist!";
                        return response()->json($Response);
                    }
                    $existdata  =    RolesModel::find($inputrequest['role_id']);
                    $existdata->name     =   $inputrequest['name'];
                    $existdata->is_active       =   $inputrequest['status_enum'];
                    $existdata->description     =   $inputrequest['description'];
                    $existdata->save();
                    if ($existdata != null) {
                        $Response['ErrorCode'] = "200";
                        $Response['Message'] = "Updated Successfully";
                        $Response['Status'] = 1;
                        return response()->json($Response);
                    }
                    $Response['Message'] = "Failed";
                }
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }
        
    public function roleDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('delete'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['role_id'];
                $existdata = RolesModel::find($uID);
                if ($existdata != null) {
                        $existdata['is_deleted'] = 1;
                        $existdata->save(); //update
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been deleted successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
                return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
}

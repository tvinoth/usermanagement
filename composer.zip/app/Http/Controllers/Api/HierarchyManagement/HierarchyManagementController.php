<?php

namespace App\Http\Controllers\Api\HierarchyManagement;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\HierarchyManagement as HierModel;
use Carbon\Carbon;
use Validator;
use DB;
use App\User;

class HierarchyManagementController extends Controller
{
    public function validationRequestRule($type) {
        switch ($type) {
            case 'create';
                $request['app_id']              =   "required";
                $request['app_token']           =   "required";
                $request['hierarchy_name']      =   'required|string|min:2|max:255';
                $request['primary_incharge']    =   'required|numeric';
                $request['secondary_incharge']  =   'required|numeric';
                break;
            case 'update';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['hierarchyId'] = 'required|numeric';
                $request['primary_incharge'] = 'required|numeric';
                $request['secondary_incharge'] = 'required|numeric';
                $request['temporary_incharge'] = 'required|numeric';
                break;
            case 'view';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['hierarchyId'] = "required|numeric";
                break;
            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['hierarchyId'] = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['first_name'] = 'required|string|min:2|max:255';
                $request['last_name'] = 'required|string|min:1|max:255';
                break;
        }
        return $request;
    }
    
    public function doGetHierarchyList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }

            $userdetails    =   HierModel\HierarchyModel::getHierarchyDetails($start, $length, $searchStr, $orderColumn, $sorting);
            $data           =   array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $showname           =   "";
                    $tempArray          =   array();
                    $showname           =   ($row->NAME == "" ? '--' : $row->NAME);
                    $tempArray[]        =   $showname;
                    $tempArray[]        =   $row->DESCRIPTION;
                    $tempArray[]        =   $row->PRIMARY_NAME;
                    $tempArray[]        =   $row->SECONDARY_NAME;
                    if ($row->IS_ACTIVE == 1)
                        $tempArray[]    =   '<td><span class="label label-success"><i class="fa fa-user"></i> Active</span></td>';
                    else
                        $tempArray[]    =   '<td><span class="label label-danger"><i class="fa fa-user-times"></i> In Active </span></td>';
                    $tempArray[]        =   Carbon::parse($row->CREATED_DATE)->format('l jS \\of F Y h:i:s A');
                    $actions            =   '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->ID . ',this)" data-type="view" title="View"></i><a>
                                            <a class="editSection" onClick="viewUserinfo(' . $row->ID . ',this)" id="editSection_' . $row->ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[]        =   $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"]               =   $Req->draw;
            $Response["recordsTotal"]       =   (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"]    =   (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"]               =   $data;

            return response()->json($Response);
        }
    }
    
    public function doAddHierarchy(Request $request)
    {
        $inputrequest       =   $request->input();
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $Response['user_details'] = [];
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('create'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                $input['hierarchy_name']        =   $inputrequest['hierarchy_name'];
                $input['primary_incharge']      =   $inputrequest['primary_incharge'];
                $input['secondary_incharge']    =   $inputrequest['secondary_incharge'];
                $input['created_at']            =   Carbon::now();
                $input['parent_id']             =   empty($inputrequest['parent_id']) ? 0 : $inputrequest['parent_id'];
                $input['description']           =   empty($inputrequest['description']) ? '' : $inputrequest['description'];
                $create     =   HierModel\HierarchyModel::insert($input);
//                $existuserinfo = User::Active()->where($wheredata)->first();
//                if ($existuserinfo != null) {
                    $Response['MessageCode'] = "200";
                    $Response['Message'] = "Success";
                    $Response['Status'] = 1;
                    return response()->json($Response);
//                }
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }
    
    public function doViewHierarchyInfo(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $validation     =   Validator::make($request->all(), $this->validationRequestRule('view'));
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $hierarchyID    =   $request->input('hierarchyId');
            $methodtype     =   $request->input('methodtype');
            $hierarchydetails   =   HierModel\HierarchyModel::find($hierarchyID);
            $categories     =   HierModel\HierarchyModel::where('parent_id', '=', 0)->get();
            $allCategories  =   HierModel\HierarchyModel::pluck('hierarchy_name','hierarchy_id')->all();
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                $userinfo   =   User::getUserNamelist();
                return view('HierarchyManagement.viewHierarchy')->with(compact('userinfo','hierarchydetails', 'categories','hierarchyID', 'methodtype', 'allCategories'));
            }
            if ($userdetails != null) {
                $Response['MessageCode'] = "200";
                $Response['Message'] = "Success";
                $Response['Status'] = 1;
                $Response['user_details'] = $userdetails;
                $Response['product_details'] = $productinfo;
                return response()->json($Response);
            }
            $Response['MessageCode'] = "204";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $Response['user_details'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }
    
    public function doUpdateHierarchyInfo(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('update'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['hierarchyId'];
                $wheredata = ['id' => $uID];
                $existinfo = HierModel\HierarchyModel::find($uID);
                if ($existinfo != null) {
                        $existinfo['hierarchy_name']    =   $inputrequest['hierarchy_name'];
                        $existinfo['description']       =   $inputrequest['description'];
                        $existinfo['parent_id']         =   $inputrequest['parent_id'];
                        $existinfo['primary_incharge']  =   $inputrequest['primary_incharge'];
                        $existinfo['updated_at']        =   Carbon::now();
                        $existinfo['temporary_incharge']=   $inputrequest['temporary_incharge'];
                        $existinfo['secondary_incharge']=   $inputrequest['secondary_incharge'];
                    
                    $updateuserdetails  =   $existinfo->save(); //update
                    if ($updateuserdetails) {
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been updated successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
                $Response['MessageCode'] = "401";
                $Response['RequiredField'] = "";
                $Response['Message'] = "Invalid Hierarchy Id, do not match our records.";
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
    
    public function doHierarchyDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('delete'));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request Message parameters, All fields are required";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['hierarchyId'];
                $existdata = HierModel\HierarchyModel::find($uID);
                if ($existdata != null) {
                        $existdata['is_deleted'] = 1;
                        $existdata->save(); //update
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been deleted successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
                return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
}

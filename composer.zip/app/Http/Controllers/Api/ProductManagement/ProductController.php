<?php

namespace App\Http\Controllers\Api\ProductManagement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Validation\Rule;
use App\Models\MenuManagement as MenuModel;
use App\Models\Products as PRDModel;
use App\Models\StatusEnumModel;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB;
use Config;

class ProductController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $productappId;

    public function __construct() {
        parent::__construct();
        $this->productappId = Config::get('constants.products.product_app_id');
    }

    public function validationRequestRule($type, $id) {
        switch ($type) {
            case 'new';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['product_name'] = "required";
//                $request['product_name'] = "required|alpha|max:255|unique:products,product_name";
                $request['product_name'] = "required|alpha|min:3|max:255";
                $request['product_name'] = Rule::unique('products');
                $request['product_short_name'] = "required|alpha|min:3|max:3";
                $request['product_short_name'] = Rule::unique('products');
                $request['product_owner'] = "required";
                $request['product_uat_url'] = 'regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/';
                $request['product_live_url'] = 'regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/';
                $request['description'] = "required";
                $request['product_type'] = "required|array|min:1";
                $request['product_type.*'] = "required|distinct|min:1|numeric";
                $request['other_tool'] = "required|array|min:1";
                $request['other_tool.*'] = "required|distinct|min:1|numeric";
                $request['product_role'] = "required|array|min:1";
                $request['product_role.*'] = "required|distinct|min:1|numeric";
                $request['version'] = "required";
                $request['manufacture'] = "required|array|min:1";
                $request['manufacture.*'] = "required|distinct|min:1|numeric";
                $request['contact'] = "required";
//                $request['contact'] = "required|array|min:1";
//                $request['contact.*'] = "required|min:1|distinct|string";
                $request['technology'] = "required|array|min:1";
                $request['technology.*'] = "required|min:1|distinct|numeric";
                $request['access_usage'] = "required|array|min:1";
                $request['access_usage.*'] = "required|min:1|distinct|numeric";
                break;
            case 'productrolemodulemapnew';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['product_id'] = "required|numeric";
                $request['productrole'] = "required|array|min:1";
                $request['productrole.*'] = "required|distinct|min:1|numeric";
//                $request['parent_item_module'] = "required|array|min:1";
//                $request['parent_item_module.*'] = "required|distinct|min:1";
//                $request['parent_module'] = "required|array|min:1";
//                $request['parent_module.*'] = "required|distinct|min:1";
                break;
            case 'productrolemodulemapupdate';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['role_id'] = "required|numeric";
                $request['product_id'] = "required|numeric";
                $request['user_id'] = "required|numeric";
                break;
            case 'rolemapdelete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['role_id'] = "required|numeric";
                $request['product_id'] = "required|numeric";
                break;
            case 'productnewaccess';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['user_id'] = "required|numeric";
                $request['product_id'] = "required|numeric";
                $request['role_id']    = "required|numeric";
                $request['userName'] = "required|array|min:1";
                $request['userName.*'] = "required|distinct|min:1|numeric";
                break;
            case 'updateuseraccess';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['user_id'] = "required|numeric";
                $request['status_enum'] = "required|numeric";
                $request['product_id'] = "required|numeric";
                $request['role_id']    = "required|numeric";
                $request['user_role_id']    = "required|numeric";
                $request['role_user_id']    = "required|numeric";
                break;
            
            case 'useraccessdelete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['user_role_id'] = "required|numeric";
                $request['product_id'] = "required|numeric";
                break;
            case 'list';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                break;
            case 'update';
                $request['app_id'] = "required";
                $request['product_id'] = "required";
                $request['products_info_id'] = "required";
                $request['app_token'] = "required";
                $request['product_name'] = "required|alpha|max:255";
                $request['product_name'] = Rule::unique('products')->ignore($id, 'product_id');
//                $request['product_short_name'] = "required|product_short_name|max:255|unique:products,product_short_name,".$id.",'product_id';
                $request['product_owner'] = "required";
                $request['product_uat_url'] = 'regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/';
                $request['product_live_url'] = 'regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/';
                $request['description'] = "required";
                $request['product_type'] = "required|array|min:1";
                $request['product_type.*'] = "required|distinct|min:1|numeric";
                $request['other_tool'] = "required|array|min:1";
                $request['other_tool.*'] = "required|distinct|min:1|numeric";
                $request['product_role'] = "required|array|min:1";
                $request['product_role.*'] = "required|distinct|min:1|numeric";
                $request['version'] = "required";
                $request['manufacture'] = "required|array|min:1";
                $request['manufacture.*'] = "required|distinct|min:1|numeric";
                $request['contact'] = "required";
//                $request['contact'] = "required|array|min:1";
//                $request['contact.*'] = "required|min:1|distinct|string";
                $request['technology'] = "required|array|min:1";
                $request['technology.*'] = "required|min:1|distinct|numeric";
                $request['access_usage'] = "required|array|min:1";
                $request['access_usage.*'] = "required|min:1|distinct|numeric";
                break;
            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
            case 'view';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
            case 'viewrolemap';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['product_id'] = "required|numeric";
                $request['role_id']     = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
        }
        return $request;
    }
    
    public function ProductRoleModuleMapList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }
            
            $productID = (isset($Req->product_id) ? $Req->product_id : '');
            
            $userdetails    =   PRDModel\ProductRoleModuleMapModel::getProductRoleModuleMapList($productID,$start, $length, $searchStr, $orderColumn, $sorting);
            $data           =   array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $tempArray      =   array();
                    $tempArray[] = $row->NAME;
//                    $tempArray[] =   $row->TYPE;
                    if ($row->is_active == 1)
                        $tempArray[] = '<td><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                    else
                        $tempArray[] = '<td><span class="label label-danger"><i class="fa fa-fw fa-remove"></i> In Active </span></td>';
                    $tempArray[] = Carbon::parse($row->CREATED_DATE)->format('l jS F Y h:i:s A');
                    $actions = '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->ID . ','.$row->ROLE_ID.',this)" data-type="viewrolemap" title="View"></i><a> <a class="editSection" onClick="viewUserinfo(' . $row->ID . ','.$row->ROLE_ID.',this)" id="editSection_' . $row->ID . '" data-type="updaterolemap"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->ROLE_ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[] = $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }
    
    public function ProductUserAccessList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }
            
            $productID = (isset($Req->product_id) ? $Req->product_id : '');
            
            $userdetails    =   PRDModel\UserRoleModel::getProductUserRoleMapList($productID,$start, $length, $searchStr, $orderColumn, $sorting);
            $data           =   array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $tempArray      =   array();
                    $tempArray[]    =   $row->USER_NAME;
                    $tempArray[] =   $row->NAME;
                    if ($row->is_active == 1)
                        $tempArray[] = '<td><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                    else
                        $tempArray[] = '<td><span class="label label-danger"><i class="fa fa-fw fa-remove"></i> In Active </span></td>';
                    $tempArray[] = Carbon::parse($row->CREATED_DATE)->format('l jS F Y h:i:s A');
                    $actions = '<a><i class="fa fa-eye fa-2px btn btn-xs btn-success" onClick="viewUserinfo(' . $row->ID . ','.$row->ROLE_ID.','.$row->USER_ID.','.$row->is_active.',this)" data-type="view" title="View"></i><a> <a class="editSection" onClick="viewUserinfo(' . $row->ID . ','.$row->ROLE_ID.','.$row->USER_ID.','.$row->is_active.',this)" id="editSection_' . $row->ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>
                                            <a class="deleteSection" id="deleteSection_' . $row->ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[] = $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }
    
    public function viewProductRoleMap(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $inputrequest   =   $request->input();
            $validation     =   Validator::make($inputrequest, $this->validationRequestRule('viewrolemap',''));
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $wheredata  =   ['product_id'=>$inputrequest['product_id'],'role_id'=>$inputrequest['role_id']];
            $datainfo   =   PRDModel\ProductRoleModuleMapModel::Active()->where($wheredata)->get();
            $Response['MessageCode'] = "204";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $Response['Role'] = $inputrequest['role_id'];
            $Response['productRoleMapDetails'] = $datainfo;
            return response()->json($Response);
        }
        return response()->json($Response);
    }
    
    public function productrolemapDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('rolemapdelete',''));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                $productID = $inputrequest['product_id'];
                $roelId = $inputrequest['role_id'];
                $inserted = "";
                //delete old 
                DB::beginTransaction();
                $wheredata  =   ['product_id'=>$productID,'role_id'=>$roelId];
                $update     =   PRDModel\ProductRoleModuleMapModel::where($wheredata)->update(['is_deleted'=>1]);
                if ($update != null) {
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been deleted successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
    
    public function getProductList(Request $request) {
        $Response['MessageCode'] = "405";
        $Response['RequiredField'] = "";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['Status'] = 0;
        if ($request->isMethod('POST')) {
            $inputrequest = $request->input();
            $validation = Validator::make($inputrequest, $this->validationRequestRule('list', ''));
            if ($validation->fails()) {
                $Response['MessageCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            $Response['MessageCode'] = "200";
            $Response['Message'] = "Success";
            $Response['Status'] = 1;
            $ProductDetails = PRDModel\ProductModel::getProductInfo($inputrequest['searchproduct']);
            $data = [];
            if (count($ProductDetails) >= 1) {
                foreach ($ProductDetails as $key => $value) {
                    $newArray['editurl'] = Crypt::encryptString($value->product_id);
                    $newArray['product_app_id'] = $value->product_app_id;
                    $newArray['product_name'] = $value->product_name;
                    $newArray['product_token'] = $value->product_token;
                    $newArray['product_app_id'] = $value->product_app_id;
                    $newArray['product_type'] = $value->product_type;
                    $newArray['user_id'] = $value->user_id;
                    $newArray['product_live_url'] = $value->product_live_url;
                    $newArray['product_uat_url'] = $value->product_uat_url;
                    $newArray['product_owner'] = $value->product_owner;
                    $newArray['product_description'] = $value->product_description;
                    $newArray['product_logo'] = $value->product_logo;
                    $newArray['created_by'] = $value->created_by;
                    $newArray['updated_by'] = $value->updated_by;
                    $newArray['created_at'] = $value->created_at;
                    $newArray['updated_at'] = $value->updated_at;
                    $newArray['is_active'] = $value->is_active;
                    $newArray['PRODUCT_TYPE_NAME'] = $value->PRODUCT_TYPE_NAME;
                    array_push($data, $newArray);
                }
            }
            $Response['ProductDetails'] = $data;
            return response()->json($Response);
        }
    }

    public function viewModuleInfo(Request $request) {
        $Response['message_code'] = "405";
        $Response['required_field'] = "";
        $Response['message'] = "HTTP method that the resource does not allow";
        $Response['status'] = 0;
        if ($request->isMethod('POST')) {
            $inputrequest = $request->input();
            $validation = Validator::make($inputrequest, $this->validationRequestRule('view', ''));
            if ($validation->fails()) {
                $Response['message_code'] = "400";
                $Response['required_field'] = "All fields are required";
                $Response['message'] = "Bad Request, Invalid request message parameters";
                $Response['required_field'] = $validation->errors();
                return response()->json($Response);
            }
            $ID = $inputrequest['module_id'];
            $methodtype = $inputrequest['methodtype'];
            $moduleinfo = MenuModel\ModuleModel::find($ID);
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                $statusdetails = StatusEnumModel::Active()->get();
                $productid = Config::get('constants.products.self');
                $productdata['app_id'] = '';
                $productdata['app_token'] = '';
                $productinfo = PRDModel\ProductModel::find($productid);
                if ($productinfo != null)
                    $productdata['app_id'] = $productinfo->product_app_id;
                $productdata['app_token'] = $productinfo->product_token;
                $productdetails = PRDModel\ProductModel::Active()->get();
                return view('MenuSettings.menu_module.view')->with(compact('moduleinfo', 'methodtype', 'productdetails', 'productdata', 'statusdetails'));
            }
            $Response['message_code'] = "204";
            $Response['message'] = "Success";
            $Response['status'] = 1;
            $Response['user_details'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }

    public function addProduct(Request $request) {
        try {
            $Response['ErrorCode'] = "405";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['RequiredField'] = [];
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('new', ''));
                if ($validation->fails()) {
                    $Response['ErrorCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }

                $appcode = "";
                $lastRecord = PRDModel\ProductModel::latest()->first();
                if ($lastRecord != null)
                    $appcode = $this->productappId . ($lastRecord->product_id + 1);
                else
                    $appcode = $this->productappId . '1';

                $sourcetarget = 'uploads/product_logo/';
                $fileuploadname = "";
                if (Input::hasFile('product_logo')) {
                    $userimage = $request->file('product_logo');
                    $fileexetention = $userimage->getClientOriginalExtension();
                    $sourcefilename = $userimage->getClientOriginalName();
                    $file_name = pathinfo($sourcefilename, PATHINFO_FILENAME); // filename without extension
                    $NewfileName = $appcode . '_' . trim($file_name) . '.' . $fileexetention;
                    $fileuploadname = $sourcetarget . $NewfileName;
                    $movefile = $userimage->move($sourcetarget, $NewfileName);
                    if ($movefile == '') {
                        $Response['MessageCode'] = "404";
                        $Response['Message'] = "Product Logo is not uploaded successfully.";
                        return response()->json($Response);
                    }
                }


                $wheredata = ['product_name' => $inputrequest['product_name']];
                $checkexist = PRDModel\ProductModel::Active()->where($wheredata)->first();
                if ($checkexist != null) {
                    $Response['ErrorCode'] = "400";
                    $Response['Message'] = $inputrequest['product_name'] . " is already exist!";
                    return response()->json($Response);
                }

                DB::beginTransaction();
                $userId = $inputrequest['user_id'];
                $input['created_by'] = $userId;
                $input['product_name'] = $inputrequest['product_name'];
                $input['product_owner'] = $inputrequest['product_owner'];
                $input['product_live_url'] = $inputrequest['product_live_url'];
                $input['product_uat_url'] = $inputrequest['product_uat_url'];
                $input['product_description'] = $inputrequest['description'];
                $input['product_short_name'] = strtoupper($inputrequest['product_short_name']);
                $input['product_app_id'] = $appcode;
                $input['product_token'] = $appcode;
                $input['product_logo'] = url($fileuploadname);

                $inserted = PRDModel\ProductModel::create($input);
                if ($inserted != null) {
                    $productID = $inserted->product_id;
                    $productinfo['product_id'] = $productID;
                    $productinfo['products_version'] = $inputrequest['version'];
                    $productinfo['user_engaged'] = $inputrequest['user_engaged'];
                    $productinfo['created_by'] = $userId;
                    $productinforesult = PRDModel\ProductsInfoModel::create($productinfo); //insert products info
                    //insert products type system
                    $producttypeenum = [];
                    foreach ($inputrequest['product_type'] as $key => $value) {
                        $producttypeenum[$key]['product_id'] = $productID;
                        $producttypeenum[$key]['product_type_enum_id'] = $value;
                        $producttypeenum[$key]['created_by'] = $userId;
                    }
                    $producttyperesult = PRDModel\ProductTypeSystemModel::insert($producttypeenum);

                    //insert products Access
                    $productaccess = [];
                    foreach ($inputrequest['access_usage'] as $key => $value) {
                        $productaccess[$key]['product_id'] = $productID;
                        $productaccess[$key]['hierarchy_id'] = $value;
                        $productaccess[$key]['created_by'] = $userId;
                    }
                    $productaccessresult = PRDModel\ProductAccessModel::insert($productaccess);

                    //insert products Other Tool
                    $productothertool = [];
                    foreach ($inputrequest['other_tool'] as $key => $value) {
                        $productothertool[$key]['product_id'] = $productID;
                        $productothertool[$key]['main_product_id'] = $value;
                        $productothertool[$key]['created_by'] = $userId;
                    }
                    $productotherresult = PRDModel\ProductOtherToolModel::insert($productothertool);

                    //insert products manufacture
                    $productmanufacture = [];
                    foreach ($inputrequest['manufacture'] as $key => $value) {
                        $productmanufacture[$key]['product_id'] = $productID;
                        $productmanufacture[$key]['hierarchy_id'] = $value;
                        $productmanufacture[$key]['created_by'] = $userId;
                    }
                    $productmanufactureresult = PRDModel\ProductManufactureModel::insert($productmanufacture);

                    //insert products developed
                    $productdeveloped = [];
                    foreach ($inputrequest['developedby'] as $key => $value) {
                        $productdeveloped[$key]['product_id'] = $productID;
                        $productdeveloped[$key]['user_id'] = $value;
                        $productdeveloped[$key]['created_by'] = $userId;
                    }
                    $productdevelopedresult = PRDModel\ProductDevelopedModel::insert($productdeveloped);

                    //insert products contact
                    $productcontact = [];
                    $contact = explode(',', $inputrequest['contact']);
                    if (is_array($contact) && count($contact) >= 1) {
                        foreach ($contact as $key => $value) {
                            $productcontact[$key]['product_id'] = $productID;
                            $productcontact[$key]['contact_mail'] = $value;
                            $productcontact[$key]['created_by'] = $userId;
                        }
                        $productcontactresult = PRDModel\ProductContactModel::insert($productcontact);
                    }
                    //insert products technology
                    $producttechnology = [];
                    foreach ($inputrequest['technology'] as $key => $value) {
                        $producttechnology[$key]['product_id'] = $productID;
                        $producttechnology[$key]['technology_id'] = $value;
                        $producttechnology[$key]['created_by'] = $userId;
                    }
                    $producttechnologyresult = PRDModel\ProductTechnologyModel::insert($producttechnology);

                    //insert products keywords
                    $productkeywords = [];
                    $keywords = explode(',', $inputrequest['keywords']);
                    if (is_array($keywords) && count($keywords) >= 1) {
                        foreach ($keywords as $key => $value) {
                            $productkeywords[$key]['product_id'] = $productID;
                            $productkeywords[$key]['keywords'] = $value;
                            $productkeywords[$key]['created_by'] = $userId;
                        }
                        $productkeywordsresult = PRDModel\ProductKeywordsModel::insert($productkeywords);
                    }

                    //insert products roles
                    $productroles = [];
                    foreach ($inputrequest['product_role'] as $key => $value) {
                        $productroles[$key]['product_id'] = $productID;
                        $productroles[$key]['role_id'] = $value;
                        $productroles[$key]['created_by'] = $userId;
                    }
                    $productrolesresult = PRDModel\ProductRoleModel::insert($productroles);


                    if ($productinforesult != null) {
                        DB::commit();
                        $Response['ErrorCode'] = "200";
                        $Response['Message'] = "Created Successfully";
                        $Response['Status'] = 1;
                        $Response['ProductId'] = Crypt::encryptString($productID);
                        return response()->json($Response);
                    }
                }
                DB::rollback();
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }

    public function addProductRoleModuleMap(Request $request) {
        try {
        $Response['ErrorCode'] = "405";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['RequiredField'] = [];
        $Response['Status'] = 0;
        $inputrequest = $request->input();
        if ($request->isMethod('POST')) {
            $validation = Validator::make($inputrequest, $this->validationRequestRule('productrolemodulemapnew', ''));
            if ($validation->fails()) {
                $Response['ErrorCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            
            $appcode = "";
            $lastRecord = PRDModel\ProductRoleModuleMapModel::latest()->first();
            $productID = $inputrequest['product_id'];
            $userId = $inputrequest['user_id'];
            $wheredata = ['product_id' => $productID];
            $checkexist = PRDModel\ProductRoleModuleMapModel::Active()->where($wheredata)->whereIn('role_id', $inputrequest['productrole'])->get();

            if (count($checkexist) >= 1) {
                $Response['ErrorCode'] = "400";
                $Response['Message'] = "Role is already exist!";
                return response()->json($Response);
            }
            
            $inserted = "";
            DB::beginTransaction();
            // insert parent items
            if (isset($inputrequest['productrole']) &&  count($inputrequest['productrole']) >= 1) {
                foreach ($inputrequest['productrole'] as $key => $role) {
                    if (isset($inputrequest['parent_module']) &&  count($inputrequest['parent_module']) >= 1) {
                        foreach ($inputrequest['parent_module'] as $key => $value) {
                            $input['created_by'] = $userId;
                            $input['product_id'] = $productID;
                            $input['role_id'] = $role;
                            $input['module_id'] = $value;
                            $getcode            =   MenuModel\ModuleModel::find($value);
                            $input['module_code'] = ($getcode !=    ''?$getcode->module_code:'');
                            $input['created_at'] = Carbon::now();
                            $inserted = PRDModel\ProductRoleModuleMapModel::insert($input);
                        }
                    }

                    if (isset($inputrequest['child_item_module']) && count($inputrequest['child_item_module']) >= 1) {
                        foreach ($inputrequest['child_item_module'] as $prodkey => $prodvalue) {
                            if (count($prodvalue) >= 1) {
                                foreach ($prodvalue as $subprodkey => $subprodvalue) {
                                    $childitems['product_id'] = $productID;
                                    $childitems['module_id'] = $prodkey;
                                    $childitems['role_id'] = $role;
                                    $childitems['module_item_id'] = $subprodkey;
                                    $childitems['module_code'] = $subprodvalue;
                                    $childitems['created_by'] = $userId;
                                    $childitems['created_at'] = Carbon::now();
                                    $inserted = PRDModel\ProductRoleModuleMapModel::insert($childitems);
                                }
                            }
                        }
                    }
                }
            }
            
            if ($inserted != null) {
                DB::commit();
                $Response['ErrorCode'] = "200";
                $Response['Message'] = "Created Successfully";
                $Response['Status'] = 1;
                return response()->json($Response);
            }
            DB::rollback();
        }
        return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }
    
    public function updateProductRoleModuleMap(Request $request) {
        try {
        $Response['ErrorCode'] = "405";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['RequiredField'] = [];
        $Response['Status'] = 0;
        $inputrequest = $request->input();
        if ($request->isMethod('POST')) {
            $validation = Validator::make($inputrequest, $this->validationRequestRule('productrolemodulemapupdate', ''));
            if ($validation->fails()) {
                $Response['ErrorCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            
            $productID = $inputrequest['product_id'];
            $userId = $inputrequest['user_id'];
            $roelId = $inputrequest['role_id'];
            $inserted = "";
            //delete old 
            DB::beginTransaction();
            $wheredata  =   ['product_id'=>$productID,'role_id'=>$roelId];
            $update     =   PRDModel\ProductRoleModuleMapModel::where($wheredata)->update(['is_deleted'=>1]);
            // insert parent items
            
            if (isset($inputrequest['parent_module']) &&  count($inputrequest['parent_module']) >= 1) {
                foreach ($inputrequest['parent_module'] as $key => $value) {
                    $input['created_by'] = $userId;
                    $input['product_id'] = $productID;
                    $input['role_id'] = $roelId;
                    $input['module_id'] = $value;
                    $getcode            =   MenuModel\ModuleModel::find($value);
                    $input['module_code'] = ($getcode !=    ''?$getcode->module_code:'');
                    $input['created_at'] = Carbon::now();
                    $inserted = PRDModel\ProductRoleModuleMapModel::insert($input);
                }
            }

            if (isset($inputrequest['child_item_module']) && count($inputrequest['child_item_module']) >= 1) {
                foreach ($inputrequest['child_item_module'] as $prodkey => $prodvalue) {
                    if (count($prodvalue) >= 1) {
                        foreach ($prodvalue as $subprodkey => $subprodvalue) {
                            $childitems['product_id'] = $productID;
                            $childitems['module_id'] = $prodkey;
                            $childitems['role_id'] = $roelId;
                            $childitems['module_item_id'] = $subprodkey;
                            $childitems['module_code'] = $subprodvalue;
                            $childitems['created_by'] = $userId;
                            $childitems['created_at'] = Carbon::now();
                            $inserted = PRDModel\ProductRoleModuleMapModel::insert($childitems);
                        }
                    }
                }
            }
            
            if ($inserted != null) {
                DB::commit();
                $Response['ErrorCode'] = "200";
                $Response['Message'] = "Updated Successfully";
                $Response['Status'] = 1;
                return response()->json($Response);
            }
            DB::rollback();
        }
        return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }
    
    public function updateProduct(Request $request) {
        try {
            $Response['ErrorCode'] = "405";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['RequiredField'] = [];
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('POST')) {
                $productID = $inputrequest['product_id'];
                $validation = Validator::make($inputrequest, $this->validationRequestRule('update', $productID));
                if ($validation->fails()) {
                    $Response['ErrorCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }

                $productinfoID = $inputrequest['products_info_id'];
                $productinfo = PRDModel\ProductModel::find($productID);
                if ($productinfo != null) {
					$appcode =	$productinfo->product_app_id;
                    $sourcetarget = 'uploads/product_logo/';
                    $fileuploadname = "";
                    if (Input::hasFile('product_logo')) {
                        $userimage = $request->file('product_logo');
                        $fileexetention = $userimage->getClientOriginalExtension();
                        $sourcefilename = $userimage->getClientOriginalName();
                        $file_name = pathinfo($sourcefilename, PATHINFO_FILENAME); // filename without extension
                        $NewfileName = $appcode . '_' . trim($file_name) . '.' . $fileexetention;
                        $fileuploadname = $sourcetarget . $NewfileName;
                        $movefile = $userimage->move($sourcetarget, $NewfileName);
                        if ($movefile == '') {
                            $Response['MessageCode'] = "404";
                            $Response['Message'] = "Product Logo is not uploaded successfully.";
                            return response()->json($Response);
                        }
                        $productinfo['product_logo'] = url($fileuploadname);
                    }


                    $wheredata = ['product_name' => $inputrequest['product_name']];
                    $checkexist = PRDModel\ProductModel::Active()->where($wheredata)->where('product_id', '<>', $productID)->first();
                    if ($checkexist != null) {
                        $Response['ErrorCode'] = "400";
                        $Response['Message'] = $inputrequest['product_name'] . " is already exist!";
                        return response()->json($Response);
                    }

                    DB::beginTransaction();
                    $userId = $inputrequest['user_id'];
                    $productinfo['updated_by'] = $userId;
                    $productinfo['product_name'] = $inputrequest['product_name'];
                    $productinfo['product_owner'] = $inputrequest['product_owner'];
                    $productinfo['product_live_url'] = $inputrequest['product_live_url'];
                    $productinfo['product_uat_url'] = $inputrequest['product_uat_url'];
                    $productinfo['product_description'] = $inputrequest['description'];
                    $updateded = $productinfo->save();
                    if ($updateded != null) {
                        $productinfodata['products_version'] = $inputrequest['version'];
                        $productinfodata['user_engaged'] = $inputrequest['user_engaged'];
                        $productinfodata['updated_by'] = $userId;
                        $productinforesult = PRDModel\ProductsInfoModel::where('products_info_id', $productinfoID)->update($productinfodata); //update products info
                        //insert products type system
                        PRDModel\ProductTypeSystemModel::where('product_id', $productID)->delete();
                        $producttypeenum = [];
                        foreach ($inputrequest['product_type'] as $key => $value) {
                            $producttypeenum[$key]['product_id'] = $productID;
                            $producttypeenum[$key]['product_type_enum_id'] = $value;
                            $producttypeenum[$key]['created_by'] = $userId;
                        }
                        $producttyperesult = PRDModel\ProductTypeSystemModel::insert($producttypeenum);

                        //insert products Access
                        PRDModel\ProductAccessModel::where('product_id', $productID)->delete();
                        $productaccess = [];
                        foreach ($inputrequest['access_usage'] as $key => $value) {
                            $productaccess[$key]['product_id'] = $productID;
                            $productaccess[$key]['hierarchy_id'] = $value;
                            $productaccess[$key]['created_by'] = $userId;
                        }
                        $productaccessresult = PRDModel\ProductAccessModel::insert($productaccess);

                        //insert products Other Tool
                        PRDModel\ProductOtherToolModel::where('product_id', $productID)->delete();
                        $productothertool = [];
                        foreach ($inputrequest['other_tool'] as $key => $value) {
                            $productothertool[$key]['product_id'] = $productID;
                            $productothertool[$key]['main_product_id'] = $value;
                            $productothertool[$key]['created_by'] = $userId;
                        }
                        $productotherresult = PRDModel\ProductOtherToolModel::insert($productothertool);

                        //insert products manufacture
                        PRDModel\ProductManufactureModel::where('product_id', $productID)->delete();
                        $productmanufacture = [];
                        foreach ($inputrequest['manufacture'] as $key => $value) {
                            $productmanufacture[$key]['product_id'] = $productID;
                            $productmanufacture[$key]['hierarchy_id'] = $value;
                            $productmanufacture[$key]['created_by'] = $userId;
                        }
                        $productmanufactureresult = PRDModel\ProductManufactureModel::insert($productmanufacture);

                        //insert products developed
                        PRDModel\ProductDevelopedModel::where('product_id', $productID)->delete();
                        $productdeveloped = [];
                        foreach ($inputrequest['developedby'] as $key => $value) {
                            $productdeveloped[$key]['product_id'] = $productID;
                            $productdeveloped[$key]['user_id'] = $value;
                            $productdeveloped[$key]['created_by'] = $userId;
                        }
                        $productdevelopedresult = PRDModel\ProductDevelopedModel::insert($productdeveloped);

                        //insert products contact
                        PRDModel\ProductContactModel::where('product_id', $productID)->delete();
                        $productcontact = [];
                        $contact = explode(',', $inputrequest['contact']);
                        if (is_array($contact) && count($contact) >= 1) {
                            foreach ($contact as $key => $value) {
                                $productcontact[$key]['product_id'] = $productID;
                                $productcontact[$key]['contact_mail'] = $value;
                                $productcontact[$key]['created_by'] = $userId;
                            }
                            $productcontactresult = PRDModel\ProductContactModel::insert($productcontact);
                        }
                        //insert products technology
                        PRDModel\ProductTechnologyModel::where('product_id', $productID)->delete();
                        $producttechnology = [];
                        foreach ($inputrequest['technology'] as $key => $value) {
                            $producttechnology[$key]['product_id'] = $productID;
                            $producttechnology[$key]['technology_id'] = $value;
                            $producttechnology[$key]['created_by'] = $userId;
                        }
                        $producttechnologyresult = PRDModel\ProductTechnologyModel::insert($producttechnology);

                        //insert products keywords
                        PRDModel\ProductKeywordsModel::where('product_id', $productID)->delete();
                        $productkeywords = [];
                        $keywords = explode(',', $inputrequest['keywords']);
                        if (is_array($keywords) && count($keywords) >= 1) {
                            foreach ($keywords as $key => $value) {
                                $productkeywords[$key]['product_id'] = $productID;
                                $productkeywords[$key]['keywords'] = $value;
                                $productkeywords[$key]['created_by'] = $userId;
                            }
                            $productkeywordsresult = PRDModel\ProductKeywordsModel::insert($productkeywords);
                        }

                        //insert products roles
                        PRDModel\ProductRoleModel::where('product_id', $productID)->delete();
                        $productroles = [];
                        foreach ($inputrequest['product_role'] as $key => $value) {
                            $productroles[$key]['product_id'] = $productID;
                            $productroles[$key]['role_id'] = $value;
                            $productroles[$key]['created_by'] = $userId;
                        }
                        $productrolesresult = PRDModel\ProductRoleModel::insert($productroles);

                        if ($productinforesult != null) {
                            DB::commit();
                            $Response['ErrorCode'] = "200";
                            $Response['Message'] = "Updated Successfully";
                            $Response['Status'] = 1;
                            return response()->json($Response);
                        }
                    }
                    DB::rollback();
                }
                $Response['ErrorCode'] = "404";
                $Response['Message'] = "No Data found";
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }

    public function moduleDelete(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('delete', ''));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $uID = $inputrequest['module_id'];
                $existdata = MenuModel\ModuleModel::find($uID);
                if ($existdata != null) {
                    $existdata['is_deleted'] = 1;
                    $existdata->save(); //update
                    $Response['MessageCode'] = "200";
                    $Response['Message'] = "Record has been deleted successfully";
                    $Response['Status'] = 1;
                    DB::commit();
                    return response()->json($Response);
                }
            }
            DB::rollback();
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
    
    public function createUserAccess(Request $request) {
        try {
        $Response['ErrorCode'] = "405";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['RequiredField'] = [];
        $Response['Status'] = 0;
        $inputrequest   =   $request->input();
        if ($request->isMethod('POST')) {
            $validation = Validator::make($inputrequest, $this->validationRequestRule('productnewaccess', ''));
            if ($validation->fails()) {
                $Response['ErrorCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            
            $productID  = $inputrequest['product_id'];
            $userId     = $inputrequest['user_id'];
            $roleId     = $inputrequest['role_id'];
            $wheredata = ['product_id' => $productID,'role_id'=>$roleId];
            $checkexist = PRDModel\UserRoleModel::select(DB::raw('user_roles.user_role_id AS ID,concat(u.first_name," ",u.last_name) AS USER_NAME'))->Active()->where($wheredata)->whereIn('user_id', $inputrequest['userName'])
                            ->leftjoin('users AS u', 'u.id', '=', 'user_roles.user_id')->get();
            
            if (count($checkexist) >= 1) {
                $existname  =   implode(' ',$checkexist->pluck('USER_NAME')->toArray());
                $Response['ErrorCode'] = "400";
                $Response['Message'] = $existname.' already exist!';
                return response()->json($Response);
            }
            
            $inserted = "";
            DB::beginTransaction();
            // insert 
            if (isset($inputrequest['userName']) &&  count($inputrequest['userName']) >= 1) {
                $input  =   [];
                foreach ($inputrequest['userName'] as $key => $value) {
                    $input[$key]['user_id'] = $value;
                    $input[$key]['product_id'] = $productID;
                    $input[$key]['role_id'] = $roleId;
                    $input[$key]['created_at'] = Carbon::now();
                    $input[$key]['created_by'] = $userId;
                }
                $inserted = PRDModel\UserRoleModel::insert($input);
            }
            
            if ($inserted != null) {
                DB::commit();
                $Response['ErrorCode'] = "200";
                $Response['Message'] = "Created Successfully";
                $Response['Status'] = 1;
                return response()->json($Response);
            }
            DB::rollback();
        }
        return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }
    
    public function updateUserAccess(Request $request) {
        try {
        $Response['ErrorCode'] = "405";
        $Response['Message'] = "HTTP method that the resource does not allow";
        $Response['RequiredField'] = [];
        $Response['Status'] = 0;
        $inputrequest = $request->input();
        if ($request->isMethod('POST')) {
            $validation = Validator::make($inputrequest, $this->validationRequestRule('updateuseraccess', ''));
            if ($validation->fails()) {
                $Response['ErrorCode'] = "400";
                $Response['Message'] = "Bad Request, Invalid request message parameters";
                $Response['RequiredField'] = $validation->errors();
                return response()->json($Response);
            }
            
            $productID = $inputrequest['product_id'];
            $userId = $inputrequest['user_id'];
            $roleId = $inputrequest['role_id'];
            $userRoleId = $inputrequest['user_role_id'];
            $roleUserId = $inputrequest['role_user_id'];
            
            $wheredata = ['product_id' => $productID,'user_roles.role_id'=>$roleId,'user_id'=>$roleUserId];
            $checkexist = PRDModel\UserRoleModel::select(DB::raw('r.name AS ROLE_NAME,user_roles.user_role_id AS ID,concat(u.first_name," ",u.last_name) AS USER_NAME'))
                            ->leftjoin('users AS u', 'u.id', '=', 'user_roles.user_id')
                            ->leftjoin('roles AS r', 'r.role_id', '=', 'user_roles.role_id')
                            ->Active()->where($wheredata)
                            ->where('user_role_id','<>', $userRoleId)
                            ->get();
            
            if (count($checkexist) >= 1) {
                $existname  =   implode(' ',$checkexist->pluck('ROLE_NAME')->toArray());
                $Response['ErrorCode'] = "400";
                $Response['Message'] = $existname.' already exist!';
                return response()->json($Response);
            }
            
            //delete old 
            DB::beginTransaction();
            $findexist     =   PRDModel\UserRoleModel::find($userRoleId);
            // insert parent items
            $inserted   =   "";
            if ($findexist !=   null) {
                $findexist['role_id']  =   $inputrequest['role_id'];
                $findexist['is_active']  =   $inputrequest['status_enum'];
                $findexist['updated_by']  =   $userId;
                $inserted   =   $findexist->save();
            }

            if ($inserted != null) {
                DB::commit();
                $Response['ErrorCode'] = "200";
                $Response['Message'] = "Updated Successfully";
                $Response['Status'] = 1;
                return response()->json($Response);
            }
            DB::rollback();
            }
        return response()->json($Response);
        } catch (\Exception $e) {
            return response()->json($Response);
        }
    }
    
    public function deleteUserAccess(Request $request) {
        try {
            $Response['MessageCode'] = "405";
            $Response['RequiredField'] = "";
            $Response['Message'] = "HTTP method that the resource does not allow";
            $Response['Status'] = 0;
            $inputrequest = $request->input();
            if ($request->isMethod('DELETE')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('useraccessdelete',''));
                if ($validation->fails()) {
                    $Response['MessageCode'] = "400";
                    $Response['Message'] = "Bad Request, Invalid request message parameters";
                    $Response['RequiredField'] = $validation->errors();
                    return response()->json($Response);
                }
                $productID = $inputrequest['product_id'];
                $user_role_id = $inputrequest['user_role_id'];
                //delete old 
                DB::beginTransaction();
                $update     =   PRDModel\UserRoleModel::find($user_role_id);
                if ($update != null) {
                        $update['is_deleted']   =   1;
                        $update->save();
                        $Response['MessageCode'] = "200";
                        $Response['Message'] = "Record has been deleted successfully";
                        $Response['Status'] = 1;
                        DB::commit();
                        return response()->json($Response);
                    }
                }
                DB::rollback();
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
    
}

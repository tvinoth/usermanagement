<?php

namespace App\Http\Controllers\AppSettings;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\User;
use App\Models\ModuleModel;
use App\Models\ModuleTypeEnumModel;
use Session;
use Carbon\Carbon;
use Validator;
use DB;
use Illuminate\Support\Facades\View;

class AppSettingsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        View::share("parentname","App Settings's");
        $this->middleware('auth');
    }
    
    public function validationRequestRule($type) {
        switch ($type) {
            case 'update';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                $request['module_name'] = "required";
                $request['module_type'] = "required|numeric";
                break;
            case 'delete';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                $request['ip_address'] = 'required|string';
                break;
            case 'view';
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
            default:
                $request['app_id'] = "required";
                $request['app_token'] = "required";
                $request['module_id'] = "required|numeric";
                break;
        }
        return $request;
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        View::share('childname', 'Employee Type Management');
        $modulename     =   ModuleModel::find('5');
        if($modulename !=   null){
            $modulename     =   self::doAppNameConvertion($modulename->module_type,$modulename->module_name);
        }
        return view('AppSettings.AppSettingsindex')->with(compact('modulename'));
    }
    
    public function doAppNameConvertion($type,$name){
        switch($type){
            case 1:
                $namecase   = strtoupper($name);
                break;
            case 2:
                $namecase   = strtolower($name);
                break;
            case 3:
                $namecase   = ucfirst($name);
                break;
            case 4:
                $namecase   = ucwords($name);
                break;
            default:
                $namecase   = ucwords($name);
                break;
        }
        return $namecase;
    }
    
    public function doGetAppsettingList(Request $request) {
        if ($request->input()) {
            $Req = (object) $request->input();
            $orderColumn = 5; //created date column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }

            $userdetails    =   ModuleModel::getModuleInfoDetails($start, $length, $searchStr, $orderColumn, $sorting);
            $data           =   array();
            if (isset($userdetails['alldetails']) && count($userdetails['alldetails']) >= 1) {
                foreach ($userdetails['alldetails'] as $row) {
                    $namecase       =   self::doAppNameConvertion($row->MODULE_TYPE,$row->NAME);
                    $tempArray      =   array();
                    $tempArray[] = $namecase;
                    $tempArray[] = $row->DESCRIPTION;
                    $tempArray[] =   $row->TYPE;
                    if ($row->is_active == 1)
                        $tempArray[] = '<td><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                    else
                        $tempArray[] = '<td><span class="label label-danger"><i class="fa fa-fw fa-remove"></i> In Active </span></td>';
                    $tempArray[] = Carbon::parse($row->CREATED_DATE)->format('l jS \\of F Y h:i:s A');
                    $actions = '<a class="editSection" onClick="viewUserinfo(' . $row->ID . ',this)" id="editSection_' . $row->ID . '" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>';
//                                            <a class="deleteSection" id="deleteSection_' . $row->ID . '" data-deleteusername="' . $row->NAME . '"><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-toggle="modal" data-target="#modal-delete" data-placement="top" data-original-title="Delete"></i></a>';
                    $tempArray[] = $actions;
                    array_push($data, $tempArray);
                }
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["recordsFiltered"] = (isset($userdetails['countinfo']) ? $userdetails['countinfo'] : 0);
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }
    
    public function doViewModuleInfo(Request $request) {
        $Response['message_code'] = "405";
        $Response['required_field'] = "";
        $Response['message'] = "HTTP method that the resource does not allow";
        $Response['status'] = 0;
        if ($request->isMethod('POST')) {
            $inputrequest   =   $request->input();
            $validation     =   Validator::make($inputrequest, $this->validationRequestRule('view'));
            if ($validation->fails()) {
                $Response['message_code'] = "400";
                $Response['required_field'] = "All fields are required";
                $Response['message'] = "Bad Request, Invalid request message parameters";
                $Response['required_field'] = $validation->errors();
                return response()->json($Response);
            }
            $ID         = $inputrequest['module_id'];
            $methodtype = $inputrequest['methodtype'];
            $moduleinfo =   ModuleModel::find($ID);
            $moduleenum     =   ModuleTypeEnumModel::Active()->get();
            if ($request->ajax()) {
                switch ($methodtype) {
                    case 'view';
                        $methodtype = "view";
                        break;
                    case 'update';
                        $methodtype = "update";
                        break;
                    default:
                        $methodtype = "view";
                        break;
                }
                return view('AppSettings.viewAppSettinginfo')->with(compact('moduleinfo','methodtype','moduleenum'));
            }
            $Response['message_code'] = "204";
            $Response['message'] = "Success";
            $Response['status'] = 1;
            $Response['user_details'] = [];
            return response()->json($Response);
        }
        return response()->json($Response);
    }
    
    public function doUpdateModuleInfo(Request $request) {
        try {
            $Response['message_code'] = "405";
            $Response['required_field'] = "";
            $Response['message'] = "HTTP method that the resource does not allow";
            $Response['status'] = 0;
            $inputrequest   =   $request->input();
            if ($request->isMethod('POST')) {
                $validation = Validator::make($inputrequest, $this->validationRequestRule('update'));
                if ($validation->fails()) {
                    $Response['message_code'] = "400";
                    $Response['required_field'] = "All fields are required";
                    $Response['message'] = "Bad Request, Invalid request message parameters";
                    $Response['required_field'] = $validation->errors();
                    return response()->json($Response);
                }
                DB::beginTransaction();
                $existuserinfo  =   ModuleModel::find($inputrequest['module_id']);
                if ($existuserinfo != null) {
                    $existuserinfo->module_name     =   $inputrequest['module_name'];
                    $existuserinfo->description     =   $inputrequest['description'];
                    $existuserinfo->module_type     =   $inputrequest['module_type'];
                    $existuserinfo->save(); //update
                    $Response['message_code'] = "200";
                    $Response['message'] = "Record has been updated successfully";
                    $Response['status'] = 1;
                    DB::commit();
                    return response()->json($Response);
                }
                DB::rollback();
                $Response['message_code'] = "401";
                $Response['required_field'] = "";
                $Response['message'] = "Invalid Module Id, do not match our records.";
                return response()->json($Response);
            }
            return response()->json($Response);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json($Response);
        }
    }
    
}

<?php

namespace App\Http\Controllers\MenuSettings;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\User;
use App\Models\MenuManagement as MenuModel;
use App\Models\Products as PRDModel;
use App\Models\ModuleTypeEnumModel;
use Session;
use Carbon\Carbon;
use Validator;
use DB;
use Config;

class SubModuleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $productselfId;
    public function __construct()
    {
        parent::__construct();
        $this->productselfId    =   Config::get('constants.products.self');
        $this->middleware('auth');
    }
    /**
     * Show the application menu module.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $modulename     =   MenuModel\ModuleModel::find('5');
        if($modulename !=   null){
            $modulename     =   $this->doAppNameConvertion($modulename->module_type,$modulename->module_name);
        }
        $productid      =   $this->productselfId;
        $productdata['app_id']    =   '';
        $productdata['app_token'] =   '';
        $productinfo    =   PRDModel\ProductModel::find($productid);
        $menumoduledetails  =   MenuModel\ModuleModel::Active()->get();
        if($productinfo !=  null)
        $productdata['app_id']    =   $productinfo->product_app_id;
        $productdata['app_token'] =   $productinfo->product_token;    
        return view('MenuSettings.submenu_module.index')->with(compact('modulename','productdata','menumoduledetails'));
    }
}

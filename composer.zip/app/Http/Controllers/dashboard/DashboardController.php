<?php

namespace App\Http\Controllers\dashboard;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\MenuManagement as MenuModel;
use App\User;
use Session;
use Config;
use Illuminate\Support\Facades\View;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        View::share('parentname', 'Dashboard');
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function adminindex()
    {
        View::share('childname', 'Admin Dashboard');
        $modulename     =   MenuModel\ModuleModel::find($this->dashBoard);
        if($modulename !=   null){
            $modulename     =   $this->doAppNameConvertion($modulename->module_type,$modulename->module_name);
        }
        return view('dashboard.admindashboard')->with(compact('modulename'));
    }
    
    public function userindex()
    {
        View::share('childname', 'User Dashboard');
        $modulename     =   MenuModel\ModuleModel::find($this->userDashboard);
        if($modulename !=   null){
            $modulename     =   $this->doAppNameConvertion($modulename->module_type,$modulename->module_name);
        }
        return view('dashboard.userdashboard')->with(compact('modulename'));
    }
}

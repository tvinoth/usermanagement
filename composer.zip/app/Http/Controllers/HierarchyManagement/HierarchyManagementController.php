<?php

namespace App\Http\Controllers\HierarchyManagement;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\HierarchyManagement\HierarchyModel;
use App\User;
use App\Models\MenuManagement as MenuModel;
use App\Models\Products as PRDModel;
use Config;
use Illuminate\Support\Facades\View;

class HierarchyManagementController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $productselfId;
    public function __construct()
    {
        parent::__construct();
        View::share('parentname', 'Hierarchy Management');
        View::share('childname', '');
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $userinfo   =   User::getUserNamelist();
        $categories =   HierarchyModel::where('parent_id', '=', 0)->get();
        $allCategories  =   HierarchyModel::pluck('hierarchy_name','hierarchy_id')->all();
        $hierarchyID    =   '';
        $modulename     =   MenuModel\ModuleModel::find($this->HierarchyModule);
        if($modulename !=   null){
            $modulename     =   $this->doAppNameConvertion($modulename->module_type,$modulename->module_name);
        }
        $productid      =   $this->productselfId;
        $productdata['app_id']    =   '';
        $productdata['app_token'] =   '';
        $productinfo    =   PRDModel\ProductModel::find($productid);
        $productdetails =   PRDModel\ProductModel::Active()->get();
        if($productinfo !=  null)
        $productdata['app_id']    =   $productinfo->product_app_id;
        $productdata['app_token'] =   $productinfo->product_token;  
        return view('HierarchyManagement.hierarchyDetails',compact('categories','allCategories','userinfo','hierarchyID','modulename','productdata'));
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\User;
use App\Models\MenuManagement as MenuModel;
use App\Models\Products as PRDModel;
use App\Models\ModuleTypeEnumModel;
use Session;
use Carbon\Carbon;
use Validator;
use DB;
use Config;
use Illuminate\Support\Facades\View;

class RoleManagementController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        View::share('parentname', 'Role Management');
        View::share('childname', '');
        $this->middleware('auth');
    }

    /**
     * Show the application menu module.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $modulename = MenuModel\ModuleModel::find($this->roleModule);
        if ($modulename != null) {
            $modulename = $this->doAppNameConvertion($modulename->module_type, $modulename->module_name);
        }
        $productid = Config::get('constants.products.self');
        $productdata['app_id'] = '';
        $productdata['app_token'] = '';
        $productinfo = PRDModel\ProductModel::find($productid);
        if ($productinfo != null)
            $productdata['app_id'] = $productinfo->product_app_id;
        $productdata['app_token'] = $productinfo->product_token;
        return view('RoleManagement.index')->with(compact('modulename', 'productdata'));
    }

}

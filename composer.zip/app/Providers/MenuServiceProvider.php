<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Models\MenuManagement as MenuModel;
use DB;

class MenuServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        View::composer('*', function($view) {
            $userid = "";
            if (isset(Auth::user()->id)) {
                $userid = Auth::user()->id;
            }
            $menu = MenuModel\ModuleModel::userLoginMenu($userid);
            //split parent
            $parents = $menu->where('is_parent', 1)->pluck('module_code','module_id');
            $parentsdata = $menu->where('is_parent', 1);
            //split child 
            $childs = $menu->where('is_parent', 0)->pluck('module_code','module_id');
            $childsdata = $menu->where('is_parent', 0);
            $menuArray = [];
            if (count($menu) >= 1) {
                foreach ($menu as $key => $value) {
                    if($value->is_parent    ==  1){
                        $menuArray[$key]['parent'] = $value->toArray();
                        $existdata = MenuModel\ModuleModel::where('parent_id', $value->module_id)->get()->pluck('module_code');
                        $difference = $existdata->intersect($childs)->all();
                        if (count($difference) >= 1) {
                            foreach ($difference as $childkey => $childvalue) {
                                $menuArray[$key]['child'] = $childsdata->where('module_code', $childvalue)->toArray();
                            }
                        } else {
                            $menuArray[$key]['child'] = [];
                        }
                    }
//                    else{
//                        $existdata = MenuModel\ModuleModel::select(DB::raw('module_code,menu_icon,parent_id,menu_url,is_parent,module_name'))->where('module_id', $value->parent_id)->first()->toArray();
//                        if (count($existdata) >= 1) {
//                            $menuArray[$key]['parent'] =     $existdata;
//                        }
//                        $menuArray[$key]['child'] = $value->toArray();
//                    }
                }
            }
            $menudecode     =   json_encode($menuArray);
            $menu           =   json_decode($menudecode);
            $view->with('layouts.sidebar')->with(compact('menu'));
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

}

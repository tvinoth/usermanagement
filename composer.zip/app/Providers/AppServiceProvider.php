<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
//use Illuminate\Support\Facades\View;
//use Illuminate\Support\Facades\Auth;
//use App\Models\MenuManagement as MenuModel;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        /*View::composer('*', function($view){
			$menu 	=	MenuModel\ModuleModel::userLoginMenu(Auth::user()->id);
			$view->with('layouts.sidebar')->with(compact('menu'));
		});*/
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}

<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;

class User extends Authenticatable
{
    use Notifiable;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name','last_name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
	
    public function scopeActive($query)
    {
        return $query->where('is_active', 1);
    }
    
    public function scopeUsersActive($query)
    {
        return $query->where('users.is_active', 1);
    }
    
    public static function getUserInfo($id){
            return User::select(DB::raw('users.*,users_info.*'))->join('users_info','users_info.user_id','=','users.id')
                    ->where('users.id',$id)
                    ->first();
    }
    
    public static function getUserNamelist(){
            return User::UsersActive()->select(DB::raw('users.id as USER_ID,concat(users.first_name," ",users.last_name) AS USER_NAME,email'))->join('users_info','users_info.user_id','=','users.id')
                    ->where('users_info.is_active',1)
                    ->get();
    }
}

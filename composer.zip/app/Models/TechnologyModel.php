<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class TechnologyModel extends Model
{    
    protected $table    =   'technology';
    protected $primaryKey  =   'technology_id';
    protected $fillable   =   ['name','description'];
    public function scopeActive($query)
    {
        return $query->where('is_active', 1)->where('is_deleted', 0);
    }
}

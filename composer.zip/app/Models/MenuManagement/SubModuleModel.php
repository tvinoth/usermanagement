<?php
namespace App\Models\MenuManagement;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class SubModuleModel extends Model
{    
    protected $table    =   'sub_module';
    protected $hidden   =   [];
    protected $primaryKey  =   'sub_module_id';
    protected $fillable   =   ['module_id','sub_module_name','sub_description','is_active','sub_module_code'];
    public function scopeActive($query)
    {
        return $query->where('sub_module.is_active', 1)->where('sub_module.is_deleted', 0);
    }
    
    public function module()
    {
        return $this->belongsTo('App\Models\MenuManagement\ModuleModel','module_id');
    }
    
    public function productModule()
    {
        return $this->belongsTo('App\Models\MenuManagement\ModuleModel','module_id')->Active();
    }
    
    public function scopeExceptdelete($query)
    {
        return $query->where('sub_module.is_deleted', 1);
    }
    
    public static function getModuleInfoDetails($start,$length,$searchStr,$orderColumn,$sorting){
        $userinfo   =   [];
//        try
//        {
            $columnArray    =   [];
            $columnArray[]  =   'sub_module.sub_module_name';
            $columnArray[]  =   'sub_module.module_type';
            $columnArray[]  =   'sub_module.created_at';
            $userinfo['countinfo']  =   SubModuleModel::select(DB::raw('sub_module.sub_module_id'))
                                        ->join('module','module.module_id','=','sub_module.module_id')
                                        ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->orWhere('sub_module.sub_module_name', 'like', '%' . $searchStr . '%')
                                                ->orWhere('sub_module.sub_description', 'like', '%' . $searchStr . '%')
                                                ->orWhere('sub_module.created_at', 'like', '%' . $searchStr . '%')
                                                ->orWhere('sub_module.is_active', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('sub_module.is_deleted', 0)
                                            ->where('module.is_deleted', 0)
                                            ->count();
            $userinfo['alldetails']    =   SubModuleModel::select(DB::raw('sub_module_id as ID,module.module_name as MODULENAME,sub_module_name as NAME,sub_module.created_at as CREATED_DATE,sub_module.is_active,sub_description AS DESCRIPTION'))
                                            ->join('module','module.module_id','=','sub_module.module_id')
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->orWhere('sub_module.sub_module_name', 'like', '%' . $searchStr . '%')
                                                ->orWhere('sub_module.sub_description', 'like', '%' . $searchStr . '%')
                                                ->orWhere('sub_module.created_at', 'like', '%' . $searchStr . '%')
                                                ->orWhere('sub_module.is_active', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('sub_module.is_deleted', 0)
                                            ->where('module.is_deleted', 0)
                                            ->skip($start)->take($length)
                                            ->get();
//        }
//        catch( \Exception $e )
//	{           
//            return false;
//        }    
        return $userinfo;
    }
}

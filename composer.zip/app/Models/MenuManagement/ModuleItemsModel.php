<?php
namespace App\Models\MenuManagement;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ModuleItemsModel extends Model
{    
    protected $table    =   'module_items';
    protected $hidden   =   [];
    protected $primaryKey  =   'module_item_id';
    protected $fillable   =   ['module_id','module_item_code','module_item_name','module_item_description','is_active'];
    public function scopeActive($query)
    {
        return $query->where('module_items.is_active', 1)->where('module_items.is_deleted', 0);
    }
    
    public function scopeExceptdelete($query)
    {
        return $query->where('module_items.is_deleted', 0);
    }
    
    public function productModule()
    {
        return $this->hasMany(ModuleItemsModel::Class,'product_id','module_id')->where('module.is_parent',1)->Active();
    }
}

<?php

namespace App\Models\MenuManagement;
use Illuminate\Database\Eloquent\Model;
use App\Models\UsermanagementModel;
use DB;
use Session;
use Config;

class ModuleModel extends Model {
        
    protected $table = 'module';
    protected $hidden = [];
    protected $primaryKey = 'module_id';
    protected $fillable = ['product_id', 'module_name', 'description', 'is_parent', 'module_code'];

    public function scopeActive($query) {
        return $query->where('module.is_active', 1)->where('module.is_deleted', 0);
    }

    public function parentModule() {
        return $this->hasMany(ModuleModel::Class, 'parent_id');
    }

    public function submodule() {
        return $this->hasMany('App\Models\MenuManagement\SubModuleModel', 'module_id');
    }

    public function proModule() {
        return $this->hasMany('App\Models\MenuManagement\ModuleItemsModel', 'module_id')->Active();
    }
    
    public function productModuleItems() {
        return $this->hasMany('App\Models\MenuManagement\ModuleItemsModel', 'module_id')->Active()
                ->select(DB::raw('module_items.module_item_id,module_items.module_id,module_items.module_item_code,module_items.module_item_name'));
    }

    public static function getParentModule($ID) {
        return ModuleModel::Active()->where('module.product_id', $ID)
                        ->where('module.is_parent', 1)
                        ->get();
    }
    
    public static function getchildModuleitems($moduleID) {
        return ModuleModel::Active()->where('module.module_id', $moduleID)
                        ->leftjoin('module_items as mi','mi.module_id','=','module.module_id')
                        ->where('mi.is_active', 1)
                        ->where('mi.is_deleted', 0)
                        ->get();
    }

    public static function moduleProduct($ID) {
        return ModuleModel::select(DB::raw('module.module_id,products.product_id,products.product_name,products.product_short_name'))
                        ->join('products', 'products.product_id', '=', 'module.product_id')
                        ->where('module.module_id', $ID)
                        ->first();
    }

    public static function getModuleInfoDetails($productID, $start, $length, $searchStr, $orderColumn, $sorting) {
        $userinfo = [];
        try {
            $columnArray = [];
            $columnArray[] = 'module.module_name';
            $columnArray[] = 'module.module_type';
            $columnArray[] = 'module.created_at';
            $userinfo['countinfo'] = ModuleModel::from('module as m1')->select(DB::raw('m1.module_id'))
                    ->leftjoin('module as m2','m2.module_id','=','m1.parent_id')
                    ->where(function ($query) use ($searchStr) {
                        if (trim($searchStr) != '') {
                            return $query->Where('m1.module_name', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.module_type', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.description', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.created_at', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.is_active', 'like', '%' . $searchStr . '%');
                        }
                    })
                    ->where('m1.product_id', $productID)
                    ->where('m1.is_deleted', 0)
                    ->orderBy('m1.module_id','desc')
                    ->count();
                    
            $userinfo['alldetails'] = ModuleModel::from('module as m1')->select(DB::raw('m1.module_id as ID,m1.module_name as NAME,m2.module_name as PARENT_NAME,m1.created_at as CREATED_DATE,m1.is_parent as IS_PARENT,m1.parent_id as PARENT_ID,m1.module_type as MODULE_TYPE,case m1.module_type WHEN 1 then "UPPER CASE" WHEN 2 then "LOWER CASE" WHEN 3 then "UPPER FIRST CHARACTER" WHEN 4 then "UPPER FIRST CHARACTER EACH WORD" ELSE "--" end TYPE,m1.is_active,m1.description AS DESCRIPTION'))
                    ->leftjoin('module as m2','m2.module_id','=','m1.parent_id')
                    ->where(function ($query) use ($searchStr) {
                        if (trim($searchStr) != '') {
                            return $query->Where('m1.module_name', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.module_type', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.description', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.created_at', 'like', '%' . $searchStr . '%')
                                    ->orWhere('m1.is_active', 'like', '%' . $searchStr . '%');
                        }
                    })
                    ->where('m1.product_id', $productID)
                    ->where('m1.is_deleted', 0)
                    ->skip($start)->take($length)
                    ->orderBy('m1.module_id','desc')
                    ->get();
        } catch (\Exception $e) {
            return false;
        }
        return $userinfo;
    }

    public static function userLoginMenu($UID) {
//        DB::enableQueryLog();
        return UsermanagementModel::from('users as u')->select(DB::raw('m.menu_code,m.menu_icon,m.parent_page_active,m.child_page_active,m.parent_id,m.menu_url,prmm.module_code,prmm.module_id,m.is_parent,m.page_name'))
                        ->join('users_info as ui', 'ui.user_id', '=', 'u.id')
                        ->join('user_roles as ur', 'ur.user_id', '=', 'u.id')
                        ->join('product_role_module_map as prmm',function($join)
                        {
                            $join->on('prmm.product_id', '=', 'ur.product_id');
                            $join->on('prmm.role_id', '=', 'ur.role_id');
                        })
                        ->join('menu as m', 'm.menu_code', '=', 'prmm.module_code')
                        ->join('menu_access as ma', 'ma.menu_code', '=', 'm.menu_code')
                        ->where('u.id', $UID)
                        ->where('prmm.is_deleted', 0)
                        ->where('ur.is_deleted', 0)
                        ->where('u.is_deleted', 0)
                        ->where('m.is_deleted', 0)
                        ->where('ui.is_deleted', 0)
                        ->where('prmm.is_active', 1)
                        ->where('m.is_active', 1)
                        ->where('ur.is_active', 1)
                        ->where('u.is_active', 1)
                        ->where('ui.is_active', 1)
                        ->orderBy('m.menu_id', 'asc')
                        ->groupBy('ma.menu_id')
                        ->havingRaw('count(ma.menu_id) > 2')        
                        ->get();
//                        print_r(DB::getQueryLog()); exit;
    }
}

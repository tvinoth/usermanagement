<?php

namespace App\Models\Products;

use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductRoleModuleMapModel extends Model {

    protected $table = 'product_role_module_map';
    protected $hidden = [];
    protected $primaryKey = 'product_role_module_map_id';
    protected $fillable = ['product_id', 'role_id', 'module_id'];

    public function scopeActive($query) {
        return $query->where('product_role_module_map.is_active', 1)->where('product_role_module_map.is_deleted', 0);
    }

    public static function getProductRoleModuleMapList($productID, $start, $length, $searchStr, $orderColumn, $sorting) {
        $userinfo = [];
        try
        {
            $userinfo['countinfo']  =   0;
            $getitem        =   ProductRoleModuleMapModel::from('product_role_module_map AS prmm')->select(DB::raw('distinct prmm.role_id as totalitem, prmm.product_role_module_map_id'))
                                        ->join('roles AS r','r.role_id','=','prmm.role_id')
                                        ->where(function ($query) use ($searchStr) {
                                            if (trim($searchStr) != '') {
                                                return $query->Where('r.name', 'like', '%' . $searchStr . '%')
                                                        ->orWhere('r.description', 'like', '%' . $searchStr . '%')
                                                        ->orWhere('prmm.created_at', 'like', '%' . $searchStr . '%')
                                                        ->orWhere('prmm.is_active', 'like', '%' . $searchStr . '%');
                                            }
                                        })
                                        ->where('prmm.is_deleted', 0)
                                        ->where('prmm.product_id', $productID)
                                        ->groupBy('r.role_id')
                                        ->orderBy('prmm.product_role_module_map_id','desc')
                                        ->get();
            if(count($getitem)>=1){
                $userinfo['countinfo']  =   $getitem[0]->totalitem;
            }
            $userinfo['alldetails'] = ProductRoleModuleMapModel::from('product_role_module_map AS prmm')
                ->join('roles AS r', 'r.role_id', '=', 'prmm.role_id')
                    ->select(DB::raw('prmm.product_role_module_map_id AS ID,r.role_id AS ROLE_ID,r.name AS NAME,r.created_at AS CREATED_DATE,r.is_active,r.role_id'))
                ->where(function ($query) use ($searchStr) {
                    if (trim($searchStr) != '') {
                        return $query->Where('r.name', 'like', '%' . $searchStr . '%')
                                ->orWhere('r.description', 'like', '%' . $searchStr . '%')
                                ->orWhere('prmm.created_at', 'like', '%' . $searchStr . '%')
                                    ->orWhere('prmm.is_active', 'like', '%' . $searchStr . '%');
                        }
                    })
                    ->where('prmm.is_deleted', 0)
                    ->where('prmm.product_id', $productID)
                    ->groupBy('r.role_id')
                    ->orderBy('prmm.product_role_module_map_id', 'desc')
                    ->skip($start)->take($length)
                    ->get();
     
        }
        catch( \Exception $e )
	{           
            return false;
        }    
        return $userinfo;
    }
    
    public static function getProductRoleList($productID) {
        $userinfo = [];
        try
        {
            $userinfo   =   ProductRoleModuleMapModel::from('product_role_module_map AS prmm')
                            ->join('roles AS r', 'r.role_id', '=', 'prmm.role_id')
                            ->select(DB::raw('r.name,r.role_id'))
                            ->where('prmm.is_deleted', 0)
                            ->where('prmm.product_id', $productID)
                            ->groupBy('r.role_id')
                            ->orderBy('prmm.product_role_module_map_id', 'desc')
                            ->get();
                             }
                catch( \Exception $e )
                {           
                    return false;
                }    
                return $userinfo;
    }
    
}

<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductTypeSystemModel extends Model
{    
    protected $table    =   'product_type_system';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_type_system_id';
	protected $fillable =   ['product_id','product_type_enum_id'];
    public function scopeActive($query)
    {
        return $query->where('product_type_system.is_active', 1)->where('product_type_system.is_deleted', 0);
    }
}

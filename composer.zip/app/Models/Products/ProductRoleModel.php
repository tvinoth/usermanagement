<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductRoleModel extends Model
{    
    protected $table    =   'product_role';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_role_id';
	protected $fillable =   ['product_id','role_id'];
    public function scopeActive($query)
    {
        return $query->where('product_role.is_active', 1)->where('product_role.is_deleted', 0);
    }
}

<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductTechnologyModel extends Model
{    
    protected $table    =   'product_technology';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_technology_id';
	protected $fillable =   ['product_id','technology_id'];
    public function scopeActive($query)
    {
        return $query->where('product_technology.is_active', 1)->where('product_technology.is_deleted', 0);
    }
}

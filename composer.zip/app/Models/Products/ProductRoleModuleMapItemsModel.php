<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductRoleModuleMapItemsModel extends Model
{    
    protected $table    =   'product_role_module_map_items';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_role_module_map_items_id';
	protected $fillable =   ['product_role_module_map_id','module_items_code'];
    public function scopeActive($query)
    {
        return $query->where('product_role_module_map_items.is_active', 1)->where('product_role_module_map_items.is_deleted', 0);
    }
}

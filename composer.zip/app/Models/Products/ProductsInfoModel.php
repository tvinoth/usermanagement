<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class ProductsInfoModel extends Model
{    
    protected $table    =   'products_info';
    protected $primaryKey    =   'products_info_id';
    protected $hidden   =   [];
    protected $fillable =   ['product_id','products_version','user_engaged'];
    public function scopeActive($query)
    {
        return $query->where('is_active', 1)->where('is_deleted', 0);
    }
}

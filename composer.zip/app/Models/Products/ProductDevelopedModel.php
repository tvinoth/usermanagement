<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductDevelopedModel extends Model
{    
    protected $table    =   'product_developed';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_developed_id';
	protected $fillable =   ['product_id','user_id'];
    public function scopeActive($query)
    {
        return $query->where('product_developed.is_active', 1)->where('product_developed.is_deleted', 0);
    }
}

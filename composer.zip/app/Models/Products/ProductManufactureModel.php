<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductManufactureModel extends Model
{    
    protected $table    =   'product_manufacture';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_manufacture_id';
	protected $fillable =   ['product_id','hierarchy_id'];
    public function scopeActive($query)
    {
        return $query->where('product_manufacture.is_active', 1)->where('product_manufacture.is_deleted', 0);
    }
}

<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class ProductModel extends Model
{    
    protected $table    =   'products';
    protected $primaryKey    =   'product_id';
//    protected $hidden   =   ['product_app_id','product_token'];
    protected $fillable =   ['product_name','product_token','product_short_name','product_app_id','product_live_url','product_uat_url','product_owner','product_logo'];
    public function scopeActive($query)
    {
        return $query->where('is_active', 1)->where('is_deleted', 0);
    }
    
    public function productInfo() {
        return $this->hasOne('App\Models\Products\ProductsInfoModel','product_id', 'product_id')
                ->select(DB::raw('products_info.product_id,products_info_id,user_engaged,products_version'));
    }
    
    public function productAccess() {
        return $this->hasMany('App\Models\Products\ProductAccessModel','product_id', 'product_id')->Active()
                ->leftJoin('hierarchy', 'hierarchy.hierarchy_id', '=', 'product_access.hierarchy_id')
                ->select(DB::raw('product_access.product_id,hierarchy.hierarchy_name,hierarchy.hierarchy_id'));
    }
    
    public function productContact() {
        return $this->hasMany('App\Models\Products\ProductContactModel','product_id', 'product_id')->Active()
                ->select(DB::raw('product_contact.product_id,product_contact.product_contact_id,product_contact.contact_mail'));
    }
    
    public function productDeveloped() {
        return $this->hasMany('App\Models\Products\ProductDevelopedModel','product_id', 'product_id')->Active()
                ->leftJoin('users as u', 'u.id', '=', 'product_developed.user_id')
                ->select(DB::raw('product_developed.product_id,u.id as user_id,concat(u.first_name," ",u.last_name) AS USER_NAME'));
    }
    
    public function productKeywords() {
        return $this->hasMany('App\Models\Products\ProductKeywordsModel','product_id', 'product_id')->Active()
                ->select(DB::raw('product_keywords.product_id,keywords'));
    }
    
    public function productManufacture() {
        return $this->hasMany('App\Models\Products\ProductManufactureModel','product_id', 'product_id')->Active()
                ->leftJoin('hierarchy', 'hierarchy.hierarchy_id', '=', 'product_manufacture.hierarchy_id')
                ->select(DB::raw('product_manufacture.product_id,hierarchy.hierarchy_name,hierarchy.hierarchy_id'));
    }
    
    public function productOtherTool() {
        return $this->hasMany('App\Models\Products\ProductOtherToolModel','product_id', 'product_id')->Active()
                ->leftJoin('products', 'products.product_id', '=', 'product_other_tools.main_product_id')
                ->select(DB::raw('product_other_tools.product_id,products.product_name'));
    }
    
    public function productRole() {
        return $this->hasMany('App\Models\Products\ProductRoleModel','product_id', 'product_id')->Active()
                ->leftJoin('roles', 'roles.role_id', '=', 'product_role.role_id')
                ->select(DB::raw('product_role.product_id,roles.name,product_role.role_id'));
    }
    
    public function productModule()
    {
        return $this->hasMany('App\Models\MenuManagement\ModuleModel','product_id')->where('module.is_parent',1)->Active();
    }
    
    public function productModuleItems()
    {
        return $this->hasMany('App\Models\MenuManagement\ModuleModel','product_id')
                ->leftJoin('module_items as mi', 'mi.module_id', '=', 'module.module_id')
                ->where('module.is_parent',1)->Active();
    }
    
    public function productSubmodule()
    {
        return $this->hasMany('App\Models\MenuManagement\SubModuleModel','module_id','module_id')->Active();
    }
    
    public function productTechnology() {
        return $this->hasMany('App\Models\Products\ProductTechnologyModel','product_id', 'product_id')->Active()
                ->leftJoin('technology', 'technology.technology_id', '=', 'product_technology.technology_id')
                ->select(DB::raw('product_technology.product_id,technology.name,technology.technology_id'));
    }
    
    public function productTypeSystem() {
        return $this->hasMany('App\Models\Products\ProductTypeSystemModel','product_id', 'product_id')->Active()
                ->leftJoin('product_type_enum as pte', 'pte.product_type_enum_id', '=', 'product_type_system.product_type_enum_id')
                ->select(DB::raw('product_type_system.product_id,pte.product_type_name,pte.product_type_enum_id'));
    }
    
    public static function getUserproductInfo($userid){
            return ProductModel::select(DB::raw('products.*'))->join('user_products','user_products.product_id','=','products.product_id')
                    ->join('users','users.id','=','user_products.user_id')
                    ->where('users.id',$userid)
                    ->where('products.is_active',1)
                    ->where('user_products.is_active',1)
                    ->where('products.is_deleted', 0)
                    ->get();
    }
    
    public static function getProductInfo($searchStr){
            return ProductModel::select(DB::raw('products.*,product_type_enum.product_type_name as PRODUCT_TYPE_NAME'))
                    ->leftjoin('product_type_enum','product_type_enum.product_type_enum_id','=','products.product_type')
                    ->when($searchStr, function ($query) use ($searchStr) {
                            return $query->orWhere('products.product_name', 'like', '%' . $searchStr . '%')
                            ->orWhere('products.product_owner', 'like', '%' . $searchStr . '%')
                            ->orWhere('product_type_enum.product_type_name', 'like', '%' . $searchStr . '%')
                            ->orWhere('products.product_name', 'like', '%' . $searchStr . '%');
                        })
                    ->where('products.is_active',1)
                    ->where('product_type_enum.is_active',1)
                    ->where('products.is_deleted', 0)
                    ->get();
    }
}

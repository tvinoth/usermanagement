<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductKeywordsModel extends Model
{    
    protected $table    =   'product_keywords';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_keywords_id';
	protected $fillable =   ['product_id'];
    public function scopeActive($query)
    {
        return $query->where('product_keywords.is_active', 1)->where('product_keywords.is_deleted', 0);
    }
}

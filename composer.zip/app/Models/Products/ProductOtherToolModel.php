<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductOtherToolModel extends Model
{    
    protected $table    =   'product_other_tools';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_other_tools_id';
	protected $fillable =   ['product_id','main_product_id'];
    public function scopeActive($query)
    {
        return $query->where('product_other_tools.is_active', 1)->where('product_other_tools.is_deleted', 0);
    }
}

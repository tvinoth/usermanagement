<?php

namespace App\Models\Products;

use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class UserRoleModel extends Model {

    protected $table = 'user_roles';
    protected $hidden = [];
    protected $primaryKey = 'user_role_id';
    protected $fillable = ['user_id', 'role_id','product_id'];

    public function scopeActive($query) {
        return $query->where('user_roles.is_active', 1)->where('user_roles.is_deleted', 0);
    }

    public static function getProductUserRoleMapList($productID, $start, $length, $searchStr, $orderColumn, $sorting) {
        $userinfo = [];
        try
        {
            $userinfo['countinfo']  =   UserRoleModel::from('user_roles AS ur')->select(DB::raw('ur.user_role_id'))
                                        ->join('roles AS r','r.role_id','=','ur.role_id')
                                        ->join('users AS u', 'u.id', '=', 'ur.user_id')
                                        ->where(function ($query) use ($searchStr) {
                                            if (trim($searchStr) != '') {
                                                return $query->Where('r.name', 'like', '%' . $searchStr . '%')
                                                        ->orWhere('r.description', 'like', '%' . $searchStr . '%')
                                                        ->orWhere('ur.created_at', 'like', '%' . $searchStr . '%')
                                                        ->orWhere('ur.is_active', 'like', '%' . $searchStr . '%');
                                            }
                                        })
                                        ->where('ur.is_deleted', 0)
                                        ->where('ur.product_id', $productID)
                                        ->orderBy('ur.user_role_id','desc')
                                        ->count();
                                        
            $userinfo['alldetails'] = UserRoleModel::from('user_roles AS ur')
                ->join('roles AS r', 'r.role_id', '=', 'ur.role_id')
                ->join('users AS u', 'u.id', '=', 'ur.user_id')
                    ->select(DB::raw('ur.user_role_id AS ID,ur.user_id AS USER_ID,r.role_id AS ROLE_ID,r.name AS NAME,ur.created_at AS CREATED_DATE,ur.is_active,r.role_id,concat(u.first_name," ",u.last_name) AS USER_NAME'))
                ->where(function ($query) use ($searchStr) {
                    if (trim($searchStr) != '') {
                        return $query->Where('r.name', 'like', '%' . $searchStr . '%')
                                ->orWhere('r.description', 'like', '%' . $searchStr . '%')
                                ->orWhere('ur.created_at', 'like', '%' . $searchStr . '%')
                                    ->orWhere('ur.is_active', 'like', '%' . $searchStr . '%');
                        }
                    })
                    ->where('ur.is_deleted', 0)
                    ->where('ur.product_id', $productID)
                    ->orderBy('ur.user_role_id', 'desc')
                    ->skip($start)->take($length)
                    ->get();
     
        }
        catch( \Exception $e )
	{           
            return false;
        }    
        return $userinfo;
    }
}

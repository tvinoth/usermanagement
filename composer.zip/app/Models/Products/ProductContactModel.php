<?php
namespace App\Models\Products;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ProductContactModel extends Model
{    
    protected $table    =   'product_contact';
    protected $hidden   =   [];
    protected $primaryKey  =   'product_contact_id';
	protected $fillable =   ['product_id','contact_mail'];
    public function scopeActive($query)
    {
        return $query->where('product_contact.is_active', 1)->where('product_contact.is_deleted', 0);
    }
}

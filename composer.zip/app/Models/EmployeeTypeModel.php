<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class EmployeeTypeModel extends Model
{    
    protected $table    =   'emplyoee_type';
    protected $hidden   =   [];
    protected $primaryKey  =   'emplyoee_type_id';
    public function scopeActive($query)
    {
        return $query->where('is_active', 1)->where('is_deleted', 0);
    }
    
    public static function getEmpTypeInfoDetails($start,$length,$searchStr,$orderColumn,$sorting){
        $userinfo   =   [];
        try
        {
            $columnArray    =   [];
            $columnArray[]  =   'emplyoee_type.type_name';
            $columnArray[]  =   'emplyoee_type.description';
            $columnArray[]  =   'emplyoee_type.created_at';
            
            
            if($searchStr == 'active'){
                
            }
            
            DB::enableQueryLog();
            $userinfo['countinfo']  =   EmployeeTypeModel::select(DB::raw('emplyoee_type.emplyoee_type_id'))
                                        ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->Where('emplyoee_type.type_name', 'like', '%' . $searchStr . '%')
                                                ->orWhere('emplyoee_type.description', 'like', '%' . $searchStr . '%')
                                                ->orWhere('emplyoee_type.created_at', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('is_deleted', 0)
                                            ->count();
            
            $userinfo['alldetails']    =   EmployeeTypeModel::Active()->select(DB::raw('emplyoee_type_id as ID,type_name as NAME,created_at as CREATED_DATE,is_active as IS_ACTIVE,description AS DESCRIPTION'))
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->Where('emplyoee_type.type_name', 'like', '%' . $searchStr . '%')
                                                ->orWhere('emplyoee_type.description', 'like', '%' . $searchStr . '%')
                                                ->orWhere('emplyoee_type.created_at', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('is_deleted', 0)
                                            ->skip($start)->take($length)
                                            ->get();
        }
        catch( \Exception $e )
	{           
            return false;
        }    
        return $userinfo;
    }
}

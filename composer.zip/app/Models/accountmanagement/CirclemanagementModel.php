<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class UsermanagementModel extends Model
{    
    protected $table    =   'users';
    protected $hidden   =   ['password', 'remember_token'];
    public function scopeActive($query)
    {
        return $query->where('is_active', 1);
    }
    
    public static function getUserallInfoDetails($start,$length,$searchStr,$orderColumn,$sorting){
        $userinfo   =   [];
        try
        {
            $columnArray    =   [];
            $columnArray[]  =   'users.first_name';
            $columnArray[]  =   'ui.employee_id';
            $columnArray[]  =   'ui.team_id';
            $columnArray[]  =   'users.created_at';
            
            $userinfo['countuserinfo']  =   UsermanagementModel::select(DB::raw('users.id'))
                                            ->join('users_info as ui','ui.user_id','=','users.id')
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->where('users.first_name', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('users.middle_name', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('users.last_name', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('ui.team_id', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('users.created_at', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('users.is_active', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('users.is_deleted',0)
                                            ->count();
                                            DB::enableQueryLog();
            $userinfo['userdetails']    =   UsermanagementModel::select(DB::raw('users.*,users.id as USER_ID,users.created_at as CREATED_DATE,ui.*,concat(users.first_name," ",users.last_name) AS USER_NAME'))
                                            ->join('users_info as ui','ui.user_id','=','users.id')
                                            ->orderBy($columnArray[$orderColumn], $sorting)
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                                return $query->where('users.first_name', 'like', '%' . $searchStr . '%')
                                                                ->orWhere('users.middle_name', 'like', '%' . $searchStr . '%')
                                                                ->orWhere('users.last_name', 'like', '%' . $searchStr . '%')
                                                                ->orWhere('ui.team_id', 'like', '%' . $searchStr . '%')
                                                                ->orWhere('users.created_at', 'like', '%' . $searchStr . '%')
                                                                ->orWhere('users.is_active', 'like', '%' . $searchStr . '%');
                                                            })
                                            ->where('users.is_deleted',0)
                                            ->skip($start)->take($length)
                                            ->get();
//                                                            $a = DB::getQueryLog($userinfo['userdetails']);
//                                                            print_r($a);exit;
        }
        catch( \Exception $e )
	{           
            return false;
        }    
        return $userinfo;
    }
    
    public static function getUserInfo($id){
            return UsermanagementModel::select(DB::raw('users.*,users_info.*'))->join('users_info','users_info.user_id','=','users.id')
                    ->where('users.id',$id)
                    ->first();
    }
}

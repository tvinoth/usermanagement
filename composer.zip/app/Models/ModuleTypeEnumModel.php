<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class ModuleTypeEnumModel extends Model
{    
    protected $table    =   'module_type_enum';
    protected $hidden   =   [];
    protected $primaryKey  =   'module_type_enum_id';
    public function scopeActive($query)
    {
        return $query->where('is_active', 1);
    }
}

<?php
namespace App\Models\HierarchyManagement;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class HierarchyModel extends Model
{    
    protected $table        =   'hierarchy';
    protected $primaryKey   =   'hierarchy_id';
    public $fillable        =   ['hierarchy_name','parent_id'];
    
    public function scopeActive($query)
    {
        return $query->where('is_active', 1)->where('is_deleted', 0);
    }
    
    public function childs() {
        return $this->hasMany('App\Models\HierarchyManagement\HierarchyModel','parent_id','hierarchy_id') ;
    }
    
    public static function getHierarchyDetails($start,$length,$searchStr,$orderColumn,$sorting){
        $userinfo   =   [];
        try
        {
            $columnArray    =   [];
            $columnArray[]  =   'hierarchy_id';
            $columnArray[]  =   'hierarchy_name';
            $columnArray[]  =   'description';
            $columnArray[]  =   'created_at';
            
            $userinfo['countinfo']      =   HierarchyModel::select(DB::raw('hierarchy_id'))
                                            ->leftjoin('users AS u1','u1.id','=','hierarchy.primary_incharge')
                                            ->leftjoin('users AS u2','u2.id','=','hierarchy.secondary_incharge')
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->where('hierarchy_name', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('description', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('hierarchy.created_at', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('hierarchy.is_active', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('hierarchy.is_deleted',0)
                                            ->count();
                                            
            $userinfo['alldetails']     =   HierarchyModel::select(DB::raw('hierarchy_id as ID,hierarchy_name as NAME,concat(u1.first_name," ",u1.last_name) AS PRIMARY_NAME,concat(u2.first_name," ",u2.last_name) AS SECONDARY_NAME,description as DESCRIPTION,primary_incharge AS P_INCHARGE,secondary_incharge AS S_INCHARGE,hierarchy.is_active as IS_ACTIVE,hierarchy.created_at as CREATED_DATE'))
//                                            ->leftjoin('users', function($join)
//                                                {
//                                                    $join->on('users.id', '=', 'hierarchy.primary_incharge');
//                                                    $join->on('users.id', '=', 'hierarchy.secondary_incharge');
//                                                })
                                            ->leftjoin('users AS u1','u1.id','=','hierarchy.primary_incharge')
                                            ->leftjoin('users AS u2','u2.id','=','hierarchy.secondary_incharge')
                                            ->orderBy($columnArray[$orderColumn], $sorting)
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->where('hierarchy_name', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('description', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('hierarchy.created_at', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('hierarchy.is_active', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('hierarchy.is_deleted',0)
                                            ->skip($start)->take($length)
                                            ->get();
        }
        catch( \Exception $e )
	{           
            return false;
        }    
        return $userinfo;
    }
}

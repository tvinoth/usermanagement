<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class RolesModel extends Model
{    
    protected $table    =   'roles';
    protected $hidden   =   [];
    protected $primaryKey  =   'role_id';
    protected $fillable   =   ['name','description','product_id','role_code'];
    public function scopeActive($query)
    {
        return $query->where('is_active', 1)->where('is_deleted', 0);
    }
    
    public static function getRoleInfoDetails($start,$length,$searchStr,$orderColumn,$sorting){
        $userinfo   =   [];
        try
        {
            $columnArray    =   [];
            $columnArray[]  =   'roles.name';
            $columnArray[]  =   'roles.description';
            $columnArray[]  =   'roles.created_at';
            $userinfo['countinfo']  =   RolesModel::select(DB::raw('roles.role_id'))
                                        ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->orWhere('roles.name', 'like', '%' . $searchStr . '%')
                                                ->orWhere('roles.description', 'like', '%' . $searchStr . '%')
                                                ->orWhere('roles.created_at', 'like', '%' . $searchStr . '%')
                                                ->orWhere('roles.is_active', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('is_deleted', 0)
                                            ->count();
            $userinfo['alldetails']    =   RolesModel::select(DB::raw('role_id as ID,name as NAME,created_at as CREATED_DATE,is_active,description AS DESCRIPTION'))
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->orWhere('roles.name', 'like', '%' . $searchStr . '%')
                                                ->orWhere('roles.description', 'like', '%' . $searchStr . '%')
                                                ->orWhere('roles.created_at', 'like', '%' . $searchStr . '%')
                                                ->orWhere('roles.is_active', 'like', '%' . $searchStr . '%');
                                            })
                                            ->where('is_deleted', 0)
                                            ->skip($start)->take($length)
                                            ->get();
        }
        catch( \Exception $e )
	{           
            return false;
        }    
        return $userinfo;
    }
}

<ul>
@foreach($childs as $child)
	<li>
            @if(count($child->childs))
	    <i class="indicator glyphicon glyphicon-plus-sign"></i>
            @endif
            <label class='{{$hierarchyID == $child->hierarchy_id?"selectedhighlight":""}} pointer'>
                <input type="checkbox" name="HierarchyParent" data-hierarchyname="{{ $child->hierarchy_name }}"  {{$hierarchyID == $child->hierarchy_id?"checked":""}} value="{{$child->hierarchy_id}}">&nbsp;{{ $child->hierarchy_name }}</label>
	@if(count($child->childs))
            @include('HierarchyManagement.manageHierarchychild',['childs' => $child->childs])
        @endif
	</li>
@endforeach
</ul>
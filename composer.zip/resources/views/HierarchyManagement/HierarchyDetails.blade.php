@extends('layouts.mainapp')
@section('content')

<style>
    .selectedhighlight {
    background-color: #ff9800 !important;
    color: white;
    border: solid 2px #e28804;
    padding: 2px 7px;
    border-radius: 2px;
}
.hierarchy, .hierarchy ul {
    margin:0;
    padding:0;
    list-style:none
}
.hierarchy ul {
    margin-left:1em;
    position:relative
}
.hierarchy ul ul {
    margin-left:.5em
}
.hierarchy ul:before {
    content:"";
    display:block;
    width:0;
    position:absolute;
    top:0;
    bottom:0;
    left:0;
    border-left:1px solid
}
.hierarchy li {
    margin:0;
    padding:0 1em;
    line-height:2em;
    color:#369;
    font-weight:700;
    position:relative
}
.hierarchy ul li:before {
    content:"";
    display:block;
    width:10px;
    height:0;
    border-top:1px solid;
    margin-top:-1px;
    position:absolute;
    top:1em;
    left:0
}
.hierarchy ul li:last-child:before {
    background:#fff;
    height:auto;
    top:1em;
    bottom:0
}
.indicator {
    margin-right:5px;
}
.hierarchy li a {
    text-decoration: none;
    color:#369;
}
.hierarchy li button, .hierarchy li button:active, .hierarchy li button:focus {
    text-decoration: none;
    color:#369;
    border:none;
    background:transparent;
    margin:0px 0px 0px 0px;
    padding:0px 0px 0px 0px;
    outline: 0;
}
</style>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b>{{$modulename}}</b></small></h1>
            <ol class="breadcrumb">
            <li><a href="{{url('home')}}"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="{{url('hierarchymanagement')}}"> Hierarchy </a></li>
            </ol>
        </section>
        
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class="active"><a href="#all_data" data-toggle="tab">All Hieararchy</a></li>
                    <li class=""><a href="#new_data" data-toggle="tab">Hieararchy</a></li>
                    <li class="taggleusertab" style="display:none" id="showupdate_data"><a href="#update_data" data-toggle="tab">Update Hieararchy</a></li>
                    <li class="taggleusertab" style="display:none" id="showview_data"><a href="#view_data" class="showview_users" data-toggle="tab">View Hieararchy</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">    
                        <div class="box-body">
                            <table id="dataList" class="table table-bordered table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Primary Incharge</th>
                                        <th>Secondary Incharge</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>      
                                </tbody>    
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="new_data">
                        <br>
                        <div class="row">
                        <form method="POST" action="{{url('api/doAddHierarchy')}}" id="SectionForm" accept-charset="UTF-8" class="form-horizontal" role="form" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <section class="col-md-6">
	  					<h3>Hierarchy List</h3>
                                                
<!--                                                <div class="form-group">
                <label class="">
                  <div class="icheckbox_flat-green checked" aria-checked="true" style="position: relative;"><input type="checkbox" class="flat-red" checked="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>
                </label>
                <label class="">
                  <div class="icheckbox_flat-green checked" aria-checked="true" aria-disabled="false" style="position: relative;"><input type="checkbox" class="flat-red" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>
                </label>
              </div>-->
                            <ul id="tree1">
                                @foreach($categories as $category)
                                    <li>
                                    @if(count($category->childs))
                                        <i class="indicator glyphicon glyphicon-plus-sign"></i>
                                    @endif
                                    @if(count($category->childs) == 0)
                                        <i class="fa fa-fw fa-square"></i>
                                    @endif
                                    <label class="">
                                        <input type="checkbox" name="HierarchyParent" data-hierarchyname="{{ $category->hierarchy_name }}" value="{{$category->hierarchy_id}}">&nbsp;{{ $category->hierarchy_name }}
                                    </label>
                                        @if(count($category->childs))
                                            @include('HierarchyManagement.manageHierarchychild',['childs' => $category->childs])
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                            </section>
                            
                            <section class="col-lg-6">
                                <h3>Add Hierarchy</h3>

                                    <div class="form-group required">
                                        <label class=" col-lg-3 control-label company-label">Hierarchy Name</label>
                                        <div class="col-lg-5">
                                            <input class="form-control required_field" maxlength="150" required="true" name="hierarchy_name" type="text">
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class=" col-lg-3 control-label">Hierarchy Description</label>
                                        <div class="col-lg-5">
                                        <input class="form-control required_field" maxlength="150" required="true" name="description" type="text">
                                        <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    <div class="form-group required">
                                        <label class=" col-lg-3 control-label company-label">Primary Incharge</label>
                                        <div class="col-lg-5">
                                            <select class="form-control required_field" required="true" name="primary_incharge">
                                            <option value="">--Select--</option>
                                                @foreach($userinfo as $value)
                                                     <option value="{{ $value->USER_ID }}">
                                                         {{ $value->USER_NAME }}
                                                     </option>
                                                 @endforeach
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    <div class="form-group required">
                                        <label class=" col-lg-3 control-label company-label">Secondary Incharge</label>
                                        <div class="col-lg-5">
                                            <select class="form-control required_field" required="true" name="secondary_incharge">
                                            <option value="">--Select--</option>
                                                @foreach($userinfo as $value)
                                                     <option value="{{ $value->USER_ID }}">
                                                         {{ $value->USER_NAME }}
                                                     </option>
                                                 @endforeach
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>

                            <input type="hidden" name="app_id" value="fsafr">
                            <input type="hidden" name="app_token" value="fsa5685t">
                            <input type="hidden" name="ip_address" value="172.24.183.332">
                            <div class="form-group row">
                                <div class="col-lg-4"></div>
                                <div class="col-lg-1">
                                    <!--<button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>-->
                                </div>
                                <div class="col-lg-1">
                                    <button type="submit" class="btn btn-primary" id="AddSection">  <i class="fa fa-fw fa-plus-square"> </i> Add New</button>
                                </div>
                                <div class="col-lg-4"></div>
                            </div>
                            </section>
                        </form>
                        </div>
                    </div>
                    <div class="tab-pane fade removeshowactive" id="update_data">
                    <br>


                </div>

                <div class="tab-pane fade removeshowactive" id="view_data">
                    <br>


                </div>
                </div>
                
            </div>
        </section>
    </div>

        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog ">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header deletemodal">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Delete User</h4>
                    </div>
                    <form class="form-horizontal" action="{{url('api/doHierarchyDelete')}}" method="post" id="DeleteSectionForm">   
                    {{ csrf_field() }}
                    <div class="row">
                      <div class="col-md-12">
                          <div class="form-group required">
                            <input type="hidden" id="hierarchyId" name="hierarchyId" >
                            <input type="hidden" id="appId" name="app_id" >
                            <input type="hidden" id="appToken" name="app_token" >
                            <input type="hidden" id="ip_address" name="ip_address" value="172.24.183.33">
                          </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </form>
                    <div class="modal-body">
                        Are you sure you want to delete a <b><span id='username'></span></b>?

                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                        <button type="button" class="btn btn-danger" id="DeleteSection"><i class="fa fa-user-times"></i> Confirm Delete</button>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
@endsection

@section('bottomScripts')
<script>
    $(document).ready(function()
    {
        $(document).on('click','#usertabmenuactivity',function () {
            if($("#usertabmenuactivity li:visible").length >2 ){
                $(".taggleusertab").each(function(){
                    $(this).hide();
                });
                 $(".removeshowactive").removeClass('show active in');
            }
        });
    });
     
var datatable_url   =   {!! "'".url('api/doGetHierarchyList')."'" !!};
var token           =   {!! "'".csrf_token()."'" !!};

$.fn.dataTable.ext.errMode  =   'none';
var sectionList     =   $('#dataList').DataTable({
            "fixedHeader": true,
            "processing": true,
            "serverSide": true,
                ajax: {
                        url: datatable_url,
                        type: 'POST',
                        'data': {
                            _token: token,
                        },
                    },
                    "initComplete": function(settings, json) {
//                    console.log(json);
                    },
            "order": [[ 1, "desc" ]],
            fixedHeader: {
                header: true,
                footer: true
            }
        });



    function sectionListReload(){
        sectionList.clear().draw();
    }
    
    $.fn.extend({
    treed: function (o) {
      
      var openedClass = 'glyphicon-minus-sign';
      var closedClass = 'glyphicon-plus-sign';
      
      if (typeof o != 'undefined'){
        if (typeof o.openedClass != 'undefined'){
        openedClass = o.openedClass;
        }
        if (typeof o.closedClass != 'undefined'){
        closedClass = o.closedClass;
        }
      };
      
        /* initialize each of the top levels */
        var tree = $(this);
        tree.addClass("hierarchy");
        tree.find('li').has("ul").each(function () {
            var branch = $(this);
            branch.prepend("");
            branch.addClass('branch');
            branch.on('click', function (e) {
                if (this == e.target) {
                    var icon = $(this).children('i:first');
                    icon.toggleClass(openedClass + " " + closedClass);
                    $(this).children().children().toggle();
                }
            })
            branch.children().children().toggle();
        });
        /* fire event from the dynamically added icon */
        tree.find('.branch .indicator').each(function(){
            $(this).on('click', function () {
                $(this).closest('li').click();
            });
        });
        /* fire event to open branch if the li contains an anchor instead of text */
        tree.find('.branch>a').each(function () {
            $(this).on('click', function (e) {
                $(this).closest('li').click();
                e.preventDefault();
            });
        });
        /* fire event to open branch if the li contains a button instead of text */
        tree.find('.branch>button').each(function () {
            $(this).on('click', function (e) {
                $(this).closest('li').click();
                e.preventDefault();
            });
        });
    }
});
/* Initialization of treeviews */
$('#tree1').treed();

    function viewUserinfo(id,thisdata)
    {
        var methodtype  =   $(thisdata).attr('data-type');
        $('#usertabmenuactivity').find('li').each(function(e){
            $(this).removeClass('active'); 
        });
        $('div.tab-pane').each(function(){
            $(this).removeClass('in show active');
        });
        if(methodtype   ==  "update"){
            $("#showupdate_data").css('display','block');
            $("#showupdate_data").addClass('active');
            $("#update_data").addClass('in show active');
        }else{
            $("#showview_data").css('display','block');
            $("#showview_data").addClass('active');
            $("#view_data").addClass('in show active');
        }
          
          
        var postdata    =   {'app_id':10,'app_token':'25156','hierarchyId':id,'methodtype':methodtype}
        $.ajax({
            type    :   "POST",
            url     :   '{{url("api/doViewHierarchyInfo")}}',
            dataType:   "html",
            data    :   postdata,
            success: function(data) {
                if(methodtype   ==  "update")
                $("#update_data").html(data);
                else
                $("#view_data").html(data);
            }
        });
    }
    
    $( "#AddSection" ).click(function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SectionForm" ).serialize();
        var parent_id   =   $("input[name='HierarchyParent']:checked").val();
        formData        =   formData+'&parent_id='+parent_id;
        var url         =   $( "#SectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }
                    $.notify(data.Message,'success');
                    $('#SectionForm')[0].reset();
                    sectionListReload();
                }
           });
        }
    });
    
    // delete
    $( "div" ).on( "click", ".deleteSection", function() {
        var id          =   this.id;
        var username    =   $(this).data('deleteusername');
        var sectionID   =   id.replace("deleteSection_", "");
        $("#hierarchyId").val(sectionID);
        $("#appId").val('fertert');
        $("#appToken").val('fe2652');
        $("#username").text(username);
    });
     
    $( "#DeleteSection" ).click(function() {   //Update      
        var formData    =   $( "#DeleteSectionForm" ).serialize();
        var url         =   $( "#DeleteSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#DeleteSectionForm .required_field').each(function(index){
            var value   =   $(this).val();
            value       =   value.trim();
            if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });

        if(validation  ==  true){
           var postdata    =   formData;
           $.ajax({
               type    :   "DELETE",
               url     :   url,
               data    :   postdata,
               success: function(data) {
                   if(data.Status == 1){
                       $.notify(data.Message,'success');
                       sectionListReload(); 
                       $('#modal-delete').trigger('click');
                   }
                   $.notify(data.Message,'danger');
               }
           });
        }
    });
    
    $("input:checkbox").on('click', function() {
        var $box    =   $(this);
        var getname =   $box.data('hierarchyname');
        $("input[name='hierarchy_name']").val(getname);
        if ($box.is(":checked")) {
          var group =   "input:checkbox[name='" + $box.attr("name") + "']";
          $(group).prop("checked", false);
            $("li label").removeClass('selectedhighlight'); 
            $(this).parent().addClass('selectedhighlight');
          $box.prop("checked", true);
        } else {
            $("li label").removeClass('selectedhighlight'); 
          $box.prop("checked", false);
        }
    });
    
    
    
//    //iCheck for checkbox and radio inputs
//    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
//      checkboxClass: 'icheckbox_minimal-blue',
//      radioClass   : 'iradio_minimal-blue'
//    })
//    //Red color scheme for iCheck
//    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
//      checkboxClass: 'icheckbox_minimal-red',
//      radioClass   : 'iradio_minimal-red'
//    })
//    //Flat red color scheme for iCheck
//    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
//      checkboxClass: 'icheckbox_flat-green',
//      radioClass   : 'iradio_flat-green'
//    })

</script> 

@stop
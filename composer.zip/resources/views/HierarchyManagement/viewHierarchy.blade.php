   <style>
ul,li{
    list-style:none;
}
.selectedhighlight {
    background-color: #ff9800 !important;
    color: white;
    border: solid 2px #e28804;
    padding: 2px 7px;
    border-radius: 2px;
}
   </style> 
    @if($methodtype   ==  "view")    

    <section class="content">
        <div class="box-default" data-collapsed="0">
        
        <div class="box-body" id="viewFrm">

            <div class="row">
                <div class="col-sm-6 form-horizontal">
                    <ul id="tree1">
                        @foreach($categories as $category)
                            <li>
                            @if(count($category->childs))
                                <i class="indicator glyphicon glyphicon-plus-sign"></i>
                            @endif
                            @if(count($category->childs) == 0)
                                <i class="fa fa-fw fa-square"></i>
                            @endif
                            <label class='{{$hierarchyID == $category->hierarchy_id?"selectedhighlight":""}} pointer'>
                                <input type="checkbox" name="HierarchyParent" data-hierarchyname="{{ $category->hierarchy_name }}"  {{$hierarchyID == $category->hierarchy_id?"checked":""}} value="{{$category->hierarchy_id}}">&nbsp;{{ $category->hierarchy_name }}</label>
                                @if(count($category->childs))
                                    @include('HierarchyManagement.manageHierarchychild',['childs' => $category->childs])
                                @endif
                            </li>
                        @endforeach
                    </ul>
                </div>
                <div class="col-sm-6 form-horizontal">
                    @if($hierarchydetails !=    null)
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Hierarchy Name</label>
                        <div class="col-lg-5">
                            <input class="form-control required_field" maxlength="150" required="true" name="hierarchy_name" value="{{$hierarchydetails->hierarchy_name}}" type="text">
                            <span class="text-danger"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class=" col-lg-3 control-label">Hierarchy Description</label>
                        <div class="col-lg-5">
                        <input class="form-control required_field" maxlength="150" required="true" value="{{$hierarchydetails->description}}" name="description" type="text">
                        <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Primary Incharge</label>
                        <div class="col-lg-5">
                            <select class="form-control required_field" required="true" name="primary_incharge">
                            <option value="">--Select--</option>
                                @foreach($userinfo as $value)
                                     <option value="{{ $value->USER_ID }}" {{ $value->USER_ID   ==  $hierarchydetails->primary_incharge?'selected':''}}>
                                         {{ $value->USER_NAME }}
                                     </option>
                                 @endforeach
                             </select>
                            <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Secondary Incharge</label>
                        <div class="col-lg-5">
                            <select class="form-control required_field" required="true" name="secondary_incharge">
                            <option value="">--Select--</option>
                                @foreach($userinfo as $value)
                                     <option value="{{ $value->USER_ID }}" {{ $value->USER_ID   ==  $hierarchydetails->secondary_incharge?'selected':''}}>
                                         {{ $value->USER_NAME }}
                                     </option>
                                 @endforeach
                             </select>
                            <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Temporary Incharge</label>
                        <div class="col-lg-5">
                            <select class="form-control required_field" required="true" name="temporary_incharge">
                            <option value="">--Select--</option>
                                @foreach($userinfo as $value)
                                     <option value="{{ $value->USER_ID }}" {{ $value->USER_ID   ==  $hierarchydetails->temporary_incharge?'selected':''}}>
                                         {{ $value->USER_NAME }}
                                     </option>
                                 @endforeach
                             </select>
                            <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    @endif
                </div>
            </div>  
                
        </div>
        </div>
    </section>
    
    
    @elseif($methodtype   ==  "update")    
    <section class="content">
        <div class="box-default" data-collapsed="0">
        
        <div class="box-body">
            <div class="row">
                <form method="POST" action="{{url('api/doUpdateHierarchyInfo')}}" id="UpdateSectionForm" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
                <div class="col-sm-6 form-horizontal">
                
                    {{ csrf_field() }}
                            <input type="hidden" name="app_id" value="fsafr">
                            <input type="hidden" name="app_token" value="fsa5685t">
                            <input type="hidden" name="ip_address" value="172.24.183.332">


                    <ul id="tree1">
                        @foreach($categories as $category)
                            <li>
                            @if(count($category->childs))
                                <i class="indicator glyphicon glyphicon-plus-sign"></i>
                            @endif
                            @if(count($category->childs) == 0)
                                <i class="fa fa-fw fa-square"></i>
                            @endif
                            <label class='{{$hierarchyID == $category->hierarchy_id?"selectedhighlight":""}} pointer'><input type="checkbox" name="HierarchyParent" data-hierarchyname="{{ $category->hierarchy_name }}"  {{$hierarchyID == $category->hierarchy_id?"checked":""}} value="{{$category->hierarchy_id}}">&nbsp;{{ $category->hierarchy_name }}</label>
                                @if(count($category->childs))
                                    @include('HierarchyManagement.manageHierarchychild',['childs' => $category->childs])
                                @endif
                            </li>
                        @endforeach
                    </ul>
                </div>
                
                <div class="col-sm-6 form-horizontal">
                    @if($hierarchydetails !=    null)
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Hierarchy Name</label>
                        <div class="col-lg-5">
                            <input class="form-control required_field" maxlength="150" required="true" name="hierarchy_name" value="{{$hierarchydetails->hierarchy_name}}" type="text">
                            <span class="text-danger"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class=" col-lg-3 control-label">Hierarchy Description</label>
                        <div class="col-lg-5">
                        <input class="form-control required_field" maxlength="150" required="true" value="{{$hierarchydetails->description}}" name="description" type="text">
                        <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    <input type="hidden" name="hierarchyId" value="{{$hierarchydetails->hierarchy_id}}">
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Primary Incharge</label>
                        <div class="col-lg-5">
                            <select class="form-control required_field" required="true" name="primary_incharge">
                            <option value="">--Select--</option>
                                @foreach($userinfo as $value)
                                     <option value="{{ $value->USER_ID }}" {{ $value->USER_ID   ==  $hierarchydetails->primary_incharge?'selected':''}}>
                                         {{ $value->USER_NAME }}
                                     </option>
                                 @endforeach
                             </select>
                            <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Secondary Incharge</label>
                        <div class="col-lg-5">
                            <select class="form-control required_field" required="true" name="secondary_incharge">
                            <option value="">--Select--</option>
                                @foreach($userinfo as $value)
                                     <option value="{{ $value->USER_ID }}" {{ $value->USER_ID   ==  $hierarchydetails->secondary_incharge?'selected':''}}>
                                         {{ $value->USER_NAME }}
                                     </option>
                                 @endforeach
                             </select>
                            <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Temporary Incharge</label>
                        <div class="col-lg-5">
                            <select class="form-control required_field" required="true" name="temporary_incharge">
                            <option value="">--Select--</option>
                                @foreach($userinfo as $value)
                                     <option value="{{ $value->USER_ID }}" {{ $value->USER_ID   ==  $hierarchydetails->temporary_incharge?'selected':''}}>
                                         {{ $value->USER_NAME }}
                                     </option>
                                 @endforeach
                             </select>
                            <span class="text-danger"></span>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <button type="button" class="btn btn-primary" id="UpdateSection"> <i class="fa fa-save"> </i> Save Changes</button>
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                    
                </form>
                    @endif
                </div>
        </div>
        </div>
    </section>
    @else
    <h1>No Data found</h1>
    @endif
    <script>
        var methoddata  =   "<?php echo $methodtype; ?>";
    if(methoddata   ==  "view"){
        $("#viewFrm").find(':input').prop("disabled", true);
    }         
        $( "#UpdateSection" ).click(function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#UpdateSectionForm" ).serialize();
        var parent_id   =   $("input[name='HierarchyParent']:checked").val();
        formData        =   formData+'&parent_id='+parent_id;
        var url         =   $( "#UpdateSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#UpdateSectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }
                    $.notify(data.Message,'success');
//                    $("#showupdate_users").css('display','none');
                    sectionListReload();
                }
           });
        }
    });
    $.fn.extend({
    treed: function (o) {
      
      var openedClass = 'glyphicon-minus-sign';
      var closedClass = 'glyphicon-plus-sign';
      
      if (typeof o != 'undefined'){
        if (typeof o.openedClass != 'undefined'){
        openedClass = o.openedClass;
        }
        if (typeof o.closedClass != 'undefined'){
        closedClass = o.closedClass;
        }
      };
      
        /* initialize each of the top levels */
        var tree = $(this);
        tree.addClass("hierarchy");
        tree.find('li').has("ul").each(function () {
            var branch = $(this);
            branch.prepend("");
            branch.addClass('branch');
            branch.on('click', function (e) {
                if (this == e.target) {
                    var icon = $(this).children('i:first');
                    icon.toggleClass(openedClass + " " + closedClass);
                    $(this).children().children().toggle();
                }
            })
            branch.children().children().toggle();
        });
        /* fire event from the dynamically added icon */
        tree.find('.branch .indicator').each(function(){
            $(this).on('click', function () {
                $(this).closest('li').click();
            });
        });
        /* fire event to open branch if the li contains an anchor instead of text */
        tree.find('.branch>a').each(function () {
            $(this).on('click', function (e) {
                $(this).closest('li').click();
                e.preventDefault();
            });
        });
        /* fire event to open branch if the li contains a button instead of text */
        tree.find('.branch>button').each(function () {
            $(this).on('click', function (e) {
                $(this).closest('li').click();
                e.preventDefault();
            });
        });
    }
});$("input:checkbox").on('click', function() {
        var $box    =   $(this);
        
        var getname = $box.data('hierarchyname');
        $("input[name='hierarchy_name']").val(getname);
        if ($box.is(":checked")) {
          var group =   "input:checkbox[name='" + $box.attr("name") + "']";
          $(group).prop("checked", false);
          $("li label").removeClass('selectedhighlight'); 
        $(this).parent().addClass('selectedhighlight');
          $box.prop("checked", true);
        } else {
            $("li label").removeClass('selectedhighlight'); 
          $box.prop("checked", false);
        }
    });
    </script>
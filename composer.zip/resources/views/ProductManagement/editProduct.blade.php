@extends('layouts.mainapp')
@section('content')
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b>{{$modulename}} - {{$productinfo->product_name}}</b></small></h1>
            <ol class="breadcrumb">
            <li><a href="{{url('home')}}"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="{{url('product/productdetails')}}"> Product</a></li>
            </ol>
        </section>
        <!--<section class="">
            <div class="col-sm-10"></div>
            <div class="col-sm-2">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-info">
                    <i class="fa fa-user-plus"> </i> ADD USER
                </button>
            </div>
        </section><br><br>-->
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class="active"><a href="{{url('product/editproduct/'.$encryptproductID)}}" data-toggle="tab">Product</a></li>
                    <li class=""><a href="{{url('product/productmodule/'.$encryptproductID)}}">Module</a></li>
                    <li class=""><a href="{{url('product/productrole/'.$encryptproductID)}}">Roles</a></li>
                    <li class=""><a href="{{url('product/productaccess/'.$encryptproductID)}}">User Access</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">    
                        <div class="row">
                        <form method="POST" action="{{url('api/product/updateProduct')}}" id="SectionForm" accept-charset="UTF-8" class="form-horizontal" role="form" enctype="multipart/form-data">
                                {{ csrf_field() }}
                            <section class="col-lg-6 connectedSortable">
                                <div class=""><div id="roll" class="list-group"><p href="#" class="list-group-item disabled">Primary Info</p></div>
                                        <div class="box-body">
                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Product Name <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" name="product_name" type="text" value="{{ old('product_name', isset($productinfo->product_name) ? $productinfo->product_name : '') }}">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>

                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Product Owner <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" required="true" name="product_owner" type="text" value="{{ old('product_owner', isset($productinfo->product_owner) ? $productinfo->product_owner : '') }}">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Product Short Name <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control" maxlength="150" required="true" type="text" value="{{ old('product_short_name', isset($productinfo->product_short_name) ? $productinfo->product_short_name : '') }}" disabled="true" readonly="true">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>

                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">UAT Link <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" required="true" name="product_uat_url" type="url" value="{{ old('product_uat_url', isset($productinfo->product_uat_url) ? $productinfo->product_uat_url : '') }}">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>


                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Live Link <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input class="form-control required_field" maxlength="150" required="true" name="product_live_url" type="url" value="{{ old('product_live_url', isset($productinfo->product_live_url) ? $productinfo->product_live_url : '') }}">
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>
                                    
                                            <div class="form-group required">
                                                <label class="col-lg-2 control-label company-label">Description</label>
                                                <div class="col-lg-10">
                                                <textarea class="required_field" id="editor1" name="description" rows="10" cols="80">{{ old('description', isset($productinfo->product_description) ? $productinfo->product_description : '') }}
                                                </textarea>
                                                    <span class="text-danger"></span>
                                                </div>
                                            </div>


                                            <div class="form-group required">
                                                <label for="field-1" class="col-lg-2 control-label">Product Type <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <select name="product_type[]" class="form-control required_field">
                                                        <option value=""> --Select--</option>
                                                        @foreach($productenumtype as $value)
                                                            @forelse($productinfo->productTypeSystem as $productvalue)
                                                            <option value="{{ $value->product_type_enum_id }}" {{$productvalue->product_type_enum_id == $value->product_type_enum_id?'selected':''}}>{{ $value->product_type_name }}</option>
                                                            @empty
                                                            <option value="{{ $value->product_type_enum_id }}">{{ $value->product_type_name }}</option>
                                                            @endforelse
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="form-group required">
                                                <label for="field-1" class="col-lg-2 control-label">Other Tools Integrated <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <select name="other_tool[]" class="form-control required_field">
                                                        <option value=""> --Select--</option>
                                                        @foreach($productdetails as $value)
                                                            @forelse($productinfo->productOtherTool as $productvalue)
                                                            <option value="{{ $value->product_id }}" {{$productvalue->product_id == $value->product_id?'selected':''}}>{{ $value->product_name }}</option>
                                                            @empty
                                                            <option value="{{ $value->product_id }}">{{ $value->product_name }}</option>
                                                            @endforelse
                                                         @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group required">
                                                <label for="field-1" class="col-lg-2 control-label">Role<span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <select name="product_role[]" class="form-control required_field">
                                                        <option value=""> --Select--</option>
                                                        @foreach($productrole as $value)
                                                            @forelse($productinfo->productRole as $productvalue)
                                                            <option value="{{ $value->role_id }}" {{$productvalue->role_id == $value->role_id?'selected':''}}>{{ $value->name }}</option>
                                                            @empty
                                                            <option value="{{ $value->role_id }}">{{ $value->name }}</option>
                                                            @endforelse
                                                         @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-lg-2 control-label">Product Logo <span class="red">*</span></label>
                                                <div class="col-lg-10">
                                                    <input type="file" accept=".jpg,gif,png,jpeg" id="uploaduserimage" class="form-control" name="product_logo" value="{{ old('product_logo', isset($productinfo->product_logo) ? $productinfo->product_logo : '') }}">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="col-lg-5"></div>
                                                <div class="col-lg-5">
                                                    <center><img src="{{url($productinfo->product_logo)}}" id="previewuploaduserimage"  class="img-circle" alt="Product Image" style="width:15%;height:15%"></center>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </section>
                                
                            <section class="col-lg-6 connectedSortable">
                                <div class=""><div id="roll" class="list-group"><p href="#" class="list-group-item disabled">Secondary Info</p></div>
                                <div class="box-body">
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Version <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <input id="lname" class="form-control required_field" maxlength="150" required="true" value="{{ old('version', isset($productinfo->productInfo->products_version) ? $productinfo->productInfo->products_version : '') }}" name="version" type="text">
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">User Engaged <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <input id="lname" class="form-control required_field" maxlength="150" required="true" name="user_engaged" value="{{ old('user_engaged', isset($productinfo->productInfo->user_engaged) ? $productinfo->productInfo->user_engaged : '') }}" type="text">
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Manufacture <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select class="form-control required_field" required="true" name="manufacture[]">
                                            <option value="">--Select--</option>
                                                @foreach($hierarchy as $value)
                                                @forelse($productinfo->productManufacture as $productvalue)     
                                                <option value="{{ $value->hierarchy_id }}" {{$productvalue->hierarchy_id == $value->hierarchy_id?'selected':''}}>{{ $value->hierarchy_name }}</option>
                                                @empty
                                                <option value="{{ $value->hierarchy_id }}">{{ $value->hierarchy_name }}</option>
                                                @endforelse
                                                @endforeach
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Developed By <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select class="form-control required_field" required="true" name="developedby[]">
                                            <option value="">--Select--</option>
                                                @foreach($productowner as $value)
                                                @forelse($productinfo->productDeveloped as $productvalue)     
                                                    <option data-contactemail="{{$value->email}}" value="{{ $value->USER_ID }}" {{$productvalue->user_id == $value->USER_ID?'selected':''}}>{{ $value->USER_NAME }}</option>
                                                @empty
                                                <option data-contactemail="{{$value->email}}" value="{{ $value->USER_ID }}">{{ $value->USER_NAME }}</option>
                                                @endforelse    
                                                @endforeach
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Contact <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <textarea class="form-control required_field" rows="3" name="contact" placeholder="Product contact ...">{{$contacts}}</textarea>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label for="field-1" class="col-lg-2 control-label">Technology <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select name="technology[]" class="form-control required_field">
                                                <option value=""> --Select--</option>
                                                @foreach($ProductTechnologyModel as $value)
                                                @forelse($productinfo->productTechnology as $productvalue)     
                                                <option value="{{$value->technology_id}}" {{$productvalue->technology_id == $value->technology_id?'selected':''}}>{{ $value->name }}</option>    
                                                @empty
                                                <option value="{{$value->technology_id}}">{{ $value->name }}</option>    
                                                @endforelse    
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group required">
                                        <label class="col-lg-2 control-label company-label">Account Usage Details <span class="red">*</span></label>
                                        <div class="col-lg-10">
                                            <select class="form-control required_field" required="true" name="access_usage[]">
                                            <option value="">--Select--</option>
                                                @foreach($hierarchy as $value)
                                                @forelse($productinfo->productAccess as $productvalue)     
                                                <option value="{{$value->hierarchy_id}}" {{$productvalue->hierarchy_id == $value->hierarchy_id?'selected':''}}>{{ $value->hierarchy_name }}</option>    
                                                @empty
                                                <option value="{{$value->hierarchy_id}}">{{ $value->hierarchy_name }}</option>    
                                                @endforelse    
                                                @endforeach
                                             </select>
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Keywords</label>
                                        <div class="col-lg-10">
                                            <textarea class="form-control" rows="3" name="keywords" placeholder="Product Keywords ...">{{$keywords}}</textarea>
                                        </div>
                                    </div>

                                    <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                                    <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                    <input type="hidden" name="product_id" value="{{$productinfo->product_id}}">
                                    @if(count($productinfo->productInfo)>=1)
                                    <input type="hidden" name="products_info_id" value="{{$productinfo->productInfo->products_info_id}}">
                                    @endif
                                    
                                    <div class="form-group row">
                                        <div class="col-lg-2"></div>
                                        <div class="col-lg-2">
                                            <a href="{{url('product/productdetails')}}"><button type="button" class="btn btn-warning pull-left"><i class="fa fa-fw fa-backward"></i> Back</button></a>
                                        </div>
                                        <div class="col-lg-2">
                                            <button type="submit" class="btn btn-primary" id="UpdateSection">  <i class="fa fa-save"> </i> Save Changes</button>
                                        </div>
                                        <div class="col-lg-4"></div>
                                    </div>
                                </div>
                            </div>
                        </section>        
                    </form>
                </div>
            </div>
                    
                    
            </div>
        </div>
    </section>
</div>
        
@endsection

@section('bottomScripts')
<script src="{{ url('assets/bower_components/ckeditor/ckeditor.js')}}"></script>
<script src="{{ url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')}}"></script>
<script>
    $("select[name='developedby[]']").change(function()
    {
        $("textarea[name='contact']").val($(this).find(':selected').attr('data-contactemail'));
    });

    var token           =   {!! "'".csrf_token()."'" !!};
    var app_id          =   {!! "'".$productdata['app_id']."'" !!};
    var app_token       =   {!! "'".$productdata['app_token']."'" !!};

    var imageuploaddata     =   "";
    
    function readURL(input, previewtype) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                if (previewtype == 1)
                    $('#previewuploaduserimage').attr('src', e.target.result);
                else
                    $('#updatepreviewimage').attr('src', e.target.result);
                imageuploaddata     =   e.target.result;
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#uploaduserimage").change(function () {
        readURL(this, 1);
    });

    $("#updateuserimage").change(function () {
        readURL(this, 2);
    });
    
    $(function () {
        CKEDITOR.replace('editor1');
        $('.textarea').wysihtml5();
    });
    
    $( "#UpdateSection" ).click(function(e) {
        e.preventDefault();
        var ContentFromEditor1  =   CKEDITOR.instances.editor1.getData();
        var url         =   $( "#SectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        
        var formData    =   new FormData($( "#SectionForm" )[0]);
        formData.append('description',ContentFromEditor1);
        var url         =   $( "#SectionForm" ).attr('action');    
        
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,                
                async   : false,
                cache   : false,
                contentType: false,
                processData: false,
                success :   function(data) {
                    if(data.Status == 0){
                        
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        $.notify(data.Message,'success');
                    }
                }
           });
        }
    });
</script> 

@stop
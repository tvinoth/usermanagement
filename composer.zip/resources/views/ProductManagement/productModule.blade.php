@extends('layouts.mainapp')
@section('content')
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b>{{$modulename}} - {{$productinfo->product_name}}</b></small></h1>
            <ol class="breadcrumb">
            <li><a href="{{url('home')}}"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="{{url('menu/module')}}"> Menu Module</a></li>
            </ol>
        </section>
        <!--<section class="">
            <div class="col-sm-10"></div>
            <div class="col-sm-2">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-info">
                    <i class="fa fa-user-plus"> </i> ADD USER
                </button>
            </div>
        </section><br><br>-->
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class=""><a href="{{url('product/editproduct/'.$encryptproductID)}}">Product</a></li>
                    <li class="active"><a href="{{url('product/productmodule/'.$encryptproductID)}}">Module</a></li>
                    <li class=""><a href="{{url('product/productrole/'.$encryptproductID)}}">Roles</a></li>
                    <li class=""><a href="{{url('product/productaccess/'.$encryptproductID)}}">User Access</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">
                        <div class="box-body">
                            <form id="SectionForm" accept-charset="UTF-8" class="form-horizontal" role="form" enctype="multipart/form-data">
                                {{ csrf_field() }}
                                

                                <div class="form-group required">
                                    <label class=" col-lg-3 control-label company-label">Name</label>
                                    <div class="col-lg-5">
                                        <input id="fname" class="form-control required_field emptyvalue" maxlength="150" name="module_name" type="text">
                                        <span class="text-danger"></span>
                                    </div>
                                </div>

                                <div class="form-group required">
                                    <label class=" col-lg-3 control-label company-label">Description</label>
                                    <div class="col-lg-5">
                                        <input id="lname" class="form-control required_field emptyvalue" maxlength="150" required="true" name="description" type="text">
                                        <span class="text-danger"></span>
                                    </div>
                                </div>                            
                                
<!--                                <div class="form-group required">
                                    <label class=" col-lg-3 control-label company-label">parent</label>
                                    <div class="col-lg-5">
                                        <input type="checkbox" value="1" name="is_parent">
                                        <span class="text-danger"></span>
                                    </div>
                                </div>-->
                                
                                <div class="form-group required"  id="parent_enable">
                                    <label for="field-1" class="col-sm-3 control-label">Parent Module</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" name="parent_id" id="parent_id">
                                            <option value="">--Select--</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="form-group required disableupdatevalues" style="display:none">
                                    <label for="field-1" class="col-sm-3 control-label">Status</label>
                                    <div class="col-sm-5">
                                        <select name="status_enum" class="form-control">
                                            <option value=""> --Select--</option>
                                            @foreach($statusdetails as $value)
                                                 <option value="{{ $value->status_id }}">{{ $value->status_enum_name }}</option>
                                             @endforeach
                                        </select>
                                    </div>
                                </div>
                                
                                <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                                <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                                <input type="hidden" name="product_id" value="{{$productinfo->product_id}}">
                                <input type="hidden" name="user_id" class="required_field"  value="{{Auth::user()->id}}">
                                <input type="hidden" name="module_id" class="disableupdatevalues" style="display:none">
                                <div class="form-group row">
                                    <div class="col-lg-4"></div>
                                    <div class="col-lg-1">
                                        <button type="button" class="btn btn-warning pull-left disableupdatevalues closeupdate" data-dismiss="modal" style="display:none"><i class="fa fa-close"></i> Close</button>
                                    </div>
                                    <div class="col-lg-1">
                                        <button type="button" class="btn btn-primary disablesubmitbtn" id="AddSection">  <i class="fa fa-fw fa-check"> </i> Create Module</button>
                                        <button type="button" class="btn btn-primary disableupdatevalues updatesubmitbtn" style="display:none">  <i class="fa fa-save"> </i> Update Module</button>
                                    </div>
                                    <div class="col-lg-4"></div>
                                </div>
                            </form>
                        </div>
                        
                        <div class="box-body">
                            <table id="userList" class="table table-bordered table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th>Module Name</th>
                                        <th>Parent Module Name</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>      
                                </tbody>    
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
        
        
        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog ">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header deletemodal">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Delete User</h4>
                    </div>
                    <form class="form-horizontal" action="{{url('api/menu/moduleDelete')}}" method="post" id="DeleteSectionForm">   
                    {{ csrf_field() }}
                    <div class="row">
                      <div class="col-md-12">
                          <div class="form-group required">
                            <input type="hidden" id="module_id" name="module_id">
                            <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                            <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                          </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </form>
                    <div class="modal-body">
                        Are you sure you want to delete a <b><span id='username'></span></b>?

                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                        <button type="button" class="btn btn-danger" id="DeleteSection"><i class="fa fa-user-times"></i> Confirm Delete</button>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        
        <div class="modal fade" id="modal-submodule">
            <div class="modal-dialog" style="width: 75%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Add Module Item - <span id='modulename'></span> </h4>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{url('api/submenu/addModule/new')}}" id="SubSectionForm" accept-charset="UTF-8" role="form" enctype="multipart/form-data">
                            {{ csrf_field() }}
                        <div class="form-group required">
                            <label class=" col-lg-1 control-label company-label">Name</label>
                            <div class="col-lg-3">
                                <input id="fname" class="form-control required_field" maxlength="150" name="module_item_name" type="text">
                                <span class="text-danger"></span>
                            </div>
                        </div>

                        <div class="form-group required">
                            <label class=" col-lg-1 control-label company-label">Description</label>
                            <div class="col-lg-3">
                                <input id="lname" class="form-control required_field" maxlength="150" required="true" name="module_item_description" type="text">
                                <span class="text-danger"></span>
                            </div>
                        </div>
                        
                        <input type="hidden" name="app_id" class="required_field"  value="{{$productdata['app_id']}}">
                        <input type="hidden" name="app_token" class="required_field"  value="{{$productdata['app_token']}}">
                        <input type="hidden" name="module_id" class="required_field"  value="">
                        <input type="hidden" name="user_id" class="required_field"  value="{{Auth::user()->id}}">
                        <div class="form-group required">
                            <button type="submit" class="btn btn-primary" id="SubSection">  <i class="fa fa-fw fa-check"> </i> Create Module Item</button>
                        </div>
                    </form><br>
                    <table class="table table-bordered table-striped" width="100%">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Created Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="sudmoduledata"> 
                        </tbody>    
                    </table>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning pull-right" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                    </div>
                    

                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        
                        
@endsection

@section('bottomScripts')
<script>
    $(document).ready(function()
    {
        $(".disableupdatevalues").css('display','none');
    });
     
    var datatable_url   =   {!! "'".url('api/menu/getMenuList')."'" !!};
    var token           =   {!! "'".csrf_token()."'" !!};
    var app_id          =   {!! "'".$productdata['app_id']."'" !!};
    var app_token       =   {!! "'".$productdata['app_token']."'" !!};
    var product_id      =   {!! "'".$productinfo->product_id."'" !!};
    
    var addmodule_url   =   {!! "'".url('api/menu/addModule/new')."'" !!};
    var updatemodule_url=   {!! "'".url('api/menu/addModule/update')."'" !!};

    $.fn.dataTable.ext.errMode  =   'none';
    var sectionList     =   $('#userList').DataTable({
            "fixedHeader": true,
            "processing": true,
            "serverSide": true,
                ajax: {
                        url: datatable_url,
                        type: 'POST',
                        'data': {
                            _token: token,'app_id':app_id,'product_id':product_id
                        },
                    },
                    "initComplete": function(settings, json) {
//                    console.log(json);
                    },
            "order": [[ 1, "desc" ]],
            fixedHeader: {
                header: true,
                footer: true
            }
        });

    function sectionListReload(){
        sectionList.clear().draw();
    }
    
    function getparentModuleList()
    {
        var datatable_url   =   {!! "'".url('api/menu/getParentModuleList')."'" !!};
        $.ajax({
            type    :   "POST",
            url     :   datatable_url,
            data    :   {_token: token,'app_id':app_id,'app_token':app_token,'product_id':product_id},
            success: function(data) {
                if(data.Status == 1){
                    var errorHtml  =   '';
                    errorHtml   +=   '<option value="">--Select--</option>';
                    if(data.ParentModule.length >=1){
                        $.each(data.ParentModule, function( key, value ) {
                            errorHtml  +=  '<option value="'+value.module_id+'">'+value.module_name+'</option>';
                       });
                    }   
                    $('#parent_id').html(errorHtml);
                }else{
                   $.notify(data.Message,'error');
                }
           }
       });
    }
    getparentModuleList();
    
    
    function clearformdata(){
        $(".disableupdatevalues").css('display','none');
        $(".disablesubmitbtn").css('display','block');
        $("input[name='module_name']").val('');
        $("input[name='description']").val('');
        $("select[name='status_enum']").val('');
        $("select[name='status_enum']").removeClass('required_field');
        $("select[name='parent_id']").removeClass('required_field');
        $("#parent_enable").css('display','block');
        $("select[name='parent_id']").val('');
        $(".disablesubmitbtn").attr('id','AddSection');
        $(".updatesubmitbtn").removeAttr('id');
    }
    
    function viewUserinfo(id,name,desc,isActive,isparent,parentid,thisdata)
    {
        $('.required_field').removeClass('val-error');
        $(".disablesubmitbtn").css('display','none');
        $(".disablesubmitbtn").removeAttr('id');
        $(".updatesubmitbtn").attr('id','AddSection');
        $(".disableupdatevalues").css('display','block');
        if(isparent     ==  1){
            $("#parent_enable").css('display','none');
        }else{
            $("#parent_enable").css('display','block');
            $("select[name='parent_id']").addClass('required_field');
        }
        $("select[name='parent_id']").val(parentid);
        $("input[name='module_name']").val(name);
        $("input[name='description']").val(desc);
        $("select[name='status_enum']").val(isActive);
        $("select[name='status_enum']").addClass('required_field');
        $("input[name='module_id']").val(id);
    }
        
    $(".closeupdate").click(function(){
        $(".emptyvalue").val('');
        $(".disablesubmitbtn").css('display','block');
        $(".disableupdatevalues").css('display','none'); 
        $(".disablesubmitbtn").attr('id','AddSection');
        $("select[name='status_enum']").removeClass('required_field');
        $("select[name='parent_id']").removeClass('required_field');
        $("#parent_enable").css('display','block');
        $("select[name='parent_id']").val('');
        $(".updatesubmitbtn").removeAttr('id');
    });
    
    $( document ).on('click','#AddSection',function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SectionForm" ).serialize();
        var url         =   addmodule_url;               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        
        var isactiveElement =   $("select[name='status_enum']:visible");
        if(isactiveElement.length   !=  0){
            var url         =   updatemodule_url; 
        }
        
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        clearformdata();
                        $.notify(data.Message,'success');
                    }
                    getparentModuleList();
                    sectionListReload();
                }
           });
        }
    });
    
    //sub module creation SubSectionForm
        $( "#SubSection" ).click(function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SubSectionForm" ).serialize();
        var url         =   $( "#SubSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SubSectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        $("input[name='module_item_name']").val('');
                        $("input[name='module_item_description']").val('');
                        if(data.SubModuledata !== 'undefined'){
                            var errorHtml   =   '';
                            var innerstyle  =   '<tr id="deletesectionrow_'+data.SubModuledata.module_item_id+'">';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'">'+data.SubModuledata.module_item_name+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'">'+data.SubModuledata.module_item_description+'</td>';
                            if(data.SubModuledata.is_active == 1){
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                            }else{
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
                            }
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'">'+data.SubModuledata.created_at+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'"><a onClick="editModuleinfo('+data.SubModuledata.module_item_id+','+"'"+data.SubModuledata.module_item_name+"'"+','+"'"+data.SubModuledata.module_item_description+"'"+','+"'"+data.SubModuledata.created_at+"'"+','+data.SubModuledata.is_active+')" id="editSection_'+data.SubModuledata.module_item_id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
                            innerstyle  +=  ' <a onClick=removeModule('+data.SubModuledata.module_item_id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
                            errorHtml   +=  innerstyle+'</tr>';
                            $("#sudmoduledata tr:first").before(errorHtml);
                        }
                        $("#deleteemptyrow").remove();
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
                }
           });
        }
    });
    
    // delete
    $( "div" ).on( "click", ".deleteSection", function() {
        var id          =   this.id;
        var username    =   $(this).data('deleteusername');
        var sectionID   =   id.replace("deleteSection_", "");
        $("#module_id").val(sectionID);
        $("#username").text(username);
    });
    var sectionID   =   "";
    function viewSubmoduleinfo(sectionID,thisdata){
        sectionID   =   sectionID;
        var datatable_url   =   {!! "'".url('api/product/viewsubmodule')."'" !!};
        $("input[name='module_item_name']").val('');
        $("input[name='module_item_description']").val('');
        $('.required_field').removeClass('val-error');
        $("input[name='module_id']").val(sectionID);
        var modulename  =   $(thisdata).attr('data-addmodulename');
        $("#modulename").text(modulename);
        
        $.ajax({
            type    :   "POST",
            url     :   datatable_url,
            data    :   {_token: token,'app_id':app_id,'app_token':app_token,'module_id':sectionID},
            success: function(data) {
                if(data.Status == 1){
                    var errorHtml  =   '';
                    console.log(data.submoduledata);
                    if(data.submoduledata.length >=1){
                        $.each(data.submoduledata, function( key, value ) {
                            var innerstyle  =   '<tr id="deletesectionrow_'+value.module_item_id+'">';
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.module_item_id+'">'+value.module_item_name+'</td>';
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.module_item_id+'">'+value.module_item_description+'</td>';
                            if(value.is_active == 1){
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.module_item_id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                            }else{
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.module_item_id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
                            }
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.module_item_id+'">'+value.created_at+'</td>';
                            innerstyle  +=  '<td  class="hidesectionrow_'+value.module_item_id+'"><a onClick="editModuleinfo('+value.module_item_id+','+"'"+value.module_item_name+"'"+','+"'"+value.module_item_description+"'"+','+"'"+value.created_at+"'"+','+value.is_active+')" id="editSection_'+value.module_item_id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
                            innerstyle  +=  ' <a onClick=removeModule('+value.module_item_id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
                            errorHtml   +=  innerstyle+'</tr>';
                       });
                    }else{
                        errorHtml   +=  '<tr id="deleteemptyrow"><td colspan="5">No Item found !</td></tr>';
                    }   
                    $('#sudmoduledata').html(errorHtml);
                }else{
                   $.notify(data.Message,'error');
                }
           }
       });
       
//           $("tr #deleteemptyrow").remove();
    }
    
    var statusenum      =   {!! $statusdetails !!};
            
    function editModuleinfo(id,module_item_name,module_item_description,created_at,is_active){
        $(".hidesectionrow_"+id).remove();
        var innerstyle  =   '';
        var option      =   '';
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><input class="form-control required_field updatevalidation_'+id+'" type="text" id="module_item_name_'+id+'" value="'+module_item_name+'"></td>'
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><input class="form-control required_field updatevalidation_'+id+'" type="text" id="module_item_description_'+id+'" value="'+module_item_description+'"></td>'
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><select class="form-control required_field updatevalidation_'+id+'" type="text" id="sub_status_'+id+'"><option value="">--Select--</option>';
        $.each(statusenum,function(key,statusval)
        {
            option  +=  '<option value="'+statusval.status_id+'">'+statusval.status_enum_name+'</option>';
        });
        
        innerstyle  +=  option+'</select></td>'    
        innerstyle  +=  '<td class="undosectionrow_'+id+'">'+created_at+'</td>'    
        innerstyle  +=  '<td class="undosectionrow_'+id+'"><button onClick="updatesubmodule('+id+')" type="submit" class="btn btn-primary btn-xs"><i class="fa fa-save"> </i> update</button> <button onClick="undosubmodule('+id+','+"'"+module_item_name+"'"+','+"'"+module_item_description+"'"+','+"'"+created_at+"'"+','+is_active+')" type="submit" class="btn btn-primary btn-xs"><i class="fa fa-fw fa-undo"> </i> undo</button></td>';
        $("#deletesectionrow_"+id).append(innerstyle);
        $("#sub_status_"+id).val(is_active);
    }
    
    
    function undosubmodule(id,module_item_name,module_item_description,created_at,is_active){
        $(".undosectionrow_"+id).remove();
        var innerstyle  =   '';
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'">'+module_item_name+'</td>';
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'">'+module_item_description+'</td>';
        if(is_active == 1){
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
        }else{
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
        }
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'">'+created_at+'</td>';
        innerstyle  +=  '<td  class="hidesectionrow_'+id+'"><a onClick="editModuleinfo('+id+','+"'"+module_item_name+"'"+','+"'"+module_item_description+"'"+','+"'"+created_at+"'"+','+is_active+')" id="editSection_'+id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
        innerstyle  +=  ' <a onClick=removeModule('+id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
        $("#deletesectionrow_"+id).append(innerstyle);
    }
    
    function updatesubmodule(id){
        var url   =   {!! "'".url('api/submenu/addModule/update')."'" !!};
        var module_item_name     =   $("#module_item_name_"+id).val();
        var module_item_description     =   $("#module_item_description_"+id).val();
        var sub_status          =   $("#sub_status_"+id+" :selected").val();
        $('.updatevalidation_'+id).removeClass('val-error');
        var validation  =   true;
        $('.updatevalidation_'+id).each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   {_token: token,'app_id':app_id,'app_token':app_token,'module_id':$("input[name='module_id']").val(),'module_item_id':id,'module_item_name':module_item_name,'module_item_description':module_item_description,'status_enum':sub_status};
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }else{
                        if(data.SubModuledata !== 'undefined'){
                            var innerstyle   =   '';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'">'+data.SubModuledata.module_item_name+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'">'+data.SubModuledata.module_item_description+'</td>';
                            if(data.SubModuledata.is_active == 1){
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'"><span class="label label-success"><i class="fa fa-fw fa-wrench"></i> Active</span></td>';
                            }else{
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'"><span class="label label-danger"><i class="fa fa-fw fa-wrench"></i>In Active</span></td>';    
                            }
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'">'+data.SubModuledata.created_at+'</td>';
                            innerstyle  +=  '<td class="hidesectionrow_'+data.SubModuledata.module_item_id+'"><a onClick="editModuleinfo('+data.SubModuledata.module_item_id+','+"'"+data.SubModuledata.module_item_name+"'"+','+"'"+data.SubModuledata.module_item_description+"'"+','+"'"+data.SubModuledata.created_at+"'"+','+data.SubModuledata.is_active+')" id="editSection_'+data.SubModuledata.module_item_id+'" data-type="update"><i class="fa fa-pencil-square-o btn btn-xs btn-primary"></i></a>';
                            innerstyle  +=  ' <a onClick=removeModule('+data.SubModuledata.module_item_id+')><i class="fa fa-trash-o btn btn-xs btn-danger" title="Delete" data-original-title="Delete"></i></a></td>';
                            $(".undosectionrow_"+id).remove();
                            $("#deletesectionrow_"+id).append(innerstyle);
                        }
                        
                        $.notify(data.Message,'success');
                    }
                }
           });
        }
    }
    
    
    $( "#DeleteSection" ).click(function() {   //Update      
        var formData    =   $( "#DeleteSectionForm" ).serialize();
        var url         =   $( "#DeleteSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#DeleteSectionForm .required_field').each(function(index){
            var value   =   $(this).val();
            value       =   value.trim();
            if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });

        if(validation  ==  true){
           var postdata    =   formData;
           $.ajax({
               type    :   "DELETE",
               url     :   url,
               data    :   postdata,
               success: function(data) {
                   if(data.Status == 1){
                       $.notify(data.Message,'success');
                       sectionListReload(); 
                       $('#modal-delete').trigger('click');
                   }else{
                       $.notify(data.Message,'danger');
                   }
               }
           });
        }
    });
    
    function removeModule(id){
        var confirmdelete     =   confirm("Are you sure you want to delete !");
        if(confirmdelete  ==  true){
            var url     =   {!! "'".url('api/submenu/moduleDelete')."'" !!};
            var postdata    =   {'app_id':app_id,'app_token':app_token,'module_item_id':id};
            $.ajax({
                type    :   "DELETE",
                url     :   url,
                data    :   postdata,
                success: function(data) {
                    if(data.Status == 1){
                        if(data.moduleItemCount !== 'undefined' && data.moduleItemCount == 0){
                            $('#sudmoduledata').html('<tr id="deleteemptyrow"><td colspan="5">No Item found !</td></tr>');
                        }
                        $("#deletesectionrow_"+id).remove();
                        $.notify(data.Message,'success');
                    }else{
                        $.notify(data.Message,'danger');
                    }
                }
            });
        }
    }
    
</script> 
@stop
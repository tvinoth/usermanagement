@extends('layouts.mainapp')
@section('content')
<style>
    .box.box-solid.box-info>.box-header {
    color: #fff;
    background: #dae2e4;
    background-color: #6d8490;
}
.box.box-solid.box-info {
    border: 1px solid #777c7d;
}
    .box-header {
    display: block;
    padding: 1px 10px;
    position: relative;
}
    </style>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b>{{$modulename}} - {{$productinfo->product_name}}</b></small></h1>
            <ol class="breadcrumb">
            <li><a href="{{url('home')}}"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="{{url('rolemanagement')}}"> Role</a></li>
            </ol>
        </section>
            
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class=""><a href="{{url('product/editproduct/'.$encryptproductID)}}">Product</a></li>
                    <li class=""><a href="{{url('product/productmodule/'.$encryptproductID)}}">Module</a></li>
                    <li class="active"><a href="{{url('product/productrole/'.$encryptproductID)}}">Roles</a></li>
                    <li class=""><a href="{{url('product/productaccess/'.$encryptproductID)}}">User Access</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">    
                        <form action="{{url('api/product/addProductRoleModuleMap')}}" id="SectionForm" accept-charset="UTF-8" role="form" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="box-body">    
                                <div class="form-group required">
                                    <label class="col-lg-1 control-label company-label">Role <span class="red">*</span></label>
                                    <div class="col-lg-3">
                                        <select class="form-control required_field rolename" required="true" name="productrole[]">
                                        <option value="">--Select Role--</option>
                                            @forelse($productinfo->product_role as $value)
                                                <option value="{{ $value->role_id }}">{{ $value->name }}</option>
                                                @empty
                                            @endforelse
                                         </select>
                                        <span class="text-danger"></span>
                                    </div>
                                </div>                            

                                <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                                <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                                <input type="hidden" name="product_id" value="{{$productinfo->product_id}}">
                                <input type="hidden" name="role_id" value="">
                                <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                            </div>
                            
                            @if(count($productinfo->product_module) == 0)
                            <div class="box box-danger">
                                <div class="box-header with-border">
                                    <h4>No Module Found !</h4>
                                </div>
                            </div>
                            @elseif(count($productinfo->product_module)>= 1)
                            <div class="box box-default mainmodulecollapse collapsed-box">
                                <div class="box-header with-border">
                                    <div class="checkbox pointer">
                                        <span data-widget="collapse">New</span></h3>
                                    </div>
                                    <div class="box-tools pull-right">
                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                    </div>
                                </div>
                                <div class="box-body">
                                <div class="checkbox">
                                    <label><input type="checkbox" value="" class="allmodule"><h3 class="box-title"><span data-widget="collapse">All</span></h3></label>
                                </div>
                                @forelse($productinfo->product_module as $parentkey=>$parentvalue)
                                <div class="col-md-6">
                                    <div class="box box-primary mainmodulecollapse box-solid collapsed-box">
                                            <div class="box-header with-border">
                                                <div class="checkbox">
                                                    <label><input type="checkbox" name="parent_module[{{$parentvalue->module_id}}]" data-checkitemschecked="{{$parentvalue->module_code}}" value="{{$parentvalue->module_id}}" id="parentID_{{$parentvalue->module_id}}" data-parentmodule="{{$parentvalue->module_id}}" class="allmodulechild parentmodule"><h3 class="box-title"><span data-widget="collapse">{{$parentvalue->module_name}} </span>- <span  class="badge bg-gray">{{$parentvalue->module_code}}</span></h3></label>
                                                </div>
                                                <div class="box-tools pull-right">
                                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                                </div>
                                            </div>
                                            <div class="box-body">
                                                @if(isset($parentvalue->product_module_items) && count($parentvalue->product_module_items)>= 1)
                                                    <div class="box-body">
                                                    @forelse($parentvalue->product_module_items as $parentitem=>$parentitemvalue)
                                                    <div class="col-md-4">
                                                        <div class="checkbox">
                                                            <label><input type="checkbox" data-checkitemschecked="{{$parentitemvalue->module_item_code}}" name="child_item_module[{{$parentvalue->module_id}}][{{$parentitemvalue->module_item_id}}]" class="allmodulechild parent_{{$parentvalue->module_id}}" value="{{$parentitemvalue->module_item_code}}">{{$parentitemvalue->module_item_name}} - <span  class="badge bg-gray">{{$parentitemvalue->module_item_code}}</span></label>
                                                        </div>
                                                    </div>
                                                    @empty
                                                    @endforelse
                                                    </div>
                                                @endif

                                            @if(isset($parentvalue->product_sub_module) && count($parentvalue->product_sub_module)>= 1)
                                            @forelse($parentvalue->product_sub_module as $subkey=>$subvalue)
                                           
                                                <div class="box box-info mainmodulecollapse box-solid collapsed-box">
                                                    <div class="box-header with-border">
                                                         <div class="checkbox">
                                                             <label><input type="checkbox" data-checkitemschecked="{{$subvalue->module_code}}" name="parent_module[{{$subvalue->module_id}}]" value="{{$subvalue->module_id}}" id="childID_{{$subvalue->module_id}}" data-parentwithmodule="{{$parentvalue->module_id}}" data-childmodule="{{$subvalue->module_id}}" class="allmodulechild childmodule parent_{{$parentvalue->module_id}}"><span data-widget="collapse">{{$subvalue->module_name}}</span> - <span  class="badge bg-gray">{{$subvalue->module_code}}</span></label>
                                                        </div>
                                                        <div class="box-tools pull-right">
                                                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                                        </div>
                                                    </div>
                                                    @if(isset($subvalue->product_module_items) && count($subvalue->product_module_items)>= 1)
                                                    <div class="box-body">
                                                    @forelse($subvalue->product_module_items as $subchildkey=>$subchildvalue)
                                                        <div class="col-md-4">
                                                            <div class="checkbox">
                                                                <label><input type="checkbox" data-checkitemschecked="{{$subchildvalue->module_item_code}}" name="child_item_module[{{$subvalue->module_id}}][{{$subchildvalue->module_item_id}}]" class="allmodulechild parent_{{$parentvalue->module_id}} child_{{$subchildvalue->module_id}}" value="{{$subchildvalue->module_item_code}}">{{$subchildvalue->module_item_name}} - <span  class="badge bg-gray">{{$subchildvalue->module_item_code}}</span></label>
                                                            </div>
                                                        </div>
                                                        @empty
                                                    @endforelse
                                                    </div>
                                                    @endif
                                                </div>
                                            
                                            @empty
                                            @endforelse
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                @empty
                                
                                @endforelse
                                <div class="col-md-12">
                                <span class="viewrolemaplist" style="display:none">
                                    <div class="col-md-4 col-md-2"></div>
                                    <div class="col-md-4">
                                        <button type="button" class="btn btn-warning btn-lg closeview">  <i class="fa fa-fw fa-close"> </i> Close</button>
                                    </div> 
                                    <div class="col-md-4">
                                    </div>
                                </span>   
                                    
                                <span class="disableupdatevalues" style="display:none">
                                <div class="col-md-4 col-md-2"></div>
                                <div class="col-md-4">
                                    <button type="button" class="btn btn-warning btn-lg closeupdate">  <i class="fa fa-fw fa-close"> </i> Close</button>
                                </div> 
                                <div class="col-md-4">
                                    <button type="button" class="btn btn-success btn-lg updatesubmitbtn">  <i class="fa fa-fw fa-check"> </i> Update Product Role module Map</button>
                                </div>
                                </span>
                                 
                                <div class="col-md-4 col-md-offset-4 enablesubmitbtn">
                                    <button type="button" class="btn btn-success btn-lg submitbtn" id="AddSection">  <i class="fa fa-fw fa-check"> </i> Submit Product Role module Map</button>
                                </div>
                            </div>
                        
                                </div>
                                
                                
                        </div>
                            </form>
                        @endif
                    </div>
                            
            
                        <div class="box-body">
                            <table id="userList" class="table table-bordered table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>      
                                </tbody>    
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
    </div>
        
        
        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog ">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header deletemodal">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Delete User</h4>
                    </div>
                    <form class="form-horizontal" action="{{url('api/product/productrolemapDelete')}}" method="post" id="DeleteSectionForm">   
                    {{ csrf_field() }}
                    <div class="row">
                      <div class="col-md-12">
                          <div class="form-group required">
                            <input type="hidden" id="role_id" name="role_id">
                            <input type="hidden" name="product_id" value="{{$productinfo->product_id}}">
                            <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                            <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                          </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </form>
                    <div class="modal-body">
                        Are you sure you want to delete a <b><span id='username'></span></b>?

                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                        <button type="button" class="btn btn-danger" id="DeleteSection"><i class="fa fa-user-times"></i> Confirm Delete</button>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
@endsection

@section('bottomScripts')
<script>
var datatable_url   =   {!! "'".url('api/product/ProductRoleModuleMapList')."'" !!};
var updaterole_url  =   {!! "'".url('api/product/updateProductRoleModuleMap')."'" !!};
var token           =   {!! "'".csrf_token()."'" !!};
var app_id          =   {!! "'".$productdata['app_id']."'" !!};
var app_token       =   {!! "'".$productdata['app_token']."'" !!};
var product_id      =   {!! "'".$productinfo->product_id."'" !!};
//$(".box-body:not(:first)").css('display','none');

$.fn.dataTable.ext.errMode  =   'none';
var sectionList     =   $('#userList').DataTable({
            "fixedHeader": true,
            "processing": true,
            "serverSide": true,
                ajax: {
                        url: datatable_url,
                        type: 'POST',
                        'data': {
                            _token: token,'app_id':app_id,'product_id':product_id
                        },
                    },
                    "initComplete": function(settings, json) {
//                    console.log(json);
                    },
            "order": [[ 1, "desc" ]],
            fixedHeader: {
                header: true,
                footer: true
            }
        });



    function sectionListReload(){
        sectionList.clear().draw();
    }
    
    
    $('div').on('click',".closeupdate",function(){
        $("input[type='checkbox']").prop('checked',false);
        $(".mainmodulecollapse").addClass('collapsed-box');
        $(".disableupdatevalues").css('display','none');
        $(".enablesubmitbtn").css('display','block'); 
        $(".updatesubmitbtn").removeAttr('id');
        $(".submitbtn").attr('id','AddSection');
        $(".rolename").removeAttr('disabled');
        $(".rolename").val('');
        $("input[name='role_id']").val('');
    });
    
    $('div').on('click',".closeview",function(){
        $("input[type='checkbox']").prop('checked',false);
        $(".viewrolemaplist").css('display','none');
        $(".enablesubmitbtn").css('display','block'); 
        $(".rolename").removeAttr('disabled');
        $(".mainmodulecollapse").addClass('collapsed-box');
        $(".rolename").val('');
        $("input[name='role_id']").val('');
        $(".submitbtn").attr('id','AddSection');
    });
    
    
    function clearbtns(){
        $(".disableupdatevalues").css('display','block');
        $(".enablesubmitbtn").css('display','none'); 
        $(".updatesubmitbtn").attr('id','AddSection');
        $(".submitbtn").removeAttr('id');
        $(".rolename").attr('disabled','true');
        $("div").removeClass('collapsed-box');
        $(".viewrolemaplist").css('display','none');
    }
    function viewrolemap(){
        $(".viewrolemaplist").css('display','block');
        $(".disableupdatevalues").css('display','none');
        $(".enablesubmitbtn").css('display','none');
        $(".rolename").attr('disabled','true');
        $("div").removeClass('collapsed-box');
        $(".submitbtn").attr('id','AddSection');
    }
    
    function clearupdate(){
        $(".disableupdatevalues").css('display','none');
        $(".enablesubmitbtn").css('display','block'); 
        $(".updatesubmitbtn").removeAttr('id');
        $(".submitbtn").attr('id','AddSection');
        $(".rolename").removeAttr('disabled');
        $(".rolename").val('');
        $("input[name='role_id']").val('');
    }
     
    function viewUserinfo(id,roleid,thisdata)
    {
        var methodtype  =   $(thisdata).attr('data-type');
        var postdata    =   {'app_id':app_id,'app_token':app_token,'role_id':roleid,_token: token,product_id:product_id};
        $.ajax({
            type    :   "POST",
            url     :   '{{url("api/product/viewProductRoleMap")}}',
            dataType:   "json",
            data    :   postdata,
            success: function(data) {
                if(data.Status == 0){
                    if (typeof data.RequiredField !== 'undefined') {
                        $.each(data.RequiredField,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'danger');
                            });
                        });
                    }
                    $.notify(data.Message,'danger');
                }else{
                    
                    $("input[type='checkbox']").prop('checked',false);
                    $(data.productRoleMapDetails).each(function(key,value){
                        $('[data-checkitemschecked="' + value.module_code + '" ]').prop('checked',true);
                        console.log(value.module_code);
                    });

                    var checkitemchecked    =   $("input[type='checkbox']:checked").not('.allmodule').length;
                    var totalitem           =   $("input[type='checkbox']").not('.allmodule').length;
                    if(totalitem    ==  checkitemchecked){
                        $(".allmodule").prop('checked',true);
                    }
                    $("input[name='role_id']").val(roleid);
                    $(".rolename").val(roleid);   
                    if(methodtype   ==  "updaterolemap"){
                        clearbtns();
                    }else{
                        viewrolemap();
                    }
                }
            }
        });
    }
    
    $( 'div' ).on("click","#AddSection",function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SectionForm" ).serialize();
        var url         =   $( "#SectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        
        if($("input[type='checkbox']:checked").length == 0){
            alert("Select any one module");
            return false;
        }
        
        var isactiveElement =   $(".updatesubmitbtn:visible");
        if(isactiveElement.length   !=  0){
            var url         =   updaterole_url; 
        }
        
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        clearupdate();
                        $("input[type='checkbox']").prop('checked',false);
                        $('#SectionForm')[0].reset();
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
                }
           });
        }
        return false;
    });
    
    // delete
    $( "div" ).on( "click", ".deleteSection", function() {
        var id          =   this.id;
        var username    =   $(this).data('deleteusername');
        var sectionID   =   id.replace("deleteSection_", "");
        $("#role_id").val(sectionID);
        $("#username").text(username);
    });
     
    $( "#DeleteSection" ).click(function() {   //Update      
        var formData    =   $( "#DeleteSectionForm" ).serialize();
        var url         =   $( "#DeleteSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#DeleteSectionForm .required_field').each(function(index){
            var value   =   $(this).val();
            value       =   value.trim();
            if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });

        if(validation  ==  true){
           var postdata    =   formData;
           $.ajax({
               type    :   "DELETE",
               url     :   url,
               data    :   postdata,
               success: function(data) {
                   if(data.Status == 1){
                       $.notify(data.Message,{className:'success'});
                       sectionListReload(); 
                       $('#modal-delete').trigger('click');
                   }else{
                       $.notify(data.Message,'danger');
                   }
               }
           });
        }
    });
    
    //add role 
    $(document).on('click',".allmodule",function(){
        var checkedall  =   $(this).is(':checked');
        if(checkedall   ==  true)
            $(".allmodulechild").prop('checked',true);
        else
            $(".allmodulechild").prop('checked',false);
    });
    
    $(document).on('click',".allmodulechild",function(){
        var getparentclasses    =   $(this).attr('class').split(' ');
        
        //parent class
        if(getparentclasses.length  ==  2){
            var getparentid     =   getparentclasses[1].split('_');
            var totalparent     =   $('.'+getparentclasses[1]).length;

            var parentArray     =   [];
            $('.'+getparentclasses[1]).each(function(key){
                if($(this).is(':checked')   ==  true){
                    parentArray.push(key);
                }
            });

            if(totalparent      ==  parentArray.length){
                $("#parentID_"+getparentid[1]).prop('checked',true);
            }
            else{
                $("#parentID_"+getparentid[1]).prop('checked',false);
            }
        }
        
        //child
        if(getparentclasses.length  ==  3){
            var getparentid     =   getparentclasses[2].split('_');
            var totalparent     =   $('.'+getparentclasses[2]).length;

            var parentArray     =   [];
            $('.'+getparentclasses[2]).each(function(key){
                if($(this).is(':checked')   ==  true){
                    parentArray.push(key);
                }
            });
            
            if(totalparent      ==  parentArray.length){
                $("#childID_"+getparentid[1]).prop('checked',true);
            }
            else{
                $("#childID_"+getparentid[1]).prop('checked',false);
            }
            
            //if child id checked parent check set 
            var getparentclassid    =   getparentclasses[1].split('_');
            var parentdataAttr      =   $('.allmodulechild[data-parentwithmodule="' + getparentclassid[1] + '" ]').length;
            var parentArray     =   [];
            $('.allmodulechild[data-parentwithmodule="' + getparentclassid[1] + '" ]').each(function(key){
                if($(this).is(':checked')   ==  true){
                    parentArray.push(key);
                }
            });

            if(parentdataAttr      ==  parentArray.length){
                $("#parentID_"+getparentclassid[1]).prop('checked',true);
            }
            else{
                $("#parentID_"+getparentclassid[1]).prop('checked',false);
            }
        }
        
        
        var checkeditem     =   [];
        var checkedall  =   $(this).is(':checked');
        var totallength =   $(".allmodulechild").length;
        $(".allmodulechild").each(function(key){
            if($(this).is(':checked')   ==  true){
                checkeditem.push(key);
            }
        });
        if(checkeditem.length   ==  totallength){
            $(".allmodule").prop('checked',true);
        }
        else{
            $(".allmodule").prop('checked',false);
        }
        
    });
    
    $(document).on('click',".parentmodule",function(){
        var checkeditem     =   [];
        var getID       =   $(this).data('parentmodule');
        var checkedall  =   $(this).is(':checked');
        if(checkedall   ==  true){
            $(".parent_"+getID).prop('checked',true);
        }
        else{
            $(".parent_"+getID).prop('checked',false);
        }
        
        var totallength =   $(".allmodulechild").length;
        $(".allmodulechild").each(function(key){
            if($(this).is(':checked')   ==  true){
                checkeditem.push(key);
            }
        });
        if(checkeditem.length   ==  totallength){
            $(".allmodule").prop('checked',true);
        }
        else{
            $(".allmodule").prop('checked',false);
        }
        
    });
    
    $(document).on('click',".childmodule",function(){
        
        var getparentclasses    =   $(this).attr('class').split(' ');
        if(getparentclasses.length  ==  3){
            var getparentid     =   getparentclasses[2].split('_');
            var parentdataAttr  =   $('.allmodulechild[data-parentwithmodule="' + getparentid[1] + '" ]').length;
            
            var parentArray     =   [];
            $('.allmodulechild[data-parentwithmodule="' + getparentid[1] + '" ]').each(function(key){
                if($(this).is(':checked')   ==  true){
                    parentArray.push(key);
                }
            });

            if(parentdataAttr      ==  parentArray.length){
                $("#parentID_"+getparentid[1]).prop('checked',true);
            }
            else{
                $("#parentID_"+getparentid[1]).prop('checked',false);
            }
        }
        
        var getID       =   $(this).data('childmodule');
        var checkedall  =   $(this).is(':checked');
        if(checkedall   ==  true){
            $(".child_"+getID).prop('checked',true);
        }
        else{
            $(".child_"+getID).prop('checked',false);
        }
    });
    
    
</script> 

@stop
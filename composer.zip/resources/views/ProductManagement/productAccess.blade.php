@extends('layouts.mainapp')
@section('content')
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b>{{$modulename}} - {{$productinfo->product_name}}</b></small></h1>
            <ol class="breadcrumb">
            <li><a href="{{url('home')}}"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="{{url('rolemanagement')}}"> Role</a></li>
            </ol>
        </section>
            
        <section class="content" id="viewusercontent">
            <div class="nav-tabs-custom ulcontentboxmerge">
                <ul class="nav nav-tabs tabcontentboxmerge" id="usertabmenuactivity">
                    <li class=""><a href="{{url('product/editproduct/'.$encryptproductID)}}">Product</a></li>
                    <li class=""><a href="{{url('product/productmodule/'.$encryptproductID)}}">Module</a></li>
                    <li class=""><a href="{{url('product/productrole/'.$encryptproductID)}}">Roles</a></li>
                    <li class="active"><a href="{{url('product/productaccess/'.$encryptproductID)}}">User Access</a></li>
                </ul>
                <div class="tab-content no-padding">
                    <div class="tab-pane fade in active" id="all_data">   
                        <div class="box-body">
                            <form method="POST" class="form-horizontal" action="{{url('api/product/createUserAccess')}}" id="SectionForm" accept-charset="UTF-8" role="form" enctype="multipart/form-data">
                                {{ csrf_field() }}
                                <div class="form-group required">
                                    <label class="col-sm-3 control-label company-label">User <span class="red">*</span></label>
                                    <div class="col-sm-5">
                                        <select class="form-control required_field userName" required="true" name="userName[]">
                                        <option value="">--Select--</option>
                                            @foreach($productowner as $value)
                                                <option data-contactemail="{{$value->email}}" value="{{ $value->USER_ID }}">{{ $value->USER_NAME }}</option>
                                            @endforeach
                                         </select>
                                        <span class="text-danger"></span>
                                    </div>
                                </div>
                                                                
                                <div class="form-group required">
                                    <label class="col-sm-3 control-label company-label">Role <span class="red">*</span></label>
                                    <div class="col-sm-5">
                                        <select class="form-control required_field" required="true" name="role_id">
                                        <option value="">--Select--</option>
                                            @foreach($productrole as $value)
                                                <option value="{{ $value->role_id }}">{{ $value->name }}</option>
                                             @endforeach
                                         </select>
                                        <span class="text-danger"></span>
                                    </div>
                                </div>                            
                                
                                <div class="form-group required disableupdatevalues" style="display:none">
                                    <label for="field-1" class="col-sm-3 control-label">Status</label>
                                    <div class="col-sm-5">
                                        <select name="status_enum" class="form-control">
                                            <option value=""> --Select--</option>
                                            @foreach($statusdetails as $value)
                                                 <option value="{{ $value->status_id }}">{{ $value->status_enum_name }}</option>
                                             @endforeach
                                        </select>
                                    </div>
                                </div>
                                
                                <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                                <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                                <input type="hidden" name="product_id" value="{{$productinfo->product_id}}">
                                <input type="hidden" name="user_id" class="required_field"  value="{{Auth::user()->id}}">
                                <input type="hidden" name="user_role_id" value="">
                                <input type="hidden" name="role_user_id" value="">
                                <div class="form-group row">
                                    <div class="col-lg-4"></div>
                                    <div class="col-lg-1">
                                        <button type="button" class="btn btn-warning pull-left disableupdatevalues closeupdate" data-dismiss="modal" style="display:none"><i class="fa fa-close"></i> Close</button>
                                    </div>
                                    <div class="col-lg-1">
                                        <button type="submit" class="btn btn-primary disablesubmitbtn" id="AddSection">  <i class="fa fa-fw fa-check"> </i> Assign Role</button>
                                        <button type="button" class="btn btn-primary disableupdatevalues updatesubmitbtn" style="display:none">  <i class="fa fa-save"> </i> Update Assign Role</button>
                                    </div>
                                    <div class="col-lg-4"></div>
                                </div>
                            </form>
                        </div>
                        
                        <div class="box-body">
                            <table id="userList" class="table table-bordered table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th>User Name</th>
                                        <th>Role Name</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>      
                                </tbody>    
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
    </div>
        
        
        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog ">
                <div class="modal-content" style="width:100%">
                    <div class="modal-header deletemodal">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Delete User</h4>
                    </div>
                    <form class="form-horizontal" action="{{url('api/product/deleteUserAccess')}}" method="post" id="DeleteSectionForm">   
                    {{ csrf_field() }}
                    <div class="row">
                      <div class="col-md-12">
                          <div class="form-group required">
                            <input type="hidden" id="user_role_id" name="user_role_id">
                            <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                            <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                            <input type="hidden" name="product_id" value="{{$productinfo->product_id}}">
                            <input type="hidden" name="user_id" class="required_field"  value="{{Auth::user()->id}}">
                          </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </form>
                    <div class="modal-body">
                        Are you sure you want to delete a <b><span id='username'></span></b>?

                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                        <button type="button" class="btn btn-danger" id="DeleteSection"><i class="fa fa-user-times"></i> Confirm Delete</button>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
@endsection

@section('bottomScripts')
<script>
var datatable_url   =   {!! "'".url('api/product/ProductUserAccessList')."'" !!};
var token           =   {!! "'".csrf_token()."'" !!};
var app_id          =   {!! "'".$productdata['app_id']."'" !!};
var app_token       =   {!! "'".$productdata['app_token']."'" !!};
var product_id      =   {!! "'".$productinfo->product_id."'" !!};
var updatemodule_url=   {!! "'".url('api/product/updateUserAccess')."'" !!};

$.fn.dataTable.ext.errMode  =   'none';
var sectionList     =   $('#userList').DataTable({
            "fixedHeader": true,
            "processing": true,
            "serverSide": true,
                ajax: {
                        url: datatable_url,
                        type: 'POST',
                        'data': {
                            _token: token,'app_id':app_id,'product_id':product_id
                        },
                    },
                    "initComplete": function(settings, json) {
//                    console.log(json);
                    },
            "order": [[ 1, "desc" ]],
            fixedHeader: {
                header: true,
                footer: true
            }
        });



    function sectionListReload(){
        sectionList.clear().draw();
    }
    
    function viewUserinfo(id,role,userid,isActive,thisdata)
    {
        var methodtype  =   $(thisdata).attr('data-type');
        if(methodtype   ==  "update"){
            $('.required_field').removeClass('val-error');
            $(".disablesubmitbtn").css('display','none');
            $(".disablesubmitbtn").removeAttr('id');
            $(".updatesubmitbtn").attr('id','AddSection');
            $(".disableupdatevalues").css('display','block');
            $(".userName").attr('disabled',true);
            $(".userName").val(userid);
            $("select[name='role_id']").val(role);
            $("select[name='status_enum']").val(isActive);
            $("select[name='status_enum']").addClass('required_field');
            $("input[name='user_role_id']").val(id);
            $("input[name='role_user_id']").val(userid);
            $("select[name='role_id']").removeAttr('disabled');
            $("select[name='status_enum']").removeAttr('disabled');
        }else{
            $(".userName").attr('disabled',true);
            $(".userName").val(userid);
            $("select[name='role_id']").attr('disabled',true);
            $("select[name='status_enum']").attr('disabled',true);
            $("select[name='role_id']").val(role);
            $("select[name='status_enum']").val(isActive);
            $(".disablesubmitbtn").css('display','none');
            $(".disableupdatevalues").css('display','block');
            $(".updatesubmitbtn").css('display','none');
        }
    }
    
    $(".closeupdate").click(function(){
        $(".userName").removeAttr('disabled');
        $("select[name='role_id']").removeAttr('disabled');
        $("select[name='status_enum']").removeAttr('disabled');
        $(".userName").val('');
        $("select[name='role_id']").val('');
        $("input[name='role_user_id']").val('');
        $(".disablesubmitbtn").css('display','block');
        $(".disableupdatevalues").css('display','none'); 
        $(".disablesubmitbtn").attr('id','AddSection');
        $("select[name='status_enum']").removeClass('required_field');
        $(".updatesubmitbtn").removeAttr('id');
        $(".disablesubmitbtn").css('display','block');
    });
    
    function clearformdata(){
        $(".disableupdatevalues").css('display','none');
        $(".disablesubmitbtn").css('display','block');
        $("select[name='role_id']").val('');
        $(".userName").removeAttr('disabled');
        $(".userName").val('');
        $(".disablesubmitbtn").attr('id','AddSection');
        $(".updatesubmitbtn").removeAttr('id');
    }
    
    $( document ).on('click','#AddSection',function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#SectionForm" ).serialize();
        var url         =   $( "#SectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#SectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        
        var isactiveElement =   $("select[name='status_enum']:visible");
        if(isactiveElement.length   !=  0){
            var url         =   updatemodule_url; 
        }
        
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        clearformdata();
                        $("#SectionForm")[0].reset();
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
                }
           });
        }
    });
    
    // delete
    $( "div" ).on( "click", ".deleteSection", function() {
        var id          =   this.id;
        var username    =   $(this).data('deleteusername');
        var sectionID   =   id.replace("deleteSection_", "");
        $("#user_role_id").val(sectionID);
        $("#username").text(username);
    });
     
    $( "#DeleteSection" ).click(function() {   //Update      
        var formData    =   $( "#DeleteSectionForm" ).serialize();
        var url         =   $( "#DeleteSectionForm" ).attr('action');               
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#DeleteSectionForm .required_field').each(function(index){
            var value   =   $(this).val();
            value       =   value.trim();
            if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });

        if(validation  ==  true){
           var postdata    =   formData;
           $.ajax({
               type    :   "DELETE",
               url     :   url,
               data    :   postdata,
               success: function(data) {
                   if(data.Status == 0){
                        if (typeof data.RequiredField !== 'undefined') {
                            $.each(data.RequiredField,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'danger');
                                });
                            });
                        }
                        $.notify(data.Message,'danger');
                    }else{
                        $('#modal-delete').trigger('click');
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
               }
           });
        }
    });
</script> 

@stop
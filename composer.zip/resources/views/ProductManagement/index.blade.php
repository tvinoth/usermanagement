@extends('layouts.mainapp')
@section('content')
        <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <section class="content-header">
            <h1><small><b>{{$modulename}}</b></small></h1>
            <ol class="breadcrumb">
            <li><a href="{{url('home')}}"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="{{url('product/productdetails')}}"> Product</a></li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <div class="box box-default">
                    <div class="box-header">
                        <div class="col-sm-7"></div>
                        <div class="col-sm-1">
                            <a href="{{url('product/addproduct')}}"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-info">
                                <i class="fa fa-user-plus"> </i> Add Product
                            </button></a>
                        </div>
                        <div class="col-sm-2">
                            <div class="input-group">
                                <input type="text" name="product_name" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                    <button type="submit" name="searchproduct" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        <div class="col-sm-2"></div>
                    </div>
                </div>
                </div>
                </div>
                <div class="row">
                    <div id="productviewdata">
                    
                    </div>
                </div>
        </section>
    </div>
@endsection

@section('bottomScripts')
<script>
    window.onload   =   function() {
        productlist('');
    };
           
    //     getProductList
    var datatable_url   =   {!! "'".url('api/product/getProductList')."'" !!};
    var token           =   {!! "'".csrf_token()."'" !!};
    var app_id          =   {!! "'".$productdata['app_id']."'" !!};
    var app_token       =   {!! "'".$productdata['app_token']."'" !!};
    
    function productlist(searchproduct){
        $.ajax({
            type    :   "POST",
            url     :   datatable_url,
            data    :   {_token: token,'app_id':app_id,'app_token':app_token,'searchproduct':searchproduct},
           success: function(data) {
                if(data.Status == 1){
                    var errorHtml  =   '';
                    if(data.ProductDetails.length >=1){
                        $.each(data.ProductDetails, function( key, value ) {
                            var innerstyle  =   "";
                            var encrypt     =   value.editurl;
                            var editProductId   =   '{!! url("product/editproduct/'+encrypt+'") !!}';
                            innerstyle  +=  '<div class="col-md-4" style="min-height: 250px"><div class="col-md-12 grid-box"><div class="col-md-12">';
                            innerstyle  +=  '<img src="'+value.product_logo+'" class="image" style="max-height: 150px"></div>';
                            innerstyle  +=  '<div class="col-md-12"><br><div class="col-md-9"><p class="text-muted">Product Name : '+value.product_name+'</p>';
                            innerstyle  +=  '<p class="text-muted">Contact Name : '+value.product_owner+'</p>';
                            innerstyle  +=  '<p class="text-muted">Product Type : '+value.PRODUCT_TYPE_NAME+'</p></div><div class="col-md-3">';
                            innerstyle  +=  '<a href="'+editProductId+'"><i class="fa fa-pencil-square-o fa-1x btn-lg btn-primary" title="Edit" data-placement="top" data-original-title="Edit"></i></a>';
                            innerstyle  +=  '<a href="'+value.product_live_url+'"  target="_blank">UAT<i class="fa fa-fw fa-link fa-1x" title="Uat Link" data-placement="top" data-original-title="Uat Link"></i></a>';
                            innerstyle  +=  '<a href="'+value.product_uat_url+'"  target="_blank">LIVE<i class="fa fa-fw fa-link fa-1x" title="Live Link" data-placement="top" data-original-title="Live Link"></i></a></div></div></div></div>';
                            errorHtml   +=  innerstyle;
                       });
                    }else{
                        errorHtml   +=  "<h3><center>No Products</center></h3>";
                    }   
                    $('#productviewdata').html(errorHtml);
                }else{
                   $.notify(data.Message,'error');
                }
           }
       });
    }
    
    $("input[name='product_name']").keyup(function(){
        var searchproduct   =   $(this).val();
        productlist(searchproduct);
    });
    
</script> 

@stop
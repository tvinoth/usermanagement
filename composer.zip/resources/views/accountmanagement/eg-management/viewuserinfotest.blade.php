    @if(count($userdetails)>=1)
    <section class="content">
        <div class="box-default" data-collapsed="0">
            <div class="box-header with-border">
                <div class="box-title">
                <strong>Admin</strong>
                </div>
            </div>
        
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6"><p class="pull-left test"><img src="{{url('assets/dist/img/avatar5.png')}}"  class="img-circle" alt="User Image" style="width:20%;height:20%"></p></div><div class="col-sm-6"></div>
            </div>
            <div class="row">
                <div class="col-sm-6 form-horizontal">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        User Details
                        </a>
                    </div>
                    
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">First Name</label>
                        <div class="col-sm-8">
                            <span class="form-control">{{$userdetails->first_name}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Last Name</label>
                        <div class="col-sm-8">
                            <span class="form-control">A</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Emp ID</label>
                        <div class="col-sm-8">
                            <span class="form-control">312015</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-8">
                            <span class="form-control">admin@spi-global.com</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Date of Birth</label>
                        <div class="col-sm-8">
                            <span class="form-control">0000-00-00 00:00:00</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Phone</label>
                        <div class="col-sm-8">
                            <span class="form-control">9790037458</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Team</label>
                        <div class="col-sm-8">
                            <span class="form-control">FMS</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Type</label>
                        <div class="col-sm-8">
                            <span class="form-control">Others</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Employee Role</label>
                        <div class="col-sm-8">
                            <span class="form-control">AM</span>
                        </div>
                    </div>
                </div>
                
                
                <div class="col-sm-6">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        Product Access Details
                        </a>
                        <ul class="nav nav-pills nav-stacked">
                            <li><a href="#"><img src="{{url('assets/dist/img/empty-user.jpg')}}"  class="img-circle" alt="User Image" style="width:5%;height:5%"> &nbsp;&nbsp; FMS</a></li>
                            <li><a href="#"><img src="{{url('assets/dist/img/mag_logo.png')}}"  class="img-circle" alt="User Image" style="width:5%;height:5%"> &nbsp;&nbsp; Magnus</a></li>
                            <li><a href="#"><img src="{{url('assets/dist/img/scp.gif')}}"  class="img-circle" alt="User Image" style="width:5%;height:5%"> &nbsp;&nbsp; Scriptorium</a></li>
                            <li><a href="#"><img src="{{url('assets/dist/img/empty-user.jpg')}}"  class="img-circle" alt="User Image" style="width:5%;height:5%"> &nbsp;&nbsp; OUP</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
@else
<h1>No Data found</h1>
@endif
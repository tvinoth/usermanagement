
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            @guest
            <div class="pull-left image">
                <img src="{{url('assets/dist/img/avatar5.png')}}" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p>Guest</p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
            @endguest
            @Auth
            <div class="pull-left image">
                <img src="{{url('assets/dist/img/avatar5.png')}}" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p>{{Auth::user()->first_name}} {{Auth::user()->last_name}}</p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
            @endAuth
        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
<!--            <li class="treeview">
                <a href="#">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li><a href="{{url('admindashboard')}}"><i class="fa fa-fw fa-user-secret"></i> Admin Dashboard</a></li>
                    <li class=""><a href="{{url('userdashboard')}}"><i class="fa fa-fw fa-dashcube"></i> User Dashboard</a></li>
                    
                </ul>
            </li>-->
            @forelse($menu as $key=>$menuvalue)
                @if(isset($menuvalue->child) && count($menuvalue->child) >= 1)
                    <li class="treeview {{$menuvalue->parent->parent_page_active == $parentname?'active menu-open':''}}">
                        <a href="#">
                            <i class="{{$menuvalue->parent->menu_icon}}"></i> <span>{{$menuvalue->parent->page_name}}</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu" style="">
                            @foreach($menuvalue->child as $subkey=>$submenuvalue)
                                <li class="{{$submenuvalue->child_page_active == $childname?'active':''}}"><a href="{{url($submenuvalue->menu_url)}}"><i class="{{$submenuvalue->menu_icon}}"></i>{{$submenuvalue->page_name}}</a></li>
                            @endforeach
                        </ul>
                    </li>
                @else
                    <li class="{{$menuvalue->parent->parent_page_active == $parentname?'active':''}}">
                        <a href="{{url($menuvalue->parent->menu_url)}}">
                            <i class="{{$menuvalue->parent->menu_icon}}"></i> <span>{{$menuvalue->parent->page_name}}</span>
                        </a>
                    </li>
                @endif
            @empty
             <li class="">
                <a href="#">
                    No Module is found!
                </a>
            </li>
            @endforelse
            
<!--            <li class="">
                <a href="{{url('usermanagement')}}">
                    <i class="fa fa-user"></i> <span>User Management</span>
                </a>
            </li>
            <li class="">
                <a href="{{url('hierarchymanagement')}}">
                    <i class="fa fa-fw fa-hand-lizard-o"></i> <span>Hierarchy Management</span>
                </a>
            </li>-->
            <!--<li class="treeview">
                <a href="#">
                    <i class="fa fa-fw fa-wrench"></i> <span>Account Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li><a href="{{url('usermanagement')}}"><i class="fa fa-fw fa-group"></i> EG Management</a></li>
                    <li class="active"><a href="{{url('userdashboard')}}"><i class="fa fa-fw fa-cloud"></i> Cluster Management</a></li>
                    <li class="active"><a href="{{url('userdashboard')}}"><i class="fa fa-fw fa-steam"></i> Team Management</a></li>
                </ul>
            </li>-->
<!--            <li class="treeview active menu-open">
                <a href="#">
                    <i class="fa fa-cogs"></i> <span>App Setting's</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="{{url('emptypemanagement')}}"><i class="fa fa-fw fa-users"></i> Employee Type Management</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-cogs"></i> <span>Product Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="{{url('product/productdetails')}}"><i class="fa fa-cogs"></i> Product Details</a></li>
                    <li><a href="{{url('menu/module')}}"><i class="fa fa-cogs"></i> Module</a></li>
                    <li><a href="{{url('menu/submodule')}}"><i class="fa fa-cogs"></i> Sub Module</a></li>
                </ul>
            </li>-->
<!--            <li class="">
                <a href="{{url('rolemanagement')}}">
                    <i class="fa fa-fw fa-child"></i> <span>Roles Management</span>
                </a>
            </li>-->
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>

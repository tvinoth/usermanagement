    
    @if($data != null && $methodtype   ==  "view")    
    <section class="content">
        <div class="box-default" data-collapsed="0">
            <div class="box-header with-border">
                <div class="box-title">
                <strong>{{$data->type_name}}</strong>
                </div>
            </div>
        
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6 form-horizontal">
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Name</label>
                        <div class="col-sm-8">
                            <span class="form-control">{{$data->type_name}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-8">
                            <span class="form-control">{{$data->description}}</span>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        </div>
    </section>
    
    @elseif($data != null && $methodtype   ==  "update")    
    <section class="content">
        <div class="box-default" data-collapsed="0">        
        <div class="box-body">
        <form method="POST" action="{{url('api/doUpdateEmptype')}}" id="UpdateSectionForm" accept-charset="UTF-8" class="form-horizontal">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-sm-6 form-horizontal">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        Employee Type Details
                        </a>
                    </div>
                    <input type="hidden" name="emptype_id" value="{{$data->emplyoee_type_id}}">
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="type_name" value="{{$data->type_name}}" placeholder="Name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="description" value="{{$data->description}}" placeholder="description Name">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <button type="button" class="btn btn-primary" id="UpdateSection"> <i class="fa fa-save"> </i> Save Changes</button>
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                </div>
                
                
                <div class="col-sm-6">
                    
                </div>
            </div>
        </form>
        </div>
        </div>
    </section>
    @else
    <h1>No Data found</h1>
    @endif
    
    <script>
        $( "#UpdateSection" ).click(function(e) {    // Add     
        e.preventDefault();
        var formData    =   $( "#UpdateSectionForm" ).serialize();
        var url         =   $( "#UpdateSectionForm" ).attr('action');   
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#UpdateSectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }
                    $.notify(data.Message,'success');
                    sectionListReload();
                }
           });
        }
    });
    </script>
    
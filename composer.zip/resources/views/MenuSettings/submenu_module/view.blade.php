    
    @if($moduleinfo != null && $methodtype   ==  "view")    
    <section class="content">
        <div class="box-default" data-collapsed="0">        
        <div class="box-body">
            <div class="row" id="viewFrm">
                <div class="form-horizontal">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        Module Details
                        </a>
                    </div>
                    <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                    <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                    <input type="hidden" name="sub_module_id" value="{{$moduleinfo->sub_module_id}}">
                    <div class="form-group required">
                        <label for="field-1" class="col-sm-3 control-label">Main Module</label>
                        <div class="col-sm-5">
                            <select name="module_id" class="form-control required_field">
                                <option value=""> --Select--</option>
                                @foreach($menumoduledetails as $value)
                                     <option value="{{ $value->module_id }}" {{ $value->module_id == $moduleinfo->module_id?'selected':''}}>{{ $value->module_name }}</option>
                                 @endforeach
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Name</label>
                        <div class="col-lg-5">
                            <input id="fname" class="form-control required_field" maxlength="150" name="sub_module_name" value="{{$moduleinfo->sub_module_name}}" type="text" placeholder="Module Name">
                            <span class="text-danger"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control required_field" name="sub_description" value="{{$moduleinfo->sub_description}}" placeholder="description Name">
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label for="field-1" class="col-sm-3 control-label">Status</label>
                        <div class="col-sm-5">
                            <select name="status_enum" class="form-control required_field">
                                <option value=""> --Select--</option>
                                @foreach($statusdetails as $value)
                                     <option value="{{ $value->status_id }}" {{ $value->status_id == $moduleinfo->is_active?'selected':''}}>{{ $value->status_enum_name }}</option>
                                 @endforeach
                            </select>
                        </div>
                    </div>
                    
                </div>
                
                
                <div class="col-sm-6">
                    
                </div>
            </div>
        </div>
        </div>
    </section>
    @elseif($moduleinfo != null && $methodtype   ==  "update")    
    <section class="content">
        <div class="box-default" data-collapsed="0">        
        <div class="box-body">
        <form method="POST" action="{{url('api/submenu/addModule/update')}}" id="UpdateSectionForm" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="row">
                <div class="form-horizontal">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        Module Details
                        </a>
                    </div>
                    <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                    <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                    <input type="hidden" name="sub_module_id" value="{{$moduleinfo->sub_module_id}}">
                    <div class="form-group required">
                        <label for="field-1" class="col-sm-3 control-label">Product</label>
                        <div class="col-sm-5">
                            <select name="module_id" class="form-control required_field">
                                <option value=""> --Select--</option>
                                @foreach($menumoduledetails as $value)
                                     <option value="{{ $value->module_id }}" {{ $value->module_id == $moduleinfo->sub_module_id?'selected':''}}>{{ $value->module_name }}</option>
                                 @endforeach
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group required">
                        <label class=" col-lg-3 control-label company-label">Name</label>
                        <div class="col-lg-5">
                            <input id="fname" class="form-control required_field" maxlength="150" name="sub_module_name" value="{{$moduleinfo->sub_module_name}}" type="text" placeholder="Module Name">
                            <span class="text-danger"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" name="sub_description" value="{{$moduleinfo->sub_description}}" placeholder="description Name">
                        </div>
                    </div>
                    <div class="form-group required">
                        <label for="field-1" class="col-sm-3 control-label">Status</label>
                        <div class="col-sm-5">
                            <select name="status_enum" class="form-control required_field">
                                <option value=""> --Select--</option>
                                @foreach($statusdetails as $value)
                                     <option value="{{ $value->status_id }}" {{ $value->status_id == $moduleinfo->is_active?'selected':''}}>{{ $value->status_enum_name }}</option>
                                 @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <button type="button" class="btn btn-primary" id="UpdateSection"> <i class="fa fa-save"> </i> Save Changes</button>
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                </div>
                
                
                <div class="col-sm-6">
                    
                </div>
            </div>
        </form>
        </div>
        </div>
    </section>
    @else
    <h1>No Data found</h1>
    @endif
    
    <script>
        $(document).ready(function(){
           var methoddata  =   "<?php echo $methodtype; ?>";
            if(methoddata   ==  "view"){
                $("#viewFrm").find(':input').prop("disabled", true);
            }   
        });
        $( "#UpdateSection" ).click(function(e) {    // Add     
        e.preventDefault();
//        var formData    =   $( "#UpdateSectionForm" ).serialize();
        var url         =   $( "#UpdateSectionForm" ).attr('action');   
        var formData    =   new FormData($( "#UpdateSectionForm" )[0]);
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#UpdateSectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                success :   function(data) {
                    if(data.Status == 0){
                        $.notify(data.Message,'danger');
                    }else{
                        $.notify(data.Message,'success');
                    }
                    sectionListReload();
                }
           });
        }
    });
    </script>
    
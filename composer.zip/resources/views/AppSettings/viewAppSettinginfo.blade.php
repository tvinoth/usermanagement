    
    
    @if($moduleinfo != null && $methodtype   ==  "update")    
    <section class="content">
        <div class="box-default" data-collapsed="0">        
        <div class="box-body">
        <form method="POST" action="{{url('doUpdateModuleInfo')}}" id="UpdateSectionForm" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-sm-6 form-horizontal">
                    <div id="roll" class="list-group">
                        <a href="#" class="list-group-item disabled">
                        Module Details
                        </a>
                    </div>
                    <input type="hidden" name="app_id" value="{{$productdata['app_id']}}">
                    <input type="hidden" name="app_token" value="{{$productdata['app_token']}}">
                    <input type="hidden" name="module_id" value="{{$moduleinfo->module_id}}">
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Module Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="module_name" value="{{$moduleinfo->module_name}}" placeholder="Module Name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Module Description</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="description" value="{{$moduleinfo->description}}" placeholder="description Name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label">Module Type</label>
                        <div class="col-sm-8">
                            <select name="module_type" class="form-control">
                                <option value=""> --Select--</option>
                                @foreach($moduleenum as $value)
                                     <option value="{{ $value->module_type_enum_id }}" {{ $value->module_type_enum_id   ==  $moduleinfo->module_type?'selected':''}}>
                                         {{ $value->module_type_name }}
                                     </option>
                                 @endforeach
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <button type="button" class="btn btn-primary" id="UpdateSection"> <i class="fa fa-save"> </i> Save Changes</button>
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                </div>
                
                
                <div class="col-sm-6">
                    
                </div>
            </div>
        </form>
        </div>
        </div>
    </section>
    @else
    <h1>No Data found</h1>
    @endif
    
    <script>
        $( "#UpdateSection" ).click(function(e) {    // Add     
        e.preventDefault();
//        var formData    =   $( "#UpdateSectionForm" ).serialize();
        var url         =   $( "#UpdateSectionForm" ).attr('action');   
        var formData    =   new FormData($( "#UpdateSectionForm" )[0]);
        $('.required_field').removeClass('val-error');
        var validation  =   true;
        $('#UpdateSectionForm .required_field').each(function(index){
                var value   =   $(this).val();
                value       =   value.trim();
                if(value    ==  '' || value ==  ' ' || value.length ==  0){
                validation  =   false;
                $(this).addClass('val-error');
            }
        });
        if(validation  ==  true){
            var postdata    =   formData;
            $.ajax({
                type    :   "POST",
                url     :   url,
                data    :   postdata,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                success :   function(data) {
                    if(data.status == 0){

                    }
//                    $("#showupdate_users").css('display','none');
                    sectionListReload();
                }
           });
        }
    });
    </script>
    
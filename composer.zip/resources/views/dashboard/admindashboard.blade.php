@extends('layouts.mainapp')
@section('content')
<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>{{$modulename}}</h1>
        </section>
        <!-- Main content -->
        <section class="content">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <div class="info-box-content">
                            <span class="info-box-number">4,000</span>
                            <span class="info-box-text">Users</span>
                        </div>
                        <span class="info-box-icon info-box-icon-blue"><i class="fa fa-user"></i></span>
                    </div>
                </div>

                <!-- fix for small devices only -->
                <div class="clearfix visible-sm-block"></div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon info-box-icon-orange"><i class="fa fa-user"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-number">1,700</span>
                            <span class="info-box-text">Online Users</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon info-box-icon-green"><i class="fa fa-cubes"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-number">25</span>
                            <span class="info-box-text">Accounts</span>
                        </div>
                    </div>
                </div>

                <!-- /.col -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon info-box-icon-pink"><i class="fa fa-list-ul"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-number">55</span>
                            <span class="info-box-text">Products</span>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
            
            <!-- Main row -->
            <div class="row">
                <!-- Left col -->
                <section class="col-lg-6 connectedSortable">
                    <!-- PRODUCT LIST -->
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">Recently Added Products</h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <ul class="products-list product-list-in-box">
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/default-50x50.gif')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">FMS
                                            <span class="label label-default pull-right">$1800</span></a>
                                        <span class="product-description">
                                            Freelance Management System.
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/magnus.png')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">MAGNUS
                                            <span class="label label-default pull-right">$700</span></a>
                                        <span class="product-description">
                                            Workflow Management System.
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/scp.gif')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">SCRIPTORIUM <span
                                                class="label label-default pull-right">$350</span></a>
                                        <span class="product-description">
                                            HR Management System.
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/default-50x50.gif')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">REPORTING SYSTEM
                                            <span class="label label-default pull-right">$399</span></a>
                                        <span class="product-description">
                                            SPI Reporting Management System.
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                            </ul>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer text-center">
                            <a href="javascript:void(0)" class="uppercase">View All Products</a>
                        </div>
                        <!-- /.box-footer -->
                    </div>
                </section>
                <!-- /.Left col -->
                <!-- right col (We are only adding the ID to make the widgets sortable)-->
                <section class="col-lg-6 connectedSortable">
                    <!-- PRODUCT LIST -->
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">Recently Users Activities</h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <ul class="products-list product-list-in-box">
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/avatar5.png')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">Arun
                                            <span class="label label-default pull-right">3 hours ago</span></a>
                                        <span class="product-description">
                                            Spice Completed
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/empty-user.jpg')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">Madhan
                                            <span class="label label-default pull-right">2 hours ago</span></a>
                                        <span class="product-description">
                                            Proofing Completed
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/avatar5.png')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">Vinoth<span
                                                class="label label-default pull-right">1 hour ago</span></a>
                                        <span class="product-description">
                                            Password Changed
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                                <li class="item">
                                    <div class="product-img">
                                        <img src="{{url('assets/dist/img/empty-user.jpg')}}" alt="Product Image">
                                    </div>
                                    <div class="product-info">
                                        <a href="javascript:void(0)" class="product-title">Tamil
                                            <span class="label label-default pull-right">one minutes ago</span></a>
                                        <span class="product-description">
                                            Split Completed
                                        </span>
                                    </div>
                                </li>
                                <!-- /.item -->
                            </ul>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer text-center">
                            <a href="javascript:void(0)" class="uppercase">View All Activities</a>
                        </div>
                        <!-- /.box-footer -->
                    </div>
                </section>
                <!-- right col -->
            </div>
            <!-- /.row (main row) -->
        </section>
        <!-- /.content -->
    </div>
@endsection
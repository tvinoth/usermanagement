@extends('layouts.mainapp')
@section('content')
<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                {{$modulename}}
                <small style="float: right">Last Login: 28 Oct 2018 11:04:88</small>
            </h1>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="col-md-3 project-list">
                <div class="col-md-12">
                    <img src="{{url('assets/dist/img/Magnus_logo_new.PNG')}}">
                </div>
                <div class="col-md-12"><br>
                    <p class="text-muted">Role : Project Manager</p>
                </div>
            </div>
            <div class="col-md-3 project-list">
                <div class="col-md-12">
                    <img src="{{url('assets/dist/img/fms-logo.png')}}">
                </div>
                <div class="col-md-12"><br>
                    <p class="text-muted">Role : Project Manager</p>
                </div>
            </div>
            <div class="col-md-3 project-list">
                <div class="col-md-12">
                    <img src="{{url('assets/dist/img/Magnus_logo_new.PNG')}}">
                </div>
                <div class="col-md-12"><br>
                    <p class="text-muted">Role : Project Manager</p>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
@endsection
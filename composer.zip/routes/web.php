<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::group(['middleware' => 'auth'], function() {
    Route::get('/home', 'HomeController@index');
    Route::get('/admindashboard', 'dashboard\DashboardController@adminindex');
    Route::get('/userdashboard', 'dashboard\DashboardController@userindex');
    Route::get('/usermanagement', 'usermanagement\UserManagementController@index');
    Route::get('/hierarchymanagement', 'HierarchyManagement\HierarchyManagementController@index');
    Route::get('/appmanagement', 'AppSettings\AppSettingsController@index');
    Route::post('/doGetAppsettingList', 'AppSettings\AppSettingsController@doGetAppsettingList');
    Route::post('/doUpdateModuleInfo', 'AppSettings\AppSettingsController@doUpdateModuleInfo');
    Route::post('/doViewModuleInfo', 'AppSettings\AppSettingsController@doViewModuleInfo');
    Route::get('/emptypemanagement', 'EmployeeTypeManagement\EmployeeTypeManagementController@index');

    // menu routing
    Route::prefix('menu')->group(function () {
        Route::any('module', 'MenuSettings\ModuleController@index');
        Route::any('submodule', 'MenuSettings\SubModuleController@index');
    });

    Route::get('/rolemanagement', 'RoleManagementController@index');
    // product routing
    Route::prefix('product')->group(function () {
        Route::any('productdetails', 'ProductManagement\ProductController@index');
        Route::any('addproduct', 'ProductManagement\ProductController@addproduct');
        Route::any('editproduct/{PID}', 'ProductManagement\ProductController@editproduct');
        Route::any('productmodule/{PID}', 'ProductManagement\ProductController@productmodule');
        Route::any('productrole/{PID}', 'ProductManagement\ProductController@productrole');
        Route::any('productaccess/{PID}', 'ProductManagement\ProductController@productaccess');
    });
});



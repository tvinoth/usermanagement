<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
// user api
Route::any('/doCreateUser', 'Api\usermanagement\UserManagementController@doCreateUser');
Route::any('/doUserLogin', 'Api\usermanagement\UserManagementController@doUserLogin');
Route::any('/doGetUserList', 'Api\usermanagement\UserManagementController@doGetUserList');
Route::post('/doViewUserInfo', 'Api\usermanagement\UserManagementController@doViewUserInfo');
Route::post('/doUpdateUserInfo', 'Api\usermanagement\UserManagementController@doUpdateUserInfo');
Route::delete('/doUserDelete', 'Api\usermanagement\UserManagementController@doUserDelete');

// hierarchy api
Route::any('/doGetHierarchyList', 'Api\HierarchyManagement\HierarchyManagementController@doGetHierarchyList');
Route::any('/doAddHierarchy', 'Api\HierarchyManagement\HierarchyManagementController@doAddHierarchy');
Route::delete('/doHierarchyDelete', 'Api\HierarchyManagement\HierarchyManagementController@doHierarchyDelete');
Route::post('/doViewHierarchyInfo', 'Api\HierarchyManagement\HierarchyManagementController@doViewHierarchyInfo');
Route::post('/doUpdateHierarchyInfo', 'Api\HierarchyManagement\HierarchyManagementController@doUpdateHierarchyInfo');

// employee type api
Route::any('/doGetEmpTypeList', 'Api\EmployeeTypeManagement\EmployeeTypeManagementController@doGetEmpTypeList');
Route::delete('/doEmpTypeDelete', 'Api\EmployeeTypeManagement\EmployeeTypeManagementController@doEmpTypeDelete');
Route::post('/doViewEmpTypeInfo', 'Api\EmployeeTypeManagement\EmployeeTypeManagementController@doViewEmpTypeInfo');
Route::post('/doAddEmployeeType', 'Api\EmployeeTypeManagement\EmployeeTypeManagementController@doAddEmployeeType');
Route::post('/doUpdateEmptype', 'Api\EmployeeTypeManagement\EmployeeTypeManagementController@doUpdateEmptype');

// menu routing
Route::prefix('menu')->group(function () {
    //main module
    Route::any('getMenuList', 'Api\MenuSettings\ModuleController@getMenuList');
    Route::any('addModule/{type}/', 'Api\MenuSettings\ModuleController@addModule');
    Route::post('viewModuleInfo', 'Api\MenuSettings\ModuleController@viewModuleInfo');
    Route::delete('moduleDelete', 'Api\MenuSettings\ModuleController@moduleDelete');
    Route::post('getParentModuleList', 'Api\MenuSettings\ModuleController@getParentModuleList');
});

//sub module
Route::prefix('submenu')->group(function () {
    Route::any('getMenuList', 'Api\MenuSettings\SubModuleController@getMenuList');
    Route::any('addModule/{type}/', 'Api\MenuSettings\SubModuleController@addModule');
    Route::post('viewModuleInfo', 'Api\MenuSettings\SubModuleController@viewModuleInfo');
    Route::delete('moduleDelete', 'Api\MenuSettings\SubModuleController@moduleDelete');
});

//sub module
Route::prefix('role')->group(function () {
    Route::any('getRoleList', 'Api\RoleManagementController@getRoleList');
    Route::any('addRole/{type}/', 'Api\RoleManagementController@addRole');
    Route::post('viewRoleInfo', 'Api\RoleManagementController@viewRoleInfo');
    Route::delete('roleDelete', 'Api\RoleManagementController@roleDelete');
});

//product
Route::prefix('product')->group(function () {
    Route::any('getProductList', 'Api\ProductManagement\ProductController@getProductList');
    Route::any('addProduct', 'Api\ProductManagement\ProductController@addProduct');
    Route::any('updateProduct', 'Api\ProductManagement\ProductController@updateProduct');
    Route::post('viewRoleInfo', 'Api\RoleManagementController@viewRoleInfo');
    Route::delete('roleDelete', 'Api\RoleManagementController@roleDelete');
    //product module
    Route::post('viewsubmodule', 'Api\MenuSettings\SubModuleController@viewsubmodule');
    Route::any('addProductRoleModuleMap', 'Api\ProductManagement\ProductController@addProductRoleModuleMap');
    Route::post('updateProductRoleModuleMap', 'Api\ProductManagement\ProductController@updateProductRoleModuleMap');
    Route::any('ProductRoleModuleMapList', 'Api\ProductManagement\ProductController@ProductRoleModuleMapList');
    Route::post('viewProductRoleMap', 'Api\ProductManagement\ProductController@viewProductRoleMap');
    Route::delete('productrolemapDelete', 'Api\ProductManagement\ProductController@productrolemapDelete');
    //product user access
    Route::any('ProductUserAccessList', 'Api\ProductManagement\ProductController@ProductUserAccessList');
    Route::any('createUserAccess', 'Api\ProductManagement\ProductController@createUserAccess');
    Route::delete('deleteUserAccess', 'Api\ProductManagement\ProductController@deleteUserAccess');
    Route::post('updateUserAccess', 'Api\ProductManagement\ProductController@updateUserAccess');
});


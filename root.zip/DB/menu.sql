-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               10.1.25-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for test
CREATE DATABASE IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `test`;

-- Dumping structure for table test.menu
CREATE TABLE IF NOT EXISTS `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(150) NOT NULL,
  `parent_page_active` varchar(150) NOT NULL,
  `child_page_active` varchar(150) NOT NULL,
  `menu_code` varchar(250) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_parent` tinyint(4) DEFAULT '1',
  `menu_icon` varchar(150) DEFAULT NULL,
  `menu_url` varchar(150) DEFAULT NULL,
  `order_seq` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table test.menu: ~10 rows (approximately)
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`menu_id`, `page_name`, `parent_page_active`, `child_page_active`, `menu_code`, `parent_id`, `is_parent`, `menu_icon`, `menu_url`, `order_seq`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 'Dashboard', 'Dashboard', '', 'UDUAS01-01', NULL, 1, 'fa fa-dashboard', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(2, 'Admin Dashboard', 'Admin Dashboard', 'Dashboard', 'UUUAS02-02', 1, 0, 'fa fa-fw fa-dashcube', 'admindashboard', 2, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(3, 'User Dashboard', 'User Dashboard', 'Dashboard', 'UAUAS03-03', 1, 0, 'fa fa-fw fa-user-secret', 'userdashboard', 3, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(4, 'User Management', 'User Management', '', 'UUUAS04-04', NULL, 1, 'fa fa-user', 'usermanagement', 4, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(5, 'Hierarchy Management', 'Hierarchy Management', '', 'UHUAS05-05', NULL, 1, 'fa fa-fw fa-hand-lizard-o', 'hierarchymanagement', 5, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(6, 'App Settings\'s', 'App Settings\'s', '', 'UAUAS06-06', NULL, 1, 'fa fa-cogs', NULL, 6, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(7, 'Employee Type Management', 'Employee Type Management', 'App Settings\'s', 'UEUAS07-07', 6, 0, 'fa fa-fw fa-users', 'emptypemanagement', 7, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(8, 'Product Management', 'Product Management', '', 'UPUAS11-11', NULL, 1, 'fa fa-cogs', NULL, 8, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(9, 'Product Details', 'Product Details', 'Product Management', 'UPUAS12-12', 8, 0, 'fa fa-cogs', 'product/productdetails', 9, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(10, 'Role Management', 'Role Management', '', 'URUAS13-13', NULL, 1, 'fa fa-fw fa-child', 'rolemanagement', 10, 1, 0, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

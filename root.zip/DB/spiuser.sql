-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               10.1.25-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for test
CREATE DATABASE IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `test`;

-- Dumping structure for table test.emplyoee_type
CREATE TABLE IF NOT EXISTS `emplyoee_type` (
  `emplyoee_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`emplyoee_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table test.emplyoee_type: ~5 rows (approximately)
/*!40000 ALTER TABLE `emplyoee_type` DISABLE KEYS */;
INSERT INTO `emplyoee_type` (`emplyoee_type_id`, `type_name`, `description`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 'SPI User', NULL, 1, 0, '2018-12-07 10:12:08', NULL, NULL, NULL, NULL),
	(2, 'Freelancer', 'test', 1, 0, '2018-12-07 10:12:34', NULL, '2018-12-07 14:52:15', NULL, NULL),
	(3, 'Others', NULL, 1, 0, '2018-12-07 10:12:36', NULL, NULL, NULL, NULL),
	(4, 'ter', 'ttrewt', 1, 1, '2018-12-07 14:19:23', NULL, '2018-12-07 14:21:52', NULL, NULL),
	(5, 'dtyre', 'trt', 1, 0, '2018-12-28 06:03:37', NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `emplyoee_type` ENABLE KEYS */;

-- Dumping structure for table test.hierarchy
CREATE TABLE IF NOT EXISTS `hierarchy` (
  `hierarchy_id` int(11) NOT NULL AUTO_INCREMENT,
  `hierarchy_name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `depth` int(11) DEFAULT '0',
  `primary_incharge` int(11) DEFAULT '0',
  `secondary_incharge` int(11) DEFAULT '0',
  `temporary_incharge` int(11) DEFAULT '0',
  `from_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`hierarchy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

-- Dumping data for table test.hierarchy: ~7 rows (approximately)
/*!40000 ALTER TABLE `hierarchy` DISABLE KEYS */;
INSERT INTO `hierarchy` (`hierarchy_id`, `hierarchy_name`, `description`, `parent_id`, `depth`, `primary_incharge`, `secondary_incharge`, `temporary_incharge`, `from_date`, `end_date`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 'SPI', 'SPI Global', 0, 0, 11, 12, 0, NULL, NULL, 1, 0, '2018-12-06 19:44:10', NULL, NULL, 0, NULL),
	(2, 'EMS', NULL, 1, 0, 0, 0, 0, NULL, NULL, 1, 1, '2018-12-05 13:55:02', NULL, '2018-12-06 10:37:54', NULL, NULL),
	(19, 'HEALTHCARE', 'HEALTHCARE', 1, 0, 12, 12, 0, NULL, NULL, 1, 0, '2018-12-06 19:44:05', NULL, NULL, NULL, NULL),
	(20, 'HEALTHCARE', 'HEALTHCARE 1', 19, 0, 12, 12, 12, NULL, NULL, 1, 0, '2018-12-06 19:44:06', NULL, '2018-12-07 07:33:40', NULL, NULL),
	(22, 'HEALTHCARE', 'EMS 1', 22, 0, 12, 15, 11, NULL, NULL, 1, 0, '2018-12-06 19:44:07', NULL, '2018-12-13 07:22:20', NULL, NULL),
	(23, 'EMS g', 'EMS 1', 23, 0, 12, 15, 14, NULL, NULL, 1, 0, '2018-12-06 19:44:07', NULL, '2018-12-07 07:25:52', NULL, NULL),
	(24, 'EMS', 'scg', 20, 0, 12, 15, 0, NULL, NULL, 1, 0, '2018-12-06 19:44:08', NULL, '2018-12-06 14:16:59', NULL, NULL);
/*!40000 ALTER TABLE `hierarchy` ENABLE KEYS */;

-- Dumping structure for table test.menu
CREATE TABLE IF NOT EXISTS `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(150) NOT NULL,
  `menu_code` varchar(250) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_parent` tinyint(4) DEFAULT '1',
  `menu_icon` varchar(150) DEFAULT NULL,
  `menu_url` varchar(150) DEFAULT NULL,
  `order_seq` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table test.menu: ~10 rows (approximately)
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`menu_id`, `page_name`, `menu_code`, `parent_id`, `is_parent`, `menu_icon`, `menu_url`, `order_seq`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 'Dashboard', 'UDUAS01-01', NULL, 1, 'fa fa-dashboard', NULL, 1, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(2, 'Admin Dashboard', 'UUUAS02-02', 1, 0, 'fa fa-fw fa-dashcube', 'admindashboard', 2, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(3, 'User Dashboard', 'UAUAS03-03', 1, 0, 'fa fa-fw fa-user-secret', 'userdashboard', 3, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(4, 'User Management', 'UUUAS04-04', NULL, 1, 'fa fa-user', 'usermanagement', 4, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(5, 'Hierarchy Management', 'UHUAS05-05', NULL, 1, 'fa fa-fw fa-hand-lizard-o', 'hierarchymanagement', 5, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(6, 'App Settings\'s', 'UAUAS06-06', NULL, 1, 'fa fa-cogs', NULL, 6, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(7, 'Employee Type Management', 'UEUAS07-07', 6, 0, 'fa fa-fw fa-users', 'emptypemanagement', 7, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(8, 'Product Management', 'UPUAS11-11', NULL, 1, 'fa fa-cogs', NULL, 8, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(9, 'Product Details', 'UPUAS12-12', 8, 0, 'fa fa-cogs', 'product/productdetails', 9, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(10, 'Role Management', 'URUAS13-13', NULL, 1, 'fa fa-fw fa-child', 'rolemanagement', 10, 1, 0, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;

-- Dumping structure for table test.menu_access
CREATE TABLE IF NOT EXISTS `menu_access` (
  `menu_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `menu_code` varchar(250) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_access_id`),
  KEY `FK_menu_access_menu` (`menu_id`),
  CONSTRAINT `FK_menu_access_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- Dumping data for table test.menu_access: ~4 rows (approximately)
/*!40000 ALTER TABLE `menu_access` DISABLE KEYS */;
INSERT INTO `menu_access` (`menu_access_id`, `menu_id`, `menu_code`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 1, 'UAUAS60-23', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(6, 1, 'URUAS55-21', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(7, 1, 'UGUAS59-22', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(9, 2, 'UUUAS02-02', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(10, 2, 'UUUAS02-02', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(11, 2, 'UUUAS02-02', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(12, 2, 'UUUAS02-02', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(13, 3, 'UAUAS03-03', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(14, 3, 'UAUAS03-03', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(15, 3, 'UAUAS03-03', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(16, 1, 'UDUAS01-01', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(17, 1, 'UDUAS01-01', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(18, 1, 'UDUAS01-01', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(19, 4, 'UUUAS04-04', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(20, 4, 'UUUAS04-04', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(21, 4, 'UUUAS04-04', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(22, 5, 'UHUAS05-05', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(23, 5, 'UHUAS05-05', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(24, 5, 'UHUAS05-05', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(25, 6, 'UAUAS06-06', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(26, 6, 'UAUAS06-06', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(27, 6, 'UAUAS06-06', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(28, 7, 'UEUAS07-07', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(29, 7, 'UEUAS07-07', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(30, 7, 'UEUAS07-07', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(31, 1, 'UPUAS11-11', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(32, 8, 'UPUAS11-11', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(33, 8, 'UPUAS11-11', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(34, 8, 'UPUAS11-11', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(35, 9, 'UPUAS12-12', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(36, 9, 'UPUAS12-12', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(37, 9, 'UPUAS12-12', 1, 0, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `menu_access` ENABLE KEYS */;

-- Dumping structure for table test.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.migrations: ~0 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table test.module
CREATE TABLE IF NOT EXISTS `module` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `module_code` varchar(50) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `is_parent` tinyint(4) NOT NULL DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `module_type` enum('1','2','3','4') NOT NULL DEFAULT '1' COMMENT '1 - uppercase,2 - lowercase,3 - upper fisrt charater,4 - upper fisrt charater each word',
  `description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

-- Dumping data for table test.module: ~33 rows (approximately)
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
INSERT INTO `module` (`module_id`, `product_id`, `module_code`, `module_name`, `is_parent`, `parent_id`, `module_type`, `description`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 1, 'UDUAS01-01', 'Dashboard', 1, NULL, '3', NULL, 1, 0, '2018-12-07 13:06:23', NULL, '2018-12-20 10:10:47', NULL, NULL),
	(2, 1, 'UUUAS02-02', 'User Dashboard', 0, 1, '3', NULL, 1, 0, NULL, NULL, '2018-12-17 07:31:40', NULL, NULL),
	(3, 1, 'UAUAS03-03', 'Admin Dashboard', 0, 1, '3', NULL, 1, 0, NULL, NULL, '2018-12-17 07:29:49', NULL, NULL),
	(4, 1, 'UUUAS04-04', 'User Management', 1, NULL, '3', NULL, 1, 0, NULL, NULL, '2018-12-10 14:02:20', NULL, NULL),
	(5, 1, 'UHUAS05-05', 'Hierarchy Management', 1, NULL, '3', NULL, 1, 0, NULL, NULL, '2018-12-07 14:56:50', NULL, NULL),
	(6, 1, 'UAUAS06-06', 'App Settings\'s', 1, NULL, '3', NULL, 1, 0, NULL, NULL, '2018-12-07 14:52:50', NULL, NULL),
	(7, 1, 'UEUAS07-07', 'Employee Type Management', 0, 6, '3', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(11, 1, 'UPUAS11-11', 'Product Management', 1, NULL, '3', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(12, 1, 'UPUAS12-12', 'Product Details', 0, 11, '3', NULL, 1, 0, '2018-12-10 10:52:45', NULL, '2018-12-11 05:08:33', NULL, NULL),
	(13, 1, 'URUAS13-13', 'Role Management', 1, NULL, '3', NULL, 1, 0, '2018-12-14 06:09:46', NULL, '2018-12-14 06:58:46', NULL, NULL),
	(87, 2, 'FDFMS85-02', 'Dashboard', 1, NULL, '1', 'Dashboard', 1, 0, '2018-12-20 13:30:17', NULL, NULL, 14, NULL),
	(88, 2, 'FFFMS88-03', 'Freelancers', 1, NULL, '1', 'Freelancers', 1, 0, '2018-12-20 13:30:27', NULL, NULL, 14, NULL),
	(89, 2, 'FMFMS89-04', 'Manage Freelancers', 0, 88, '1', 'Manage Freelancers', 1, 0, '2018-12-20 13:31:39', NULL, NULL, 14, NULL),
	(90, 2, 'FMFMS90-05', 'Manage PMs', 1, NULL, '1', 'Manage PMs', 1, 0, '2018-12-20 13:31:49', NULL, NULL, 14, NULL),
	(91, 2, 'FMFMS91-06', 'Manage Services', 1, NULL, '1', 'Manage Services', 1, 0, '2018-12-20 13:31:56', NULL, NULL, 14, NULL),
	(92, 2, 'FMFMS92-07', 'Manage Clients', 1, NULL, '1', 'Manage Clients', 1, 0, '2018-12-20 13:32:05', NULL, NULL, 14, NULL),
	(93, 2, 'FMFMS93-08', 'Manage Projects', 1, NULL, '1', 'Manage Projects', 1, 0, '2018-12-20 13:32:12', NULL, NULL, 14, NULL),
	(94, 2, 'FRFMS94-09', 'Reports', 1, NULL, '1', 'Reports', 1, 0, '2018-12-20 13:32:18', NULL, NULL, 14, NULL),
	(95, 2, 'FFFMS95-10', 'FL Communication', 1, NULL, '1', 'FL Communication', 1, 0, '2018-12-20 13:32:25', NULL, NULL, 14, NULL),
	(96, 2, 'FFFMS96-11', 'FL Queries & Mails', 1, NULL, '1', 'FL Queries & Mails', 1, 0, '2018-12-20 13:32:35', NULL, NULL, 14, NULL),
	(97, 2, 'FSFMS97-12', 'SPiCE Installation', 1, NULL, '1', 'SPiCE Installation', 1, 0, '2018-12-20 13:32:43', NULL, NULL, 14, NULL),
	(98, 2, 'FCFMS98-13', 'Contract Forms', 1, NULL, '1', 'Contract Forms', 1, 0, '2018-12-20 13:32:51', NULL, NULL, 14, NULL),
	(99, 2, 'FCFMS99-14', 'Client Managers', 1, NULL, '1', 'Client Managers', 1, 0, '2018-12-20 13:33:21', NULL, NULL, 14, NULL),
	(100, 2, 'FPFMS100-15', 'Projects', 1, NULL, '1', 'Projects', 1, 0, '2018-12-20 13:33:32', NULL, NULL, 14, NULL),
	(101, 2, 'FMFMS101-16', 'My Projects', 1, NULL, '1', 'My Projects', 1, 0, '2018-12-20 13:33:38', NULL, NULL, 14, NULL),
	(102, 2, 'FMFMS102-17', 'Manage PEs', 1, NULL, '1', 'Manage PEs', 1, 0, '2018-12-20 13:33:47', NULL, NULL, 14, NULL),
	(103, 2, 'FPFMS103-18', 'Preferences', 1, NULL, '1', 'Preferences', 1, 0, '2018-12-20 13:34:20', NULL, NULL, 14, NULL),
	(105, 2, 'FIFMS105-20', 'Instructions', 1, NULL, '1', 'Instructions', 1, 0, '2018-12-20 13:35:56', NULL, NULL, 14, NULL),
	(106, 2, 'FWFMS106-21', 'Work Instructions', 0, 105, '1', 'Work Instructions', 1, 0, '2018-12-20 13:36:13', NULL, NULL, 14, NULL),
	(107, 2, 'FIFMS107-22', 'Invoicing Instructions', 0, 105, '1', 'Invoicing Instructions', 1, 0, '2018-12-20 13:36:22', NULL, NULL, 14, NULL),
	(108, 2, 'FDFMS108-23', 'Dashboard A', 0, 87, '1', 'Dashboard 2', 1, 0, '2018-12-20 14:05:09', NULL, NULL, 14, NULL),
	(109, 2, 'FCFMS109-24', 'Child freelancers', 0, 88, '1', 'Child freelancers', 1, 0, '2018-12-21 07:17:58', NULL, NULL, 14, NULL),
	(110, 2, 'FDFMS108-25', 'Dashboard B', 0, 87, '1', 'Dashboard 2', 1, 0, '2018-12-20 14:05:09', NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `module` ENABLE KEYS */;

-- Dumping structure for table test.module_items
CREATE TABLE IF NOT EXISTS `module_items` (
  `module_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `module_item_code` varchar(50) NOT NULL,
  `module_item_name` varchar(200) NOT NULL,
  `module_item_description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`module_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

-- Dumping data for table test.module_items: ~26 rows (approximately)
/*!40000 ALTER TABLE `module_items` DISABLE KEYS */;
INSERT INTO `module_items` (`module_item_id`, `module_id`, `module_item_code`, `module_item_name`, `module_item_description`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(25, 36, 'FM14-01', 'Manage Freelancers', 'Manage Freelancers', 1, 0, '2018-12-18 09:47:51', NULL, '2018-12-18 09:47:51', NULL, NULL),
	(26, 52, 'FP26-02', 'Project', 'Project', 1, 0, '2018-12-18 09:50:27', NULL, '2018-12-18 09:50:27', NULL, NULL),
	(27, 52, 'FG27-03', 'General', 'General', 1, 0, '2018-12-18 09:50:31', NULL, '2018-12-18 09:50:31', NULL, NULL),
	(28, 53, 'FW28-04', 'Work Instructions', 'Work Instructions', 1, 0, '2018-12-18 09:50:49', NULL, '2018-12-18 09:50:49', NULL, NULL),
	(29, 53, 'FI29-05', 'Invoicing Instructions', 'Invoicing Instructions', 1, 0, '2018-12-18 09:50:55', NULL, '2018-12-18 09:50:55', NULL, NULL),
	(33, 87, 'FAFMS33-03', 'Assign to me', 'Assign to me', 1, 0, '2018-12-20 13:59:02', NULL, '2018-12-20 13:59:02', NULL, NULL),
	(34, 87, 'FAFMS34-04', 'Activity', 'Activity', 1, 0, '2018-12-20 13:59:13', NULL, '2018-12-20 13:59:13', NULL, NULL),
	(35, 87, 'FIFMS35-05', 'Introduction', 'Introduction', 1, 0, '2018-12-20 13:59:32', NULL, '2018-12-20 13:59:32', NULL, NULL),
	(36, 88, 'FUFMS36-06', 'User System', 'User System', 1, 0, '2018-12-20 14:00:41', NULL, '2018-12-20 14:00:41', NULL, NULL),
	(37, 108, 'FDFMS37-07', 'dashboard view', 'dashboard view', 1, 0, '2018-12-21 05:58:08', NULL, '2018-12-21 05:58:08', NULL, NULL),
	(38, 108, 'FDFMS38-08', 'dashboard view1', 'dashboard view', 1, 0, '2018-12-21 05:58:14', NULL, '2018-12-21 05:58:14', NULL, NULL),
	(39, 107, 'FIFMS39-09', 'Invoice Test', 'Invoice Test', 1, 0, '2018-12-21 05:58:26', NULL, '2018-12-21 05:58:26', NULL, NULL),
	(40, 107, 'FIFMS40-10', 'Invoice Test 1', 'Invoice Test', 1, 0, '2018-12-21 05:58:29', NULL, '2018-12-21 05:58:29', NULL, NULL),
	(41, 106, 'FIFMS41-11', 'Instructions1', 'Instructions1', 1, 0, '2018-12-21 05:59:10', NULL, '2018-12-21 05:59:10', NULL, NULL),
	(42, 106, 'FIFMS42-12', 'Instructions', 'Instructions1', 1, 0, '2018-12-21 05:59:14', NULL, '2018-12-21 05:59:14', NULL, NULL),
	(43, 103, 'FOFMS43-13', 'One', 'One', 1, 1, '2018-12-21 05:59:28', NULL, '2018-12-21 09:41:44', NULL, NULL),
	(44, 102, 'FTFMS44-14', 'Test description', 'Test description', 1, 0, '2018-12-21 05:59:43', NULL, '2018-12-21 05:59:43', NULL, NULL),
	(45, 89, 'FUFMS45-15', 'user freelancer', 'user freelancer', 1, 0, '2018-12-21 06:00:04', NULL, '2018-12-21 06:00:04', NULL, NULL),
	(46, 89, 'FOFMS46-16', 'other freelancer', 'other freelancer', 1, 0, '2018-12-21 06:00:13', NULL, '2018-12-21 06:00:13', NULL, NULL),
	(47, 96, 'FUFMS47-17', 'User Queries', 'User Queries', 1, 0, '2018-12-21 06:01:05', NULL, '2018-12-21 06:01:05', NULL, NULL),
	(48, 96, 'FPFMS48-18', 'Production Queries', 'Production Queries', 1, 0, '2018-12-21 06:01:13', NULL, '2018-12-21 06:01:13', NULL, NULL),
	(49, 103, 'FFFMS49-19', 'First preference', 'First preference', 1, 0, '2018-12-21 09:42:10', NULL, '2018-12-21 09:42:10', NULL, NULL),
	(54, 103, 'FSFMS50-20', 'Second preference', 'preference', 1, 0, '2018-12-22 11:19:25', NULL, '2018-12-22 11:19:25', NULL, NULL),
	(58, 1, 'URUAS55-21', 'RECENT ACTIVITY', 'RECENT ACTIVITY', 1, 0, '2018-12-29 16:15:27', NULL, '2018-12-29 16:15:27', NULL, NULL),
	(59, 1, 'UGUAS59-22', 'Grid Box', 'Grid Box', 1, 0, '2018-12-29 16:15:35', NULL, '2018-12-29 16:15:35', NULL, NULL),
	(60, 1, 'UAUAS60-23', 'Actions', 'Actions', 1, 0, '2018-12-29 16:15:44', NULL, '2018-12-29 16:15:44', NULL, NULL);
/*!40000 ALTER TABLE `module_items` ENABLE KEYS */;

-- Dumping structure for table test.module_type_enum
CREATE TABLE IF NOT EXISTS `module_type_enum` (
  `module_type_enum_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_type_name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`module_type_enum_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table test.module_type_enum: ~4 rows (approximately)
/*!40000 ALTER TABLE `module_type_enum` DISABLE KEYS */;
INSERT INTO `module_type_enum` (`module_type_enum_id`, `module_type_name`, `description`, `is_active`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 'Upper Case', NULL, 1, NULL, NULL, NULL, NULL, NULL),
	(2, 'Lower Case', NULL, 1, NULL, NULL, NULL, NULL, NULL),
	(3, 'Upper First Character', NULL, 1, NULL, NULL, NULL, NULL, NULL),
	(4, 'Upper First Character Each Word', NULL, 1, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `module_type_enum` ENABLE KEYS */;

-- Dumping structure for table test.products
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_app_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_type` enum('1','2') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '1- workflow,2 -hr',
  `product_short_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '1',
  `product_live_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_uat_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` mediumtext COLLATE utf8mb4_unicode_ci,
  `product_logo` text COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `is_deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.products: ~4 rows (approximately)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`product_id`, `product_app_id`, `product_name`, `product_token`, `product_type`, `product_short_name`, `user_id`, `product_live_url`, `product_uat_url`, `product_owner`, `product_description`, `product_logo`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `is_active`, `is_deleted`) VALUES
	(1, 'APPID001', 'USER MANAGEMENT', '1561DWE', '1', 'UAS', 1, 'https://fms.spi-global.com/', 'https://fms.spi-global.com/', 'Mathan', '<p>0</p>', 'http://172.24.177.171:8082/productManagement/assets/dist/img/avatar5.png', 1, 14, '2018-12-03 10:55:06', '2018-12-24 09:44:46', NULL, 1, 0),
	(2, 'APPID002', 'FMS', '54DFEWR', '2', 'FMS', 1, 'https://fms.spi-global.com/', 'https://fms.spi-global.com/', 'Spi Global', '<p>SPi Global is a market leader in technology-driven solutions for the extraction, enrichment and transformation of content assets. Our suite of proprietary technology platforms combined with our deep understanding of content workflows and data structures is the reason we are the partner of choice of leading information companies.</p>\n\n<p>While content is the key product of information companies, it is fast becoming a key differentiator across each industry. Our vision is to deploy technology solutions that will make content accessible, adaptable and actionable. This means enabling content to be found easily when you need it, adapted to the device that you are currently using and delivering the insight that you need to make a decision.</p>\n\n<p>There are many ways SPi Global touches lives today and makes a difference. We can make the same difference for you.</p>', 'http://localhost:8082/productManagement/assets/dist/img/fms-logo.png', 1, 14, '2018-12-03 10:58:01', '2018-12-19 07:22:58', NULL, 1, 0),
	(18, 'APPID15', 'HR', 'APPID15', '1', 'HRS', 1, 'https://github.com/Zizaco/entrust', 'https://github.com/Zizaco/entrust', 'trewt', NULL, 'http://172.24.177.171:8082/productManagement/uploads/product_logo/APPID15_Hydrangeas.jpg', NULL, NULL, '2018-12-13 05:52:54', '2018-12-13 05:52:54', NULL, 1, 0),
	(19, 'APPID19', 'Healthcare', 'APPID19', '1', 'HCS', 1, 'https://docs.laravel-enso.com/guide/getting-started.html', 'https://docs.laravel-enso.com/guide/getting-started.html', 'Healthcare', '<h1>test description</h1>', 'http://172.24.177.171:8082/productManagement/uploads/product_logo/APPID19_Lighthouse.jpg', NULL, 11, '2018-12-13 09:15:17', '2018-12-13 11:44:29', NULL, 1, 0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dumping structure for table test.products_info
CREATE TABLE IF NOT EXISTS `products_info` (
  `products_info_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `user_engaged` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `products_version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `is_deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`products_info_id`),
  KEY `FK_products_info_products` (`product_id`),
  CONSTRAINT `FK_products_info_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.products_info: ~3 rows (approximately)
/*!40000 ALTER TABLE `products_info` DISABLE KEYS */;
INSERT INTO `products_info` (`products_info_id`, `product_id`, `user_engaged`, `products_version`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `is_active`, `is_deleted`) VALUES
	(9, 18, '304', '1.5', NULL, NULL, '2018-12-13 05:52:54', '2018-12-13 05:52:54', NULL, 1, 0),
	(10, 19, '100', '1.5', NULL, 11, '2018-12-13 09:15:17', '2018-12-13 11:44:56', NULL, 1, 0),
	(11, 2, '100', '1', NULL, 14, NULL, '2018-12-19 07:24:17', NULL, 1, 0),
	(12, 1, '10000', '2', NULL, 14, NULL, '2018-12-28 06:54:05', NULL, 1, 0);
/*!40000 ALTER TABLE `products_info` ENABLE KEYS */;

-- Dumping structure for table test.product_access
CREATE TABLE IF NOT EXISTS `product_access` (
  `product_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `hierarchy_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_access: ~5 rows (approximately)
/*!40000 ALTER TABLE `product_access` DISABLE KEYS */;
INSERT INTO `product_access` (`product_access_id`, `product_id`, `hierarchy_id`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(2, 14, 19, 1, 0, NULL, NULL, NULL, 11, NULL),
	(3, 18, 19, 1, 0, NULL, NULL, NULL, 11, NULL),
	(7, 19, 20, 1, 0, NULL, NULL, NULL, 11, NULL),
	(11, 2, 1, 1, 0, NULL, NULL, NULL, 14, NULL),
	(13, 1, 1, 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_access` ENABLE KEYS */;

-- Dumping structure for table test.product_contact
CREATE TABLE IF NOT EXISTS `product_contact` (
  `product_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `contact_mail` varchar(250) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_contact: ~5 rows (approximately)
/*!40000 ALTER TABLE `product_contact` DISABLE KEYS */;
INSERT INTO `product_contact` (`product_contact_id`, `product_id`, `contact_mail`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(2, 14, 'mathankumar.p@spi-global.com', 1, 0, NULL, NULL, NULL, 11, NULL),
	(3, 18, 'mathankumar.p@spi-global.com', 1, 0, NULL, NULL, NULL, 11, NULL),
	(6, 19, 'mathankumar.p@spi-global.com', 1, 0, NULL, NULL, NULL, 11, NULL),
	(10, 2, 'arunkumar.P@spi-global.com', 1, 0, NULL, NULL, NULL, 14, NULL),
	(12, 1, 'arunkumar.P@spi-global.com', 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_contact` ENABLE KEYS */;

-- Dumping structure for table test.product_developed
CREATE TABLE IF NOT EXISTS `product_developed` (
  `product_developed_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_developed_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_developed: ~5 rows (approximately)
/*!40000 ALTER TABLE `product_developed` DISABLE KEYS */;
INSERT INTO `product_developed` (`product_developed_id`, `product_id`, `user_id`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(2, 14, 12, 1, 0, NULL, NULL, NULL, 11, NULL),
	(3, 18, 12, 1, 0, NULL, NULL, NULL, 11, NULL),
	(6, 19, 12, 1, 0, NULL, NULL, NULL, 11, NULL),
	(10, 2, 11, 1, 0, NULL, NULL, NULL, 14, NULL),
	(12, 1, 11, 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_developed` ENABLE KEYS */;

-- Dumping structure for table test.product_keywords
CREATE TABLE IF NOT EXISTS `product_keywords` (
  `product_keywords_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `keywords` mediumtext,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_keywords_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_keywords: ~10 rows (approximately)
/*!40000 ALTER TABLE `product_keywords` DISABLE KEYS */;
INSERT INTO `product_keywords` (`product_keywords_id`, `product_id`, `keywords`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 14, 'useradmin', 1, 0, NULL, NULL, NULL, 11, NULL),
	(2, 14, 'subadmin', 1, 0, NULL, NULL, NULL, 11, NULL),
	(3, 18, 'rtet r', 1, 0, NULL, NULL, NULL, 11, NULL),
	(4, 18, 'tewrtewrt', 1, 0, NULL, NULL, NULL, 11, NULL),
	(11, 19, 'test', 1, 0, NULL, NULL, NULL, 11, NULL),
	(12, 19, 'test', 1, 0, NULL, NULL, NULL, 11, NULL),
	(13, 19, 'ig', 1, 0, NULL, NULL, NULL, 11, NULL),
	(14, 19, ' tesone', 1, 0, NULL, NULL, NULL, 11, NULL),
	(18, 2, 'FMS', 1, 0, NULL, NULL, NULL, 14, NULL),
	(20, 1, '', 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_keywords` ENABLE KEYS */;

-- Dumping structure for table test.product_manufacture
CREATE TABLE IF NOT EXISTS `product_manufacture` (
  `product_manufacture_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `hierarchy_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_manufacture_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_manufacture: ~5 rows (approximately)
/*!40000 ALTER TABLE `product_manufacture` DISABLE KEYS */;
INSERT INTO `product_manufacture` (`product_manufacture_id`, `product_id`, `hierarchy_id`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(2, 14, 19, 1, 0, NULL, NULL, NULL, 11, NULL),
	(3, 18, 1, 1, 0, NULL, NULL, NULL, 11, NULL),
	(6, 19, 19, 1, 0, NULL, NULL, NULL, 11, NULL),
	(10, 2, 1, 1, 0, NULL, NULL, NULL, 14, NULL),
	(12, 1, 1, 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_manufacture` ENABLE KEYS */;

-- Dumping structure for table test.product_other_tools
CREATE TABLE IF NOT EXISTS `product_other_tools` (
  `product_other_tools_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `main_product_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_other_tools_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_other_tools: ~5 rows (approximately)
/*!40000 ALTER TABLE `product_other_tools` DISABLE KEYS */;
INSERT INTO `product_other_tools` (`product_other_tools_id`, `product_id`, `main_product_id`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(2, 14, 3, 1, 0, NULL, NULL, NULL, 11, NULL),
	(3, 18, 3, 1, 0, NULL, NULL, NULL, 11, NULL),
	(6, 19, 19, 1, 0, NULL, NULL, NULL, 11, NULL),
	(10, 2, 2, 1, 0, NULL, NULL, NULL, 14, NULL),
	(12, 1, 18, 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_other_tools` ENABLE KEYS */;

-- Dumping structure for table test.product_role
CREATE TABLE IF NOT EXISTS `product_role` (
  `product_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_role: ~3 rows (approximately)
/*!40000 ALTER TABLE `product_role` DISABLE KEYS */;
INSERT INTO `product_role` (`product_role_id`, `product_id`, `role_id`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(3, 19, 1, 1, 0, NULL, NULL, NULL, 11, NULL),
	(7, 2, 1, 1, 0, NULL, NULL, NULL, 14, NULL),
	(9, 1, 1, 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_role` ENABLE KEYS */;

-- Dumping structure for table test.product_role_module_map
CREATE TABLE IF NOT EXISTS `product_role_module_map` (
  `product_role_module_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `module_item_id` int(11) DEFAULT NULL,
  `module_code` varchar(250) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_role_module_map_id`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_role_module_map: ~110 rows (approximately)
/*!40000 ALTER TABLE `product_role_module_map` DISABLE KEYS */;
INSERT INTO `product_role_module_map` (`product_role_module_map_id`, `product_id`, `role_id`, `module_id`, `module_item_id`, `module_code`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(19, 2, 1, 89, NULL, 'FMFMS89-04', 1, 1, '2018-12-21 14:53:16', NULL, '2018-12-24 08:11:06', 14, NULL),
	(20, 2, 1, 88, 36, 'FUFMS36-06', 1, 1, '2018-12-21 14:53:16', NULL, '2018-12-24 08:11:06', 14, NULL),
	(21, 2, 1, 89, 45, 'FUFMS45-15', 1, 1, '2018-12-21 14:53:16', NULL, '2018-12-24 08:11:06', 14, NULL),
	(22, 2, 1, 89, 46, 'FOFMS46-16', 1, 1, '2018-12-21 14:53:16', NULL, '2018-12-24 08:11:06', 14, NULL),
	(23, 1, 1, 89, 46, 'FOFMS46-16', 1, 1, '2018-12-21 14:53:16', NULL, '2018-12-29 10:40:43', 14, NULL),
	(87, 2, 1, 87, 34, 'FAFMS34-04', 1, 1, '2018-12-22 10:24:59', NULL, '2018-12-24 08:11:06', 14, NULL),
	(88, 2, 1, 107, NULL, 'FIFMS107-22', 1, 1, '2018-12-22 10:30:47', NULL, '2018-12-24 08:11:06', 14, NULL),
	(89, 2, 1, 87, 34, 'FAFMS34-04', 1, 1, '2018-12-22 10:30:47', NULL, '2018-12-24 08:11:06', 14, NULL),
	(90, 2, 1, 107, 39, 'FIFMS39-09', 1, 1, '2018-12-22 10:30:47', NULL, '2018-12-24 08:11:06', 14, NULL),
	(93, 2, 1, 87, NULL, 'FDFMS85-02', 1, 1, '2018-12-24 08:10:21', NULL, '2018-12-24 08:11:06', 14, NULL),
	(94, 2, 1, 108, NULL, 'FDFMS108-23', 1, 1, '2018-12-24 08:10:21', NULL, '2018-12-24 08:11:06', 14, NULL),
	(95, 2, 1, 110, NULL, 'FDFMS108-25', 1, 1, '2018-12-24 08:10:21', NULL, '2018-12-24 08:11:06', 14, NULL),
	(96, 2, 1, 88, NULL, 'FFFMS88-03', 1, 1, '2018-12-24 08:10:21', NULL, '2018-12-24 08:11:06', 14, NULL),
	(97, 2, 1, 89, NULL, 'FMFMS89-04', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(98, 2, 1, 109, NULL, 'FCFMS109-24', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(99, 2, 1, 90, NULL, 'FMFMS90-05', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(100, 2, 1, 91, NULL, 'FMFMS91-06', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(101, 2, 1, 92, NULL, 'FMFMS92-07', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(102, 2, 1, 93, NULL, 'FMFMS93-08', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(103, 2, 1, 94, NULL, 'FRFMS94-09', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(104, 2, 1, 95, NULL, 'FFFMS95-10', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(105, 2, 1, 96, NULL, 'FFFMS96-11', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(106, 2, 1, 97, NULL, 'FSFMS97-12', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(107, 2, 1, 98, NULL, 'FCFMS98-13', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(108, 2, 1, 99, NULL, 'FCFMS99-14', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(109, 2, 1, 100, NULL, 'FPFMS100-15', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(110, 2, 1, 101, NULL, 'FMFMS101-16', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(111, 2, 1, 102, NULL, 'FMFMS102-17', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(112, 2, 1, 103, NULL, 'FPFMS103-18', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(113, 2, 1, 105, NULL, 'FIFMS105-20', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(114, 2, 1, 106, NULL, 'FWFMS106-21', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(115, 2, 1, 107, NULL, 'FIFMS107-22', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(116, 2, 1, 87, 33, 'FAFMS33-03', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(117, 2, 1, 87, 34, 'FAFMS34-04', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(118, 2, 1, 87, 35, 'FIFMS35-05', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(119, 2, 1, 108, 37, 'FDFMS37-07', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(120, 2, 1, 108, 38, 'FDFMS38-08', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(121, 2, 1, 88, 36, 'FUFMS36-06', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(122, 2, 1, 89, 45, 'FUFMS45-15', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(123, 2, 1, 89, 46, 'FOFMS46-16', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(124, 2, 1, 96, 47, 'FUFMS47-17', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(125, 2, 1, 96, 48, 'FPFMS48-18', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(126, 2, 1, 102, 44, 'FTFMS44-14', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(127, 2, 1, 103, 49, 'FFFMS49-19', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(128, 2, 1, 103, 54, 'FSFMS50-20', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(129, 2, 1, 106, 41, 'FIFMS41-11', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(130, 2, 1, 106, 42, 'FIFMS42-12', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(131, 2, 1, 107, 39, 'FIFMS39-09', 1, 1, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(132, 2, 1, 107, 40, 'FIFMS40-10', 1, 0, '2018-12-24 08:10:22', NULL, '2018-12-24 08:11:06', 14, NULL),
	(133, 2, 1, 108, NULL, 'FDFMS108-23', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(134, 2, 1, 89, NULL, 'FMFMS89-04', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(135, 2, 1, 87, 33, 'FAFMS33-03', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(136, 2, 1, 87, 34, 'FAFMS34-04', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(137, 2, 1, 87, 35, 'FIFMS35-05', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(138, 2, 1, 108, 37, 'FDFMS37-07', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(139, 2, 1, 108, 38, 'FDFMS38-08', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(140, 2, 1, 89, 45, 'FUFMS45-15', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(141, 2, 1, 89, 46, 'FOFMS46-16', 1, 0, '2018-12-24 08:11:06', NULL, NULL, 14, NULL),
	(142, 1, 1, 1, NULL, 'UDUAS01-01', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(143, 1, 1, 2, NULL, 'UUUAS02-02', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(144, 1, 1, 3, NULL, 'UAUAS03-03', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(145, 1, 1, 4, NULL, 'UUUAS04-04', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(146, 1, 1, 5, NULL, 'UHUAS05-05', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(147, 1, 1, 6, NULL, 'UAUAS06-06', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(148, 1, 1, 7, NULL, 'UEUAS07-07', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(149, 1, 1, 11, NULL, 'UPUAS11-11', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(150, 1, 1, 12, NULL, 'UPUAS12-12', 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(151, 1, 1, 2, 2, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(152, 1, 1, 2, 8, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(153, 1, 1, 2, 9, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(154, 1, 1, 2, 10, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(155, 1, 1, 2, 11, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(156, 1, 1, 2, 12, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(157, 1, 1, 3, 4, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(158, 1, 1, 3, 5, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(159, 1, 1, 3, 7, NULL, 1, 1, '2018-12-24 13:36:31', NULL, '2018-12-29 10:40:43', 14, NULL),
	(160, 1, 1, 1, NULL, 'UDUAS01-01', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(161, 1, 1, 2, NULL, 'UUUAS02-02', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(162, 1, 1, 3, NULL, 'UAUAS03-03', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(163, 1, 1, 4, NULL, 'UUUAS04-04', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(164, 1, 1, 5, NULL, 'UHUAS05-05', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(165, 1, 1, 6, NULL, 'UAUAS06-06', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(166, 1, 1, 7, NULL, 'UEUAS07-07', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(167, 1, 1, 11, NULL, 'UPUAS11-11', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(168, 1, 1, 12, NULL, 'UPUAS12-12', 1, 1, '2018-12-28 10:04:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(169, 1, 1, 1, NULL, 'UDUAS01-01', 1, 0, '2018-12-28 10:07:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(170, 1, 1, 2, NULL, 'UUUAS02-02', 1, 1, '2018-12-28 10:07:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(171, 1, 1, 3, NULL, 'UAUAS03-03', 1, 1, '2018-12-28 10:07:35', NULL, '2018-12-29 10:40:43', 14, NULL),
	(172, 1, 1, 4, NULL, 'UUUAS04-04', 1, 1, '2018-12-28 10:07:36', NULL, '2018-12-29 10:40:43', 14, NULL),
	(173, 1, 1, 5, NULL, 'UHUAS05-05', 1, 1, '2018-12-28 10:07:36', NULL, '2018-12-29 10:40:43', 14, NULL),
	(174, 1, 1, 6, NULL, 'UAUAS06-06', 1, 1, '2018-12-28 10:07:36', NULL, '2018-12-29 10:40:43', 14, NULL),
	(175, 1, 1, 7, NULL, 'UEUAS07-07', 1, 1, '2018-12-28 10:07:36', NULL, '2018-12-29 10:40:43', 14, NULL),
	(176, 1, 1, 11, NULL, 'UPUAS11-11', 1, 1, '2018-12-28 10:07:36', NULL, '2018-12-29 10:40:43', 14, NULL),
	(177, 1, 1, 12, NULL, 'UPUAS12-12', 1, 1, '2018-12-28 10:07:36', NULL, '2018-12-29 10:40:43', 14, NULL),
	(178, 1, 1, 13, NULL, 'URUAS13-13', 1, 1, '2018-12-28 10:07:36', NULL, '2018-12-29 10:40:43', 14, NULL),
	(179, 1, 1, 3, NULL, 'UAUAS03-03', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(180, 1, 1, 4, NULL, 'UUUAS04-04', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(181, 1, 1, 5, NULL, 'UHUAS05-05', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(182, 1, 1, 6, NULL, 'UAUAS06-06', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(183, 1, 1, 7, NULL, 'UEUAS07-07', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(184, 1, 1, 11, NULL, 'UPUAS11-11', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(185, 1, 1, 12, NULL, 'UPUAS12-12', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(186, 1, 1, 13, NULL, 'URUAS13-13', 1, 1, '2018-12-29 07:08:28', NULL, '2018-12-29 10:40:43', 14, NULL),
	(187, 1, 1, 3, NULL, 'UAUAS03-03', 1, 0, '2018-12-29 10:40:43', NULL, NULL, 14, NULL),
	(188, 1, 1, 4, NULL, 'UUUAS04-04', 1, 0, '2018-12-29 10:40:43', NULL, NULL, 14, NULL),
	(189, 1, 1, 5, NULL, 'UHUAS05-05', 1, 0, '2018-12-29 10:40:43', NULL, NULL, 14, NULL),
	(190, 1, 1, 6, NULL, 'UAUAS06-06', 1, 0, '2018-12-29 10:40:43', NULL, NULL, 14, NULL),
	(191, 1, 1, 7, NULL, 'UEUAS07-07', 1, 0, '2018-12-29 10:40:43', NULL, NULL, 14, NULL),
	(192, 1, 1, 11, NULL, 'UPUAS11-11', 1, 0, '2018-12-29 10:40:43', NULL, NULL, 14, NULL),
	(193, 1, 1, 12, NULL, 'UPUAS12-12', 1, 0, '2018-12-29 10:40:43', NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_role_module_map` ENABLE KEYS */;

-- Dumping structure for table test.product_technology
CREATE TABLE IF NOT EXISTS `product_technology` (
  `product_technology_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `technology_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_technology_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_technology: ~5 rows (approximately)
/*!40000 ALTER TABLE `product_technology` DISABLE KEYS */;
INSERT INTO `product_technology` (`product_technology_id`, `product_id`, `technology_id`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(2, 14, 2, 1, 0, NULL, NULL, NULL, 11, NULL),
	(3, 18, 2, 1, 0, NULL, NULL, NULL, 11, NULL),
	(6, 19, 1, 1, 0, NULL, NULL, NULL, 11, NULL),
	(10, 2, 1, 1, 0, NULL, NULL, NULL, 14, NULL),
	(12, 1, 1, 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_technology` ENABLE KEYS */;

-- Dumping structure for table test.product_type_enum
CREATE TABLE IF NOT EXISTS `product_type_enum` (
  `product_type_enum_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type_name` varchar(200) NOT NULL,
  `product_enum_description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_type_enum_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_type_enum: ~3 rows (approximately)
/*!40000 ALTER TABLE `product_type_enum` DISABLE KEYS */;
INSERT INTO `product_type_enum` (`product_type_enum_id`, `product_type_name`, `product_enum_description`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 'Workflow System', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(2, 'Hr System', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL),
	(3, 'Tool System', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `product_type_enum` ENABLE KEYS */;

-- Dumping structure for table test.product_type_system
CREATE TABLE IF NOT EXISTS `product_type_system` (
  `product_type_system_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `product_type_enum_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_type_system_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table test.product_type_system: ~5 rows (approximately)
/*!40000 ALTER TABLE `product_type_system` DISABLE KEYS */;
INSERT INTO `product_type_system` (`product_type_system_id`, `product_id`, `product_type_enum_id`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(4, 14, 1, 1, 0, NULL, NULL, NULL, 11, NULL),
	(5, 18, 2, 1, 0, NULL, NULL, NULL, 11, NULL),
	(8, 19, 1, 1, 0, NULL, NULL, NULL, 11, NULL),
	(12, 2, 1, 1, 0, NULL, NULL, NULL, 14, NULL),
	(14, 1, 1, 1, 0, NULL, NULL, NULL, 14, NULL);
/*!40000 ALTER TABLE `product_type_system` ENABLE KEYS */;

-- Dumping structure for table test.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `is_deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.roles: ~2 rows (approximately)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`role_id`, `name`, `description`, `role_code`, `created_by`, `updated_by`, `created_at`, `deleted_at`, `updated_at`, `is_active`, `is_deleted`) VALUES
	(1, 'Admin', 'Admin 1', 'RL1', NULL, NULL, '2018-12-11 06:05:55', NULL, '2018-12-11 06:20:19', 1, 0),
	(2, 'Sub Admin', 'Sub Admin', 'RL2', NULL, NULL, '2018-12-11 06:19:22', NULL, '2018-12-11 06:22:24', 1, 0),
	(3, 'test', 'tes', 'RL3', NULL, NULL, '2018-12-13 07:26:15', NULL, '2018-12-13 07:26:21', 1, 1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Dumping structure for table test.status_enum
CREATE TABLE IF NOT EXISTS `status_enum` (
  `status_enum_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL,
  `status_enum_name` varchar(200) NOT NULL,
  `status_enum_description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`status_enum_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table test.status_enum: ~2 rows (approximately)
/*!40000 ALTER TABLE `status_enum` DISABLE KEYS */;
INSERT INTO `status_enum` (`status_enum_id`, `status_id`, `status_enum_name`, `status_enum_description`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 1, 'Active', 'Active', 1, 0, NULL, NULL, NULL, NULL, NULL),
	(2, 0, 'In Active', 'In Active', 1, 0, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `status_enum` ENABLE KEYS */;

-- Dumping structure for table test.sub_module
CREATE TABLE IF NOT EXISTS `sub_module` (
  `sub_module_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `sub_module_code` varchar(50) NOT NULL,
  `sub_module_name` varchar(200) NOT NULL,
  `sub_description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`sub_module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table test.sub_module: ~14 rows (approximately)
/*!40000 ALTER TABLE `sub_module` DISABLE KEYS */;
INSERT INTO `sub_module` (`sub_module_id`, `module_id`, `sub_module_code`, `sub_module_name`, `sub_description`, `is_active`, `is_deleted`, `created_at`, `deleted_at`, `updated_at`, `created_by`, `updated_by`) VALUES
	(1, 1, '', 'test 11', 'test1', 1, 1, '2018-12-10 13:17:15', NULL, '2018-12-10 13:41:27', NULL, NULL),
	(2, 2, '', 'test', 'rewrwe', 1, 0, '2018-12-10 13:29:13', NULL, '2018-12-17 07:31:40', NULL, NULL),
	(3, 3, '', 'test', 'test 1', 0, 1, '2018-12-14 06:34:50', NULL, '2018-12-17 07:29:49', NULL, NULL),
	(4, 3, '', 'test 1', 'test 1', 1, 1, '2018-12-14 06:55:35', NULL, '2018-12-17 07:29:49', NULL, NULL),
	(5, 3, '', 'test we', 'test 1', 1, 1, '2018-12-14 06:55:42', NULL, '2018-12-17 07:29:49', NULL, NULL),
	(6, 4, '', 'test', 'test 1', 1, 1, '2018-12-14 06:55:58', NULL, '2018-12-14 06:55:58', NULL, NULL),
	(7, 3, '', 'test 112', 'test', 1, 1, '2018-12-14 06:58:15', NULL, '2018-12-17 07:29:49', NULL, NULL),
	(8, 2, '', 'test e', 'test', 1, 0, '2018-12-14 10:28:03', NULL, '2018-12-17 07:31:40', NULL, NULL),
	(9, 2, '', 'test ee', 'test', 1, 0, '2018-12-14 10:29:17', NULL, '2018-12-17 07:31:40', NULL, NULL),
	(10, 2, '', 'test ee4', 'test', 1, 0, '2018-12-14 10:30:01', NULL, '2018-12-17 07:31:40', NULL, NULL),
	(11, 2, '', 'rtytr', 'ytry', 1, 0, '2018-12-14 11:19:57', NULL, '2018-12-17 07:31:40', NULL, NULL),
	(12, 2, '', 'tesrewr', 'fre', 1, 0, '2018-12-14 11:24:14', NULL, '2018-12-17 07:31:40', NULL, NULL),
	(13, 2, '', 'test', 'rewrwe', 1, 0, '2018-12-14 13:52:00', NULL, '2018-12-17 07:31:40', NULL, NULL),
	(14, 3, 'HO14-01', 'one', 'test', 1, 1, '2018-12-18 06:11:50', NULL, '2018-12-18 06:11:50', NULL, NULL);
/*!40000 ALTER TABLE `sub_module` ENABLE KEYS */;

-- Dumping structure for table test.team
CREATE TABLE IF NOT EXISTS `team` (
  `team_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `team_name` varchar(255) NOT NULL,
  `team_description` varchar(25) NOT NULL,
  `team_head` int(10) unsigned DEFAULT NULL,
  `secondary_reporting` int(10) unsigned DEFAULT NULL,
  `sub_circle_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.team: ~0 rows (approximately)
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;

-- Dumping structure for table test.technology
CREATE TABLE IF NOT EXISTS `technology` (
  `technology_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `is_deleted` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`technology_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.technology: ~7 rows (approximately)
/*!40000 ALTER TABLE `technology` DISABLE KEYS */;
INSERT INTO `technology` (`technology_id`, `name`, `description`, `created_by`, `updated_by`, `created_at`, `deleted_at`, `updated_at`, `is_active`, `is_deleted`) VALUES
	(1, 'PHP', 'PHP', NULL, NULL, NULL, NULL, NULL, 1, 0),
	(2, 'PYTHON', 'PYTHON', NULL, NULL, NULL, NULL, NULL, 1, 0),
	(3, '.NET', '.NET', NULL, NULL, NULL, NULL, NULL, 1, 0),
	(4, 'JAVA', 'JAVA', NULL, NULL, NULL, NULL, NULL, 1, 0),
	(5, 'ANDROID', 'ANDROID', NULL, NULL, NULL, NULL, NULL, 1, 0),
	(6, 'IOS', 'IOS', NULL, NULL, NULL, NULL, NULL, 1, 0),
	(7, 'RUBY ON RAILS', 'RUBY ON RAILS', NULL, NULL, NULL, NULL, NULL, 1, 0),
	(8, 'NODE JS ', 'NODE JS ', NULL, NULL, NULL, NULL, NULL, 1, 0);
/*!40000 ALTER TABLE `technology` ENABLE KEYS */;

-- Dumping structure for table test.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `is_deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.users: ~5 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `email`, `password`, `created_by`, `remember_token`, `created_at`, `updated_at`, `is_active`, `is_deleted`) VALUES
	(11, 'Arun', '', 'P', 'arunkumar.P@spi-global.com', '$2y$10$ADBKXJzfrqn/jsgbWlJ7d.2XmttoEtUhA7o/Q5Z04CVglYm95ZuwC', NULL, 'Yn6pVtPhX8lZ6iOTqNUWHbaSQ724cVMg7JKKyAacMN5LHIXvbzKqXq0mWzeO', '2018-11-28 15:16:00', '2018-12-18 07:33:51', 1, 0),
	(12, 'mathan', NULL, 'P', 'mathankumar.p@spi-global.com', '$2y$10$6edNVFclNDpp37LQ748u3.SlYuqQnpz9mWd1.khMUNsESCQtC.tjy', NULL, 'AubC3ZeClAqRFoZxlxKP67nReyCiS9TeIkYMv3gyl2zjOdGD10WfQO6bFFqk', '2018-11-29 10:33:29', '2018-12-03 07:03:56', 1, 0),
	(14, 'vinoth', NULL, 'Kumar', 'vinoth.t@spi-global.com', '$2y$10$RAaNgTKjPr3eBGVBopDOXuWkZZcGTwQIGs2Vrkn0QuRB3tVLKZ4oG', NULL, 'WgVTUFeiMlUJX34UpBKJdmqc1noSw7BvKjrCKZ7u8MQXV7DBw9QlXURpWMQ7', '2018-11-30 11:46:40', '2018-12-28 05:57:26', 1, 0),
	(15, 'Ashok', NULL, 't', 'vinoth1@spi-global.com', '$2y$10$lxmFHBjKr5XypBooEOj3ZeSIAkXTubtwv7S4dJTFKQO6R.IyWkrie', NULL, NULL, '2018-12-03 10:23:06', '2018-12-03 10:23:06', 1, 0),
	(16, 'vinoth', NULL, 't', 'vintryoth@spi-global.com', '$2y$10$3ER.xt1KjSUlRppF.ZEPG.2EJuWxZB9Q6SBfwzyJObFhYz/fz0yRm', NULL, NULL, '2018-12-07 06:36:13', '2018-12-07 06:36:13', 1, 0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table test.users_info
CREATE TABLE IF NOT EXISTS `users_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `employee_id` int(10) DEFAULT NULL,
  `employee_type` varchar(155) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(10) DEFAULT NULL,
  `team_id` int(10) DEFAULT NULL,
  `mobile` text COLLATE utf8mb4_unicode_ci,
  `dob` datetime DEFAULT NULL,
  `doj` datetime DEFAULT NULL,
  `profile` text COLLATE utf8mb4_unicode_ci,
  `ip_address` text COLLATE utf8mb4_unicode_ci,
  `last_ip_address` text COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `is_deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.users_info: ~5 rows (approximately)
/*!40000 ALTER TABLE `users_info` DISABLE KEYS */;
INSERT INTO `users_info` (`id`, `user_id`, `employee_id`, `employee_type`, `role_id`, `team_id`, `mobile`, `dob`, `doj`, `profile`, `ip_address`, `last_ip_address`, `created_by`, `updated_by`, `created_at`, `updated_at`, `is_active`, `is_deleted`) VALUES
	(1, 11, 45542, '2', 2, 1, NULL, NULL, NULL, 'userimages/45542_Koala.jpg', '::1', '172.24.183.332', NULL, 1255, NULL, '2018-12-18 07:33:51', 1, 0),
	(2, 12, 6251, '2', 42, 1, NULL, NULL, NULL, 'dist/img/avatar5.png', '::1', '172.24.183.332', NULL, 1255, NULL, '2018-12-03 11:38:50', 1, 0),
	(3, 14, 45542, '1', NULL, 19, NULL, NULL, NULL, NULL, '172.24.191.78', '172.24.177.171', NULL, 14, NULL, '2018-12-28 05:57:26', 1, 0),
	(4, 15, 132455, '1', NULL, 19, NULL, NULL, NULL, 'uploads/132455_Lighthouse.jpg', '172.24.183.332', '172.24.183.332', NULL, 1255, NULL, '2018-12-13 07:15:38', 1, 0),
	(5, 16, 4325325, '2', NULL, 20, NULL, NULL, NULL, 'userimages/4325325_Jellyfish.jpg', '::1', '172.24.177.171', NULL, 16, NULL, '2018-12-28 05:57:14', 1, 0);
/*!40000 ALTER TABLE `users_info` ENABLE KEYS */;

-- Dumping structure for table test.user_products
CREATE TABLE IF NOT EXISTS `user_products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.user_products: ~5 rows (approximately)
/*!40000 ALTER TABLE `user_products` DISABLE KEYS */;
INSERT INTO `user_products` (`id`, `product_id`, `user_id`, `role_id`, `created_by`, `updated_by`, `created_at`, `deleted_at`, `updated_at`, `is_active`) VALUES
	(1, 1, 11, 2, 11, NULL, '2018-12-03 11:03:55', NULL, NULL, 1),
	(2, 2, 11, 2, 11, NULL, '2018-12-03 11:04:17', NULL, NULL, 1),
	(3, 3, 11, 2, 11, NULL, '2018-12-03 11:04:28', NULL, NULL, 1),
	(4, 2, 12, 42, 12, NULL, '2018-12-03 11:06:40', NULL, NULL, 1),
	(5, 3, 12, 43, 12, NULL, '2018-12-03 11:06:52', NULL, NULL, 1);
/*!40000 ALTER TABLE `user_products` ENABLE KEYS */;

-- Dumping structure for table test.user_roles
CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `is_deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table test.user_roles: ~4 rows (approximately)
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` (`user_role_id`, `user_id`, `role_id`, `product_id`, `created_by`, `updated_by`, `created_at`, `deleted_at`, `updated_at`, `is_active`, `is_deleted`) VALUES
	(1, 11, 1, 2, 14, 14, '2018-12-22 12:45:44', NULL, '2018-12-24 10:33:15', 1, 0),
	(2, 12, 1, 2, 14, 14, '2018-12-22 12:51:14', NULL, '2018-12-24 10:33:22', 1, 0),
	(8, 11, 1, 2, 14, NULL, '2018-12-24 06:20:17', NULL, '2018-12-24 06:31:23', 1, 1),
	(10, 14, 1, 1, 14, NULL, '2018-12-24 13:37:31', NULL, NULL, 1, 0);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;

-- Dumping structure for table test.user_team_map
CREATE TABLE IF NOT EXISTS `user_team_map` (
  `user_team_map_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `team_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_team_map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.user_team_map: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_team_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_team_map` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
